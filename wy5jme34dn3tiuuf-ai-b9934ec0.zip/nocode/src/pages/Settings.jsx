import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { 
  User, 
  Heart, 
  Utensils, 
  ChefHat, 
  Sparkles,
  Camera,
  Flame,
  Leaf
} from 'lucide-react';
import { toast } from 'sonner';

const DIET_PREFERENCES = [
  { id: 'normal', label: '正常饮食', emoji: '🍽️', desc: '均衡营养，健康饮食' },
  { id: 'weight_loss', label: '减脂健身', emoji: '🥗', desc: '低卡高蛋白，控制热量' },
  { id: 'muscle', label: '增肌塑形', emoji: '💪', desc: '高蛋白，适量碳水' },
  { id: 'comfort', label: '治愈美食', emoji: '😋', desc: '美味至上，满足味蕾' },
];

const TASTE_PREFERENCES = [
  { id: 'light', label: '清淡', emoji: '🌿', desc: '少油少盐，原汁原味' },
  { id: 'spicy', label: '偏辣', emoji: '🌶️', desc: '无辣不欢，刺激味蕾' },
  { id: 'sweet', label: '偏甜', emoji: '🍯', desc: '甜蜜滋味，心情愉悦' },
  { id: 'sour', label: '偏酸', emoji: '🍋', desc: '酸爽开胃，消食解腻' },
];

const CUISINE_TYPES = [
  { id: 'sichuan', label: '川菜', emoji: '🌶️' },
  { id: 'cantonese', label: '粤菜', emoji: '🍤' },
  { id: 'japanese', label: '日料', emoji: '🍣' },
  { id: 'korean', label: '韩餐', emoji: '🍜' },
  { id: 'western', label: '西餐', emoji: '🥩' },
  { id: 'hunan', label: '湘菜', emoji: '🌶️' },
];

const Settings = ({ preferences, onUpdatePreferences }) => {
  const [localPrefs, setLocalPrefs] = useState(preferences || {});
  const [userInfo, setUserInfo] = useState({
    userId: localPrefs.userId || '',
    avatar: localPrefs.avatar || '',
  });

  const handleSaveUserInfo = () => {
    const updated = { ...localPrefs, ...userInfo };
    setLocalPrefs(updated);
    onUpdatePreferences(updated);
    toast.success('个人信息已保存');
  };

  const handleToggleExplore = (value) => {
    const updated = { ...localPrefs, exploreNewDishes: value };
    setLocalPrefs(updated);
    onUpdatePreferences(updated);
  };

  const handleDietSelect = (dietId) => {
    const updated = { ...localPrefs, dietPreference: dietId };
    setLocalPrefs(updated);
    onUpdatePreferences(updated);
    toast.success('饮食偏好已更新');
  };

  const handleTasteSelect = (tasteId) => {
    const updated = { ...localPrefs, tastePreference: tasteId };
    setLocalPrefs(updated);
    onUpdatePreferences(updated);
    toast.success('口味偏好已更新');
  };

  const handleCuisineToggle = (cuisineId) => {
    const current = localPrefs.preferredCuisines || [];
    const updated = current.includes(cuisineId)
      ? current.filter(c => c !== cuisineId)
      : [...current, cuisineId];
    
    const newPrefs = { ...localPrefs, preferredCuisines: updated };
    setLocalPrefs(newPrefs);
    onUpdatePreferences(newPrefs);
  };

  return (
    <div className="space-y-6 pb-24">
      {/* 页面标题 */}
      <div>
        <h2 className="font-bold text-xl text-gray-800">设置中心</h2>
        <p className="text-sm text-gray-500">定制你的专属 AI 厨房体验 ✨</p>
      </div>

      {/* 个人信息 */}
      <Card className="border-green-100 overflow-hidden">
        <CardContent className="p-4">
          <h3 className="font-medium text-green-700 flex items-center gap-2 mb-4">
            <div className="w-6 h-6 rounded-full bg-green-100 flex items-center justify-center">
              <User size={14} className="text-green-600" />
            </div>
            个人信息
          </h3>
          
          <div className="flex items-center gap-4 mb-4">
            <div className="relative">
              <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-pink-100 to-purple-100 flex items-center justify-center text-3xl overflow-hidden">
                {userInfo.avatar ? (
                  <img src={userInfo.avatar} alt="头像" className="w-full h-full object-cover" />
                ) : (
                  <span>👨‍🍳</span>
                )}
              </div>
              <button className="absolute -bottom-1 -right-1 w-8 h-8 bg-green-500 text-white rounded-full flex items-center justify-center shadow-lg">
                <Camera size={14} />
              </button>
            </div>
            <div className="flex-1 space-y-3">
              <div>
                <Label className="text-xs text-gray-500">昵称</Label>
                <Input 
                  value={userInfo.userId}
                  onChange={(e) => setUserInfo(prev => ({ ...prev, userId: e.target.value }))}
                  placeholder="输入你的昵称"
                  className="mt-1 border-green-200"
                />
              </div>
            </div>
          </div>
          
          <Button 
            className="w-full bg-green-500 hover:bg-green-600 rounded-xl"
            onClick={handleSaveUserInfo}
          >
            保存信息
          </Button>
        </CardContent>
      </Card>

      {/* 探索新菜单开关 */}
      <Card className="border-green-100">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-100 to-pink-100 flex items-center justify-center text-xl">
                <Sparkles size={20} className="text-purple-600" />
              </div>
              <div>
                <h3 className="font-medium text-gray-800">今天尝试新菜单？</h3>
                <p className="text-xs text-gray-500">
                  {localPrefs.exploreNewDishes ? '会为你推荐新菜品' : '优先推荐你喜欢的菜'}
                </p>
              </div>
            </div>
            <Switch 
              checked={localPrefs.exploreNewDishes || false}
              onCheckedChange={handleToggleExplore}
              className="data-[state=checked]:bg-green-500"
            />
          </div>
        </CardContent>
      </Card>

      {/* 饮食偏好 */}
      <Card className="border-green-100">
        <CardContent className="p-4">
          <h3 className="font-medium text-green-700 flex items-center gap-2 mb-4">
            <div className="w-6 h-6 rounded-full bg-green-100 flex items-center justify-center">
              <Heart size={14} className="text-green-600" />
            </div>
            饮食偏好
          </h3>
          
          <div className="grid grid-cols-2 gap-3">
            {DIET_PREFERENCES.map((diet) => (
              <button
                key={diet.id}
                onClick={() => handleDietSelect(diet.id)}
                className={`p-3 rounded-xl border-2 text-left transition-all ${
                  localPrefs.dietPreference === diet.id
                    ? 'border-green-400 bg-green-50'
                    : 'border-gray-100 bg-white hover:border-green-200'
                }`}
              >
                <div className="text-2xl mb-1">{diet.emoji}</div>
                <div className={`text-sm font-medium ${
                  localPrefs.dietPreference === diet.id ? 'text-green-700' : 'text-gray-700'
                }`}>
                  {diet.label}
                </div>
                <div className="text-xs text-gray-400 mt-0.5">{diet.desc}</div>
              </button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* 口味偏好 */}
      <Card className="border-green-100">
        <CardContent className="p-4">
          <h3 className="font-medium text-green-700 flex items-center gap-2 mb-4">
            <div className="w-6 h-6 rounded-full bg-orange-100 flex items-center justify-center">
              <Flame size={14} className="text-orange-600" />
            </div>
            口味偏好
          </h3>
          
          <div className="grid grid-cols-4 gap-2">
            {TASTE_PREFERENCES.map((taste) => (
              <button
                key={taste.id}
                onClick={() => handleTasteSelect(taste.id)}
                className={`p-3 rounded-xl border-2 text-center transition-all ${
                  localPrefs.tastePreference === taste.id
                    ? 'border-orange-400 bg-orange-50'
                    : 'border-gray-100 bg-white hover:border-orange-200'
                }`}
              >
                <div className="text-2xl mb-1">{taste.emoji}</div>
                <div className={`text-sm font-medium ${
                  localPrefs.tastePreference === taste.id ? 'text-orange-700' : 'text-gray-700'
                }`}>
                  {taste.label}
                </div>
              </button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* 菜系偏好 */}
      <Card className="border-green-100">
        <CardContent className="p-4">
          <h3 className="font-medium text-green-700 flex items-center gap-2 mb-4">
            <div className="w-6 h-6 rounded-full bg-blue-100 flex items-center justify-center">
              <Utensils size={14} className="text-blue-600" />
            </div>
            喜欢的菜系
          </h3>
          
          <div className="flex flex-wrap gap-2">
            {CUISINE_TYPES.map((cuisine) => (
              <button
                key={cuisine.id}
                onClick={() => handleCuisineToggle(cuisine.id)}
                className={`px-4 py-2 rounded-full border-2 text-sm transition-all ${
                  (localPrefs.preferredCuisines || []).includes(cuisine.id)
                    ? 'border-blue-400 bg-blue-50 text-blue-700'
                    : 'border-gray-200 bg-white text-gray-600 hover:border-blue-200'
                }`}
              >
                <span className="mr-1">{cuisine.emoji}</span>
                {cuisine.label}
              </button>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default Settings;
