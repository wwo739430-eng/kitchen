import { useState, useMemo } from 'react';
import { useIngredients } from '@/hooks/useIngredients';
import { useUserPreferences } from '@/hooks/useUserPreferences';
import { useRecipes } from '@/hooks/useRecipes';
import { useFavorites } from '@/hooks/useFavorites';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  Menu, 
  ChefHat, 
  ShoppingCart, 
  Plus,
  Sparkles,
  Package,
  Heart,
  Settings,
  Home,
  ScanLine,
  Trash2,
  Clock,
  Users,
  ChefHat as ChefHatIcon,
  ShoppingBag,
  RefreshCw
} from 'lucide-react';
import IngredientForm from '@/components/ingredients/IngredientForm';
import AIIngredientScanner from '@/components/ingredients/AIIngredientScanner';
import IngredientCard from '@/components/ingredients/IngredientCard';
import MoodAndMealSelector from '@/components/mood/MoodAndMealSelector';
import RecipeCard from '@/components/recipes/RecipeCard';
import ShoppingList from '@/components/recipes/ShoppingList';
import BottomNav from '@/components/layout/BottomNav';
import SettingsPage from './Settings';
import { getIngredientEmoji, getRecipeEmoji } from '@/lib/recipeEmojis';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';

const Index = () => {
  const { 
    ingredients, 
    isLoading, 
    addIngredient, 
    deleteIngredient, 
    updateIngredient,
    getRemainingDays,
    getExpiringSoon 
  } = useIngredients();
  
  const { preferences, updatePreferences } = useUserPreferences();
  const { 
    recipes, 
    recommendedRecipes, 
    isLoading: recipesLoading,
    getFilteredByTime,
    generateSmartRecommendations
  } = useRecipes(preferences, ingredients);
  
  const { 
    favorites, 
    addFavorite, 
    removeFavorite, 
    isFavorite,
    getRecentFavorites 
  } = useFavorites();
  
  const [activePage, setActivePage] = useState('home');
  const [showShoppingList, setShowShoppingList] = useState(false);
  const [shoppingItems, setShoppingItems] = useState([]);
  const [showAddForm, setShowAddForm] = useState(false);
  const [showScanner, setShowScanner] = useState(false);
  const [generatedRecipes, setGeneratedRecipes] = useState(null);
  const [isGenerating, setIsGenerating] = useState(false);

  const expiringSoon = getExpiringSoon(3);
  
  // 根据烹饪时间筛选菜谱
  const getRecipesByTime = () => {
    let recipes = generatedRecipes || recommendedRecipes;
    
    // 根据用餐类型筛选
    if (preferences.mealType === 'simple') {
      recipes = recipes.filter(r => r.cook_time <= 15);
    } else if (preferences.mealType === 'elaborate') {
      recipes = recipes.filter(r => r.cook_time >= 45);
    } else {
      recipes = recipes.filter(r => r.cook_time > 15 && r.cook_time < 45);
    }
    
    // 如果不愿意尝试新菜，优先推荐收藏的菜
    if (!preferences.exploreNewDishes && favorites.length > 0) {
      const favoriteIds = favorites.map(f => f.id);
      const favoriteRecipes = recipes.filter(r => favoriteIds.includes(r.id));
      if (favoriteRecipes.length > 0) {
        return favoriteRecipes;
      }
    }
    
    return recipes;
  };

  // 一键生成推荐
  const handleGenerateRecommendations = async () => {
    setIsGenerating(true);
    toast.info('正在根据你的心情和食材智能推荐...');
    
    // 模拟AI生成过程
    setTimeout(() => {
      const smartRecipes = generateSmartRecommendations();
      setGeneratedRecipes(smartRecipes);
      setIsGenerating(false);
      toast.success(`为你生成了 ${smartRecipes.length} 道推荐菜谱！`);
    }, 1500);
  };

  const handleAddToShopping = (recipe) => {
    setShoppingItems(recipe.missingIngredients.map(mi => ({
      name: mi.ingredient_name,
      amount: mi.amount
    })));
    setShowShoppingList(true);
  };

  // 更新食材数量
  const handleUpdateQuantity = (id, newQuantity) => {
    updateIngredient({ id, quantity: newQuantity });
  };

  // 处理扫描结果
  const handleScanComplete = (scannedData) => {
    addIngredient({
      name: scannedData.name,
      quantity: scannedData.quantity,
      expiry_days: scannedData.expiryDays,
      storage_location: scannedData.storageLocation,
      image: `https://nocode.meituan.com/photo/search?keyword=${encodeURIComponent(scannedData.name)}&width=200&height=200`,
    });
    setShowScanner(false);
  };

  // 渲染首页
  const renderHome = () => {
    const displayRecipes = getRecipesByTime();
    
    return (
      <div className="space-y-4 pb-24">
        {/* 心情和用餐类型选择 - 首位展示 */}
        <MoodAndMealSelector preferences={preferences} onUpdate={updatePreferences} />

        {/* 过期提醒 */}
        {expiringSoon.length > 0 && (
          <div className="bg-gradient-to-r from-orange-50 to-red-50 border border-orange-200 rounded-2xl p-4 flex items-start gap-3">
            <div className="w-10 h-10 rounded-full bg-orange-100 flex items-center justify-center flex-shrink-0">
              <Sparkles size={20} className="text-orange-500" />
            </div>
            <div>
              <h4 className="font-medium text-orange-800">食材提醒</h4>
              <p className="text-sm text-orange-600 mt-1">
                {expiringSoon.slice(0, 3).map((item, idx) => (
                  <span key={item.id}>
                    {idx > 0 && '、'}
                    {item.name}
                    {getRemainingDays(item.created_at, item.expiry_days) <= 0 ? '（已过期）' : `（${getRemainingDays(item.created_at, item.expiry_days)}天后过期）`}
                  </span>
                ))}
                {expiringSoon.length > 3 && ` 等${expiringSoon.length}种食材`}
              </p>
              <p className="text-xs text-orange-500 mt-1">推荐优先使用这些食材做菜</p>
            </div>
          </div>
        )}

        {/* 一键生成推荐按钮 */}
        <Button
          onClick={handleGenerateRecommendations}
          disabled={isGenerating}
          className="w-full py-6 bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white rounded-2xl shadow-lg shadow-green-200 text-base font-medium"
        >
          <RefreshCw size={20} className={cn("mr-2", isGenerating && "animate-spin")} />
          {isGenerating ? '正在生成推荐...' : '✨ 一键生成推荐菜谱'}
        </Button>

        {/* 推荐菜谱区域 - 新版样式 */}
        {displayRecipes.length > 0 && (
          <div>
            {/* 区域标题 */}
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="font-bold text-lg text-gray-800">
                  给"{preferences.current_mood === '低落' ? '需要治愈' : 
                       preferences.current_mood === '疲惫' ? '疲惫' : 
                       preferences.current_mood === '一般' ? '平淡' : 
                       preferences.current_mood === '不错' ? '心情不错' : '开心'}的你"准备的舒适餐
                </h3>
              </div>
              <Badge className="bg-green-100 text-green-700 border-0 px-3 py-1">
                {displayRecipes[0]?.steps?.length || 3}步搞定
              </Badge>
            </div>

            {/* 菜谱卡片列表 - 新版横向样式 */}
            <div className="space-y-4">
              {displayRecipes.slice(0, 5).map(recipe => (
                <RecipeCard 
                  key={recipe.id} 
                  recipe={recipe} 
                  servings={preferences.servings || 2}
                  onAddToShopping={handleAddToShopping}
                  isFavorite={isFavorite(recipe.id)}
                  onToggleFavorite={(r) => isFavorite(r.id) ? removeFavorite(r.id) : addFavorite(r)}
                  variant="horizontal"
                />
              ))}
            </div>
          </div>
        )}

        {recipesLoading && !generatedRecipes && (
          <div className="text-center py-8 text-gray-400">
            <div className="w-8 h-8 border-2 border-green-500 border-t-transparent rounded-full animate-spin mx-auto mb-3"></div>
            加载中...
          </div>
        )}
        
        {!recipesLoading && displayRecipes.length === 0 && (
          <div className="text-center py-12 bg-gray-50 rounded-2xl">
            <div className="text-6xl mb-4">🍳</div>
            <p className="text-gray-500">暂无匹配的菜谱</p>
            <p className="text-sm text-gray-400 mt-1">尝试调整用餐类型或添加更多食材</p>
          </div>
        )}
      </div>
    );
  };

  // 渲染食材库
  const renderIngredients = () => (
    <div className="space-y-4 pb-24">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="font-bold text-xl text-gray-800 flex items-center gap-2">
            我的食材库
            <span className="text-2xl">🥬</span>
          </h2>
          <p className="text-sm text-gray-500">看一看今天冰箱里还有什么宝贝？🍎</p>
        </div>
      </div>

      {/* 统计卡片 */}
      <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-2xl p-4 text-white">
        <h4 className="font-medium flex items-center gap-2">
          <Package size={18} />
          库存简报
        </h4>
        <div className="grid grid-cols-2 gap-4 mt-3">
          <div>
            <p className="text-green-100 text-sm">即将过期</p>
            <p className="text-2xl font-bold">{expiringSoon.length}</p>
          </div>
          <div>
            <p className="text-green-100 text-sm">库存总量</p>
            <p className="text-2xl font-bold">{ingredients.length}</p>
          </div>
        </div>
      </div>

      {/* 添加食材按钮组 */}
      <div className="grid grid-cols-2 gap-3">
        <Button 
          onClick={() => setShowAddForm(true)}
          className="py-4 bg-green-500 hover:bg-green-600 text-white rounded-xl"
        >
          <Plus size={20} className="mr-2" />
          手动添加
        </Button>
        <Button 
          onClick={() => setShowScanner(true)}
          variant="outline"
          className="py-4 border-2 border-green-300 text-green-600 hover:bg-green-50 rounded-xl"
        >
          <ScanLine size={20} className="mr-2" />
          AI扫描
        </Button>
      </div>

      {/* 添加表单或扫描器 */}
      {showAddForm && (
        <IngredientForm 
          onSubmit={(data) => {
            addIngredient(data);
            setShowAddForm(false);
          }} 
          isLoading={isLoading} 
        />
      )}

      {/* 按分类展示食材 */}
      {['冷藏', '冷冻', '常温', '调料'].map((location) => {
        const locationIngredients = ingredients.filter(i => i.storage_location === location);
        if (locationIngredients.length === 0) return null;
        
        const icons = {
          '冷藏': '❄️ 冷藏 (Fridge)',
          '冷冻': '🧊 冷冻 (Freezer)', 
          '常温': '🌡️ 常温 (Pantry)',
          '调料': '🧂 调料 (Spices)'
        };
        
        return (
          <div key={location} className="space-y-3">
            <h3 className="font-medium text-gray-700 flex items-center gap-2">
              {icons[location]}
            </h3>
            <div className="grid gap-3">
              {locationIngredients.map(ingredient => (
                <IngredientCard
                  key={ingredient.id}
                  ingredient={ingredient}
                  remainingDays={getRemainingDays(ingredient.created_at, ingredient.expiry_days)}
                  onEdit={updateIngredient}
                  onDelete={deleteIngredient}
                  onUpdateQuantity={handleUpdateQuantity}
                />
              ))}
            </div>
          </div>
        );
      })}

      {!isLoading && ingredients.length === 0 && (
        <div className="text-center py-12">
          <div className="text-6xl mb-4">🥬</div>
          <p className="text-gray-500">食材库还是空的</p>
          <p className="text-sm text-gray-400 mt-1">添加食材开始智能推荐</p>
        </div>
      )}
    </div>
  );

  // 渲染收藏夹
  const renderFavorites = () => (
    <div className="space-y-4 pb-24">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="font-bold text-xl text-gray-800 flex items-center gap-2">
            我的收藏
            <Heart size={24} className="text-red-500 fill-red-500" />
          </h2>
          <p className="text-sm text-gray-500">你收藏的美味菜谱，随时想吃就做</p>
        </div>
        <Badge className="bg-red-100 text-red-700">
          {favorites.length}道菜
        </Badge>
      </div>

      {favorites.length === 0 ? (
        <div className="text-center py-16 bg-gray-50 rounded-2xl">
          <div className="text-6xl mb-4">💝</div>
          <p className="text-gray-500">还没有收藏任何菜谱</p>
          <p className="text-sm text-gray-400 mt-2">在首页找到喜欢的菜，点击❤️收藏</p>
          <Button 
            className="mt-4 bg-green-500 hover:bg-green-600"
            onClick={() => setActivePage('home')}
          >
            去发现美食
          </Button>
        </div>
      ) : (
        <div className="grid gap-4">
          {favorites.map(recipe => (
            <div key={recipe.id} className="relative group">
              <RecipeCard 
                recipe={recipe} 
                servings={preferences.servings || 2}
                onAddToShopping={handleAddToShopping}
                isFavorite={true}
                onToggleFavorite={() => removeFavorite(recipe.id)}
                variant="horizontal"
              />
            </div>
          ))}
        </div>
      )}
    </div>
  );

  // 渲染购物清单
  const renderShopping = () => (
    <div className="space-y-4 pb-24">
      <div className="flex items-center justify-between">
        <h2 className="font-bold text-xl text-gray-800">采购清单</h2>
        <Badge className="bg-green-100 text-green-700">{shoppingItems.length}项</Badge>
      </div>
      <p className="text-sm text-gray-500">别忘了这些能让食谱更美味的食材哦！</p>
      
      <Card className="border-green-100">
        <CardContent className="p-4">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-8 h-8 rounded-lg bg-green-100 flex items-center justify-center">
              <ShoppingCart size={18} className="text-green-600" />
            </div>
            <span className="font-medium">待购清单</span>
            <Badge className="bg-green-100 text-green-700">{shoppingItems.length}</Badge>
          </div>
          
          {shoppingItems.length === 0 ? (
            <div className="text-center text-gray-400 py-8">
              <div className="text-4xl mb-2">🛒</div>
              <p>暂无需要购买的食材</p>
              <p className="text-xs mt-1">去首页添加菜谱到购物清单</p>
            </div>
          ) : (
            <div className="space-y-2">
              {shoppingItems.map((item, idx) => (
                <div key={idx} className="flex items-center justify-between p-3 bg-gray-50 rounded-xl">
                  <div className="flex items-center gap-3">
                    <span className="text-xl">{getIngredientEmoji(item.name)}</span>
                    <div>
                      <p className="font-medium text-gray-800">{item.name}</p>
                      <p className="text-xs text-gray-500">需采购: {item.amount}</p>
                    </div>
                  </div>
                  <Button 
                    size="sm" 
                    variant="outline" 
                    className="rounded-full text-green-600 border-green-300"
                    onClick={() => {
                      const newItems = shoppingItems.filter((_, i) => i !== idx);
                      setShoppingItems(newItems);
                      toast.success('已添加到食材库');
                    }}
                  >
                    + 添加
                  </Button>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Cloudy 小贴士 */}
      <div className="bg-gradient-to-br from-green-50 to-blue-50 rounded-2xl p-4">
        <div className="flex items-center gap-2 mb-2">
          <div className="w-8 h-8 rounded-full bg-white flex items-center justify-center">
            <ChefHat size={16} className="text-green-600" />
          </div>
          <span className="font-medium text-green-800">Cloudy 的小贴士</span>
        </div>
        <p className="text-sm text-green-700">
          "去超市前记得先看看冰箱，有些调料可能还有存货哦！环保又省钱 ✨"
        </p>
      </div>
    </div>
  );

  const renderContent = () => {
    switch (activePage) {
      case 'home': return renderHome();
      case 'ingredients': return renderIngredients();
      case 'favorites': return renderFavorites();
      case 'shopping': return renderShopping();
      case 'settings': return (
        <SettingsPage 
          preferences={preferences} 
          onUpdatePreferences={updatePreferences} 
        />
      );
      default: return renderHome();
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50/50 to-white">
      {/* 顶部导航 */}
      <header className="sticky top-0 z-10 bg-white/80 backdrop-blur-md border-b border-green-100">
        <div className="max-w-lg mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-green-400 to-green-600 flex items-center justify-center">
              <ChefHat size={16} className="text-white" />
            </div>
            <h1 className="font-bold text-gray-800">心情厨房 AI</h1>
          </div>
          <Button 
            variant="ghost" 
            size="sm"
            className="text-green-600 relative"
            onClick={() => setShowShoppingList(true)}
          >
            <ShoppingCart size={20} />
            {shoppingItems.length > 0 && (
              <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-red-500 text-white text-xs flex items-center justify-center">
                {shoppingItems.length}
              </span>
            )}
          </Button>
        </div>
      </header>

      {/* 页面内容 */}
      <main className="max-w-lg mx-auto p-4">
        {renderContent()}
      </main>

      {/* 底部导航 */}
      <BottomNav 
        activePage={activePage} 
        onPageChange={setActivePage}
      />

      {/* AI扫描器 */}
      <AIIngredientScanner
        isOpen={showScanner}
        onClose={() => setShowScanner(false)}
        onScanComplete={handleScanComplete}
      />

      {/* 购物清单弹窗 */}
      <ShoppingList 
        items={shoppingItems}
        isOpen={showShoppingList}
        onClose={() => setShowShoppingList(false)}
      />
    </div>
  );
};

export default Index;
