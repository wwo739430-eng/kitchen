-- ==========================================
-- 文件摘要: 更新食材存放位置选项
-- 
-- 变更说明:
-- 1. 添加调料作为新的存放位置选项
-- 2. 更新现有数据的存放位置名称
-- 
-- 注意事项:
-- - 将"冰箱"改为"冷藏"更符合专业分类
-- - 添加"调料"分类用于调味品管理
-- ==========================================

-- 注意：这个迁移文件用于说明数据结构变更
-- 实际的约束检查在应用层完成

-- 如果需要，可以更新现有数据的存放位置名称
UPDATE ingredients 
SET storage_location = '冷藏' 
WHERE storage_location = '冰箱';

UPDATE ingredients 
SET storage_location = '常温' 
WHERE storage_location NOT IN ('冷藏', '冷冻', '常温', '调料') 
   OR storage_location IS NULL;
