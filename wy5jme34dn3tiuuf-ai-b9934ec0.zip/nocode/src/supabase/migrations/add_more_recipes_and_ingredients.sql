-- ==========================================
-- 文件摘要: 添加更多菜谱、调料和食材
-- 
-- 变更说明:
-- 1. 添加家常快手菜系列（10-15分钟）
-- 2. 添加更多调料和配菜
-- 3. 添加早餐、汤品、主食系列
-- 4. 丰富食材种类，增加蔬菜、肉类、海鲜
-- ==========================================

-- 家常快手菜系列（适合简餐）
INSERT INTO recipes (name, image, cook_time, calories_tag, mood_type, steps, servings, taste_type, cuisine_type) VALUES
('蒜蓉西兰花', 'https://nocode.meituan.com/photo/search?keyword=garlic-broccoli&width=400&height=300', 8, '低热量', '一般,低落', ARRAY['西兰花掰小朵洗净', '锅中烧水，加少许盐和油，焯烫西兰花1分钟', '捞出过凉水保持翠绿', '锅中爆香蒜末', '放入西兰花快速翻炒，加少许盐调味即可'], 2, 'light', 'home'),
('番茄炒蛋', 'https://nocode.meituan.com/photo/search?keyword=tomato-egg&width=400&height=300', 10, '正常', '开心,一般', ARRAY['番茄洗净切块，鸡蛋打散加少许盐', '热锅凉油，倒入蛋液炒至凝固盛出', '锅中留底油，放入番茄翻炒出汁', '加入炒好的鸡蛋，加少许糖调味翻炒均匀'], 2, 'light', 'home'),
('醋溜白菜', 'https://nocode.meituan.com/photo/search?keyword=vinegar-cabbage&width=400&height=300', 8, '低热量', '一般', ARRAY['白菜洗净切片，帮和叶分开', '锅中放油，爆香干辣椒和蒜末', '先下白菜帮翻炒1分钟', '再下白菜叶，加生抽、醋、盐调味', '大火快速翻炒均匀出锅'], 2, 'sour', 'home'),
('青椒土豆丝', 'https://nocode.meituan.com/photo/search?keyword=pepper-potato&width=400&height=300', 12, '正常', '一般,开心', ARRAY['土豆切丝，用清水冲洗掉淀粉', '青椒切丝，蒜切片', '锅中放油，爆香蒜片', '下土豆丝翻炒2分钟', '加入青椒丝，加盐、醋调味，翻炒均匀'], 2, 'light', 'home'),
('凉拌黄瓜', 'https://nocode.meituan.com/photo/search?keyword=cold-cucumber&width=400&height=300', 5, '低热量', '解馋,开心', ARRAY['黄瓜拍碎切段', '蒜末、生抽、醋、香油、辣椒油调成汁', '将料汁倒在黄瓜上', '拌匀腌制5分钟即可'], 2, 'spicy', 'home'),
('煎蛋', 'https://nocode.meituan.com/photo/search?keyword=fried-egg&width=400&height=300', 5, '正常', '低落,疲惫', ARRAY['平底锅刷少许油', '打入鸡蛋', '小火煎至蛋白凝固', '撒少许盐和黑胡椒'], 1, 'light', 'home'),
('白灼虾', 'https://nocode.meituan.com/photo/search?keyword=blanched-shrimp&width=400&height=300', 10, '低热量', '开心,一般', ARRAY['虾洗净，剪去虾须', '锅中烧水，加姜片、葱段、料酒', '水开后放入虾', '煮至虾变红弯曲，捞出装盘', '配蘸料：生抽、醋、姜末、香油'], 2, 'light', 'cantonese'),
('蒸蛋羹', 'https://nocode.meituan.com/photo/search?keyword=steamed-egg&width=400&height=300', 12, '正常', '低落,一般', ARRAY['鸡蛋打散，加1.5倍温水搅匀', '过筛去掉泡沫', '盖上保鲜膜，扎几个小孔', '水开后蒸10分钟', '淋上生抽和香油，撒上葱花'], 2, 'light', 'home'),
('炒青菜', 'https://nocode.meituan.com/photo/search?keyword=stir-fry-vegetables&width=400&height=300', 5, '低热量', '一般', ARRAY['青菜洗净沥干', '锅中烧热油，爆香蒜末', '大火快炒青菜', '加盐调味，炒至断生即可'], 2, 'light', 'home'),
('紫菜蛋花汤', 'https://nocode.meituan.com/photo/search?keyword=seaweed-egg-soup&width=400&height=300', 8, '低热量', '一般,低落', ARRAY['紫菜撕碎，用清水泡软', '锅中加水烧开', '放入紫菜煮1分钟', '淋入打散的蛋液，形成蛋花', '加盐、香油、葱花调味'], 2, 'light', 'home');

-- 调料和配菜系列
INSERT INTO recipes (name, image, cook_time, calories_tag, mood_type, steps, servings, taste_type, cuisine_type) VALUES
('蒜蓉酱', 'https://nocode.meituan.com/photo/search?keyword=garlic-sauce&width=400&height=300', 10, '高热量', '解馋', ARRAY['大蒜剁成蒜蓉', '锅中放油，小火慢炒一半蒜蓉至金黄', '加入另一半生蒜蓉', '加盐、糖、生抽调味', '晾凉后装瓶保存'], 10, 'spicy', 'sauce'),
('辣椒油', 'https://nocode.meituan.com/photo/search?keyword=chili-oil&width=400&height=300', 15, '高热量', '解馋', ARRAY['干辣椒剪成段，去籽', '花椒、八角、桂皮炒香', '油烧至七成热', '分三次倒入辣椒中，每次搅拌', '加入熟芝麻，密封浸泡一天'], 10, 'spicy', 'sauce'),
('拍黄瓜', 'https://nocode.meituan.com/photo/search?keyword=smashed-cucumber&width=400&height=300', 5, '低热量', '解馋,开心', ARRAY['黄瓜洗净，用刀拍碎', '切段放入碗中', '加蒜末、生抽、醋、糖、香油', '拌匀腌制10分钟'], 2, 'spicy', 'home'),
('糖蒜', 'https://nocode.meituan.com/photo/search?keyword=sweet-garlic&width=400&height=300', 30, '正常', '解馋', ARRAY['大蒜剥皮，留最内层皮', '用清水泡一天去辣味', '沥干水分', '加白醋、白糖、盐腌制', '密封保存一个月'], 10, 'sweet', 'sauce'),
('泡菜', 'https://nocode.meituan.com/photo/search?keyword=pickled-vegetables&width=400&height=300', 20, '低热量', '解馋', ARRAY['白菜切块，加盐腌制2小时', '沥干水分', '调泡菜水：凉开水、盐、糖、醋、泡椒', '白菜装入容器，倒入泡菜水', '密封腌制3天'], 5, 'sour', 'sauce');

-- 早餐系列
INSERT INTO recipes (name, image, cook_time, calories_tag, mood_type, steps, servings, taste_type, cuisine_type) VALUES
('煎蛋三明治', 'https://nocode.meituan.com/photo/search?keyword=egg-sandwich&width=400&height=300', 10, '正常', '开心,一般', ARRAY['面包片放入烤箱烤脆', '平底锅煎蛋', '番茄切片，生菜洗净', '面包片上抹沙拉酱', '依次放生菜、煎蛋、番茄，盖上另一片面包'], 1, 'light', 'western'),
('鸡蛋灌饼', 'https://nocode.meituan.com/photo/search?keyword=egg-pancake&width=400&height=300', 15, '高热量', '解馋,开心', ARRAY['手抓饼皮放入平底锅', '小火煎至鼓起', '用筷子戳洞，灌入蛋液', '翻面煎至两面金黄', '刷上甜面酱，卷上生菜'], 1, 'light', 'home'),
('牛奶燕麦', 'https://nocode.meituan.com/photo/search?keyword=oatmeal-milk&width=400&height=300', 5, '低热量', '低落,疲惫', ARRAY['燕麦片放入碗中', '倒入热牛奶', '搅拌均匀', '可加入蜂蜜或水果'], 1, 'light', 'western'),
('蛋炒饭', 'https://nocode.meituan.com/photo/search?keyword=fried-rice&width=400&height=300', 12, '高热量', '一般,开心', ARRAY['鸡蛋打散炒熟盛出', '锅中放油，下葱花爆香', '倒入米饭炒散', '加入鸡蛋、盐、生抽调味', '翻炒均匀撒上葱花'], 1, 'light', 'home'),
('豆浆油条', 'https://nocode.meituan.com/photo/search?keyword=soy-milk&width=400&height=300', 5, '高热量', '开心,解馋', ARRAY['黄豆提前泡发', '用豆浆机打成豆浆', '过滤煮沸', '搭配油条食用'], 2, 'light', 'home');

-- 汤品系列
INSERT INTO recipes (name, image, cook_time, calories_tag, mood_type, steps, servings, taste_type, cuisine_type) VALUES
('番茄蛋花汤', 'https://nocode.meituan.com/photo/search?keyword=tomato-egg-soup&width=400&height=300', 10, '低热量', '一般,低落', ARRAY['番茄切块，鸡蛋打散', '锅中放油炒番茄出汁', '加水烧开', '淋入蛋液形成蛋花', '加盐、香油调味'], 2, 'light', 'home'),
('玉米排骨汤', 'https://nocode.meituan.com/photo/search?keyword=corn-pork-rib-soup&width=400&height=300', 60, '正常', '低落,一般', ARRAY['排骨焯水去血沫', '玉米切段', '锅中加水，放入排骨、姜片', '大火烧开转小火煮40分钟', '加入玉米煮20分钟', '加盐调味'], 3, 'light', 'home'),
('冬瓜丸子汤', 'https://nocode.meituan.com/photo/search?keyword=winter-melon-meatball-soup&width=400&height=300', 30, '低热量', '一般', ARRAY['猪肉馅加蛋清、淀粉、盐搅打上劲', '冬瓜去皮切块', '锅中烧水，放入姜片', '水开后挤入肉丸', '加入冬瓜煮至透明', '加盐、香油调味'], 3, 'light', 'home'),
('酸辣汤', 'https://nocode.meituan.com/photo/search?keyword=hot-sour-soup&width=400&height=300', 15, '正常', '解馋,压力大', ARRAY['豆腐、木耳、香菇切丝', '锅中加水烧开', '放入所有食材煮5分钟', '加盐、醋、胡椒粉、生抽调味', '淋入蛋液，撒上香菜'], 2, 'sour', 'sichuan'),
('鲫鱼豆腐汤', 'https://nocode.meituan.com/photo/search?keyword=crucian-tofu-soup&width=400&height=300', 40, '正常', '低落,一般', ARRAY['鲫鱼处理干净，两面煎至金黄', '加入开水、姜片', '大火烧开转小火煮20分钟', '加入豆腐块煮10分钟', '加盐、白胡椒粉调味'], 2, 'light', 'home');

-- 添加食材关联数据 - 家常快手菜
INSERT INTO recipe_ingredients (recipe_id, ingredient_name, amount, is_main) VALUES
(43, '西兰花', '1颗', true),
(43, '大蒜', '5瓣', false),
(44, '番茄', '2个', true),
(44, '鸡蛋', '3个', true),
(44, '糖', '1勺', false),
(45, '白菜', '半颗', true),
(45, '干辣椒', '3个', false),
(45, '醋', '2勺', false),
(46, '土豆', '2个', true),
(46, '青椒', '1个', false),
(46, '醋', '1勺', false),
(47, '黄瓜', '2根', true),
(47, '辣椒油', '1勺', false),
(48, '鸡蛋', '2个', true),
(48, '油', '适量', false),
(49, '虾', '300克', true),
(49, '姜', '3片', false),
(49, '料酒', '2勺', false),
(50, '鸡蛋', '2个', true),
(50, '温水', '适量', false),
(51, '青菜', '300克', true),
(51, '大蒜', '3瓣', false),
(52, '紫菜', '10克', true),
(52, '鸡蛋', '2个', true),
(52, '香油', '1勺', false);

-- 调料系列食材
INSERT INTO recipe_ingredients (recipe_id, ingredient_name, amount, is_main) VALUES
(53, '大蒜', '2头', true),
(53, '油', '200ml', false),
(54, '干辣椒', '100克', true),
(54, '花椒', '20克', false),
(54, '芝麻', '30克', false),
(55, '黄瓜', '2根', true),
(55, '辣椒油', '2勺', false),
(56, '大蒜', '500克', true),
(56, '白醋', '300ml', false),
(56, '白糖', '200克', false),
(57, '白菜', '1颗', true),
(57, '泡椒', '50克', false);

-- 早餐系列食材
INSERT INTO recipe_ingredients (recipe_id, ingredient_name, amount, is_main) VALUES
(58, '面包', '2片', true),
(58, '鸡蛋', '1个', true),
(58, '生菜', '2片', false),
(58, '番茄', '2片', false),
(59, '手抓饼', '1张', true),
(59, '鸡蛋', '1个', true),
(59, '生菜', '2片', false),
(60, '燕麦', '50克', true),
(60, '牛奶', '250ml', true),
(61, '米饭', '1碗', true),
(61, '鸡蛋', '2个', true),
(61, '葱花', '适量', false),
(62, '黄豆', '100克', true),
(62, '油条', '2根', true);

-- 汤品系列食材
INSERT INTO recipe_ingredients (recipe_id, ingredient_name, amount, is_main) VALUES
(63, '番茄', '2个', true),
(63, '鸡蛋', '2个', true),
(64, '排骨', '500克', true),
(64, '玉米', '1根', true),
(65, '猪肉馅', '200克', true),
(65, '冬瓜', '300克', true),
(66, '豆腐', '1块', true),
(66, '木耳', '10克', false),
(66, '醋', '3勺', false),
(66, '胡椒粉', '适量', false),
(67, '鲫鱼', '1条', true),
(67, '豆腐', '1块', false),
(67, '姜', '3片', false);

-- 添加更多食材类型到ingredients表（作为示例数据）
INSERT INTO ingredients (name, image, quantity, expiry_days, storage_location, user_id) VALUES
('生抽', 'https://nocode.meituan.com/photo/search?keyword=soy-sauce&width=200&height=200', '1瓶', 365, '调料', ''),
('老抽', 'https://nocode.meituan.com/photo/search?keyword=dark-soy-sauce&width=200&height=200', '1瓶', 365, '调料', ''),
('料酒', 'https://nocode.meituan.com/photo/search?keyword=cooking-wine&width=200&height=200', '1瓶', 365, '调料', ''),
('醋', 'https://nocode.meituan.com/photo/search?keyword=vinegar&width=200&height=200', '1瓶', 365, '调料', ''),
('蚝油', 'https://nocode.meituan.com/photo/search?keyword=oyster-sauce&width=200&height=200', '1瓶', 180, '调料', ''),
('香油', 'https://nocode.meituan.com/photo/search?keyword=sesame-oil&width=200&height=200', '1瓶', 365, '调料', ''),
('盐', 'https://nocode.meituan.com/photo/search?keyword=salt&width=200&height=200', '1袋', 730, '调料', ''),
('糖', 'https://nocode.meituan.com/photo/search?keyword=sugar&width=200&height=200', '1袋', 365, '调料', ''),
('胡椒粉', 'https://nocode.meituan.com/photo/search?keyword=pepper&width=200&height=200', '1瓶', 365, '调料', ''),
('花椒', 'https://nocode.meituan.com/photo/search?keyword=sichuan-pepper&width=200&height=200', '50克', 365, '调料', ''),
('八角', 'https://nocode.meituan.com/photo/search?keyword=star-anise&width=200&height=200', '20克', 365, '调料', ''),
('桂皮', 'https://nocode.meituan.com/photo/search?keyword=cinnamon&width=200&height=200', '10克', 365, '调料', ''),
('干辣椒', 'https://nocode.meituan.com/photo/search?keyword=dried-chili&width=200&height=200', '50克', 180, '调料', ''),
('豆瓣酱', 'https://nocode.meituan.com/photo/search?keyword=bean-paste&width=200&height=200', '1瓶', 365, '调料', ''),
('甜面酱', 'https://nocode.meituan.com/photo/search?keyword=sweet-bean-sauce&width=200&height=200', '1瓶', 180, '调料', ''),
('番茄酱', 'https://nocode.meituan.com/photo/search?keyword=ketchup&width=200&height=200', '1瓶', 365, '调料', ''),
('沙拉酱', 'https://nocode.meituan.com/photo/search?keyword=salad-dressing&width=200&height=200', '1瓶', 90, '调料', ''),
('芝麻酱', 'https://nocode.meituan.com/photo/search?keyword=sesame-paste&width=200&height=200', '1瓶', 180, '调料', ''),
('咖喱块', 'https://nocode.meituan.com/photo/search?keyword=curry-cube&width=200&height=200', '1盒', 365, '调料', ''),
('火锅底料', 'https://nocode.meituan.com/photo/search?keyword=hotpot-base&width=200&height=200', '1袋', 365, '调料', ''),
('淀粉', 'https://nocode.meituan.com/photo/search?keyword=starch&width=200&height=200', '1袋', 365, '调料', ''),
('面粉', 'https://nocode.meituan.com/photo/search?keyword=flour&width=200&height=200', '1袋', 180, '常温', ''),
('大米', 'https://nocode.meituan.com/photo/search?keyword=rice&width=200&height=200', '5公斤', 365, '常温', ''),
('面条', 'https://nocode.meituan.com/photo/search?keyword=noodles&width=200&height=200', '500克', 180, '常温', ''),
('意大利面', 'https://nocode.meituan.com/photo/search?keyword=spaghetti&width=200&height=200', '500克', 365, '常温', ''),
('燕麦', 'https://nocode.meituan.com/photo/search?keyword=oats&width=200&height=200', '1袋', 180, '常温', ''),
('面包', 'https://nocode.meituan.com/photo/search?keyword=bread&width=200&height=200', '1袋', 7, '常温', '');
