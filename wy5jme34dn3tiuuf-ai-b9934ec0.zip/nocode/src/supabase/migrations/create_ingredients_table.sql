-- ==========================================
-- 文件摘要: 创建食材管理相关数据表
-- 
-- 变更说明:
-- 1. 创建食材表(ingredients)存储用户食材信息
-- 2. 创建菜谱表(recipes)存储菜谱信息
-- 3. 创建用户偏好表(user_preferences)存储用户设置
-- 4. 创建菜谱食材关联表(recipe_ingredients)管理多对多关系
-- 
-- 表结构描述:
-- - ingredients: 食材基础信息，包含名称、保质期、存放位置等
-- - recipes: 菜谱信息，包含菜名、步骤、烹饪时间、热量标签等
-- - user_preferences: 用户心情偏好、饮食目标、用餐人数等
-- - recipe_ingredients: 菜谱所需食材及用量关联表
-- 
-- 注意事项:
-- - 所有表均使用IF NOT EXISTS防止重复创建
-- - 严禁使用外键约束
-- - 包含适当的默认值设置
-- ==========================================

-- 创建食材表
CREATE TABLE IF NOT EXISTS ingredients (
    id BIGSERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    image VARCHAR(500) DEFAULT '',
    quantity VARCHAR(50) DEFAULT '',
    expiry_days INTEGER DEFAULT 7,
    storage_location VARCHAR(50) DEFAULT '常温',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    user_id VARCHAR(100) DEFAULT ''
);

-- 创建菜谱表
CREATE TABLE IF NOT EXISTS recipes (
    id BIGSERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    image VARCHAR(500) DEFAULT '',
    cook_time INTEGER DEFAULT 30,
    calories_tag VARCHAR(20) DEFAULT '正常',
    mood_type VARCHAR(50) DEFAULT '一般',
    steps TEXT[] DEFAULT '{}',
    servings INTEGER DEFAULT 2,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 创建菜谱食材关联表
CREATE TABLE IF NOT EXISTS recipe_ingredients (
    id BIGSERIAL PRIMARY KEY,
    recipe_id INTEGER DEFAULT 0,
    ingredient_name VARCHAR(100) NOT NULL,
    amount VARCHAR(50) DEFAULT '',
    is_main BOOLEAN DEFAULT false
);

-- 创建用户偏好表
CREATE TABLE IF NOT EXISTS user_preferences (
    id BIGSERIAL PRIMARY KEY,
    user_id VARCHAR(100) DEFAULT '',
    current_mood VARCHAR(20) DEFAULT '一般',
    diet_goal VARCHAR(20) DEFAULT '正常饮食',
    servings INTEGER DEFAULT 2,
    allow_shopping BOOLEAN DEFAULT true,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 插入示例菜谱数据
INSERT INTO recipes (name, image, cook_time, calories_tag, mood_type, steps, servings) VALUES
('番茄炒蛋', 'https://nocode.meituan.com/photo/search?keyword=tomato-egg&width=400&height=300', 15, '正常', '开心,一般', ARRAY['番茄洗净切块，鸡蛋打散备用', '热锅凉油，倒入蛋液炒至凝固盛出', '锅中留底油，放入番茄翻炒出汁', '加入炒好的鸡蛋，调味翻炒均匀即可'], 2),
('红烧肉', 'https://nocode.meituan.com/photo/search?keyword=braised-pork&width=400&height=300', 60, '高热量', '低落,压力大', ARRAY['五花肉切块焯水备用', '锅中放少许油，加入冰糖炒糖色', '放入肉块翻炒上色', '加入生抽、老抽、料酒和开水', '小火炖煮45分钟，大火收汁即可'], 4),
('清蒸鲈鱼', 'https://nocode.meituan.com/photo/search?keyword=steamed-fish&width=400&height=300', 20, '低热量', '正常饮食', ARRAY['鲈鱼处理干净，两面划刀', '鱼身抹盐和料酒腌制10分钟', '盘中放姜片葱段，放上鱼', '水开后蒸8-10分钟', '倒掉蒸鱼水，淋上蒸鱼豉油和热油'], 2),
('蒜蓉西兰花', 'https://nocode.meituan.com/photo/search?keyword=garlic-broccoli&width=400&height=300', 10, '低热量', '减肥,一般', ARRAY['西兰花掰小朵洗净', '锅中烧水，加少许盐和油，焯烫西兰花', '捞出过凉水保持翠绿', '锅中爆香蒜末', '放入西兰花快速翻炒，调味即可'], 2),
('可乐鸡翅', 'https://nocode.meituan.com/photo/search?keyword=cola-chicken-wings&width=400&height=300', 30, '高热量', '解馋,开心', ARRAY['鸡翅两面划刀，用料酒腌制', '锅中少许油，将鸡翅煎至两面金黄', '倒入可乐没过鸡翅', '加入生抽、老抽调味', '中火炖煮至汤汁浓稠即可'], 3),
('紫菜蛋花汤', 'https://nocode.meituan.com/photo/search?keyword=seaweed-egg-soup&width=400&height=300', 10, '低热量', '一般,低落', ARRAY['紫菜撕小块，用清水泡软', '锅中烧水，放入紫菜', '水开后淋入打散的蛋液', '加入盐和香油调味', '撒上葱花即可出锅'], 2);

-- 插入菜谱食材关联数据
INSERT INTO recipe_ingredients (recipe_id, ingredient_name, amount, is_main) VALUES
(1, '番茄', '2个', true),
(1, '鸡蛋', '3个', true),
(2, '五花肉', '500克', true),
(2, '冰糖', '30克', false),
(3, '鲈鱼', '1条', true),
(3, '姜', '3片', false),
(4, '西兰花', '1颗', true),
(4, '大蒜', '5瓣', false),
(5, '鸡翅', '10个', true),
(5, '可乐', '1罐', true),
(6, '紫菜', '10克', true),
(6, '鸡蛋', '2个', true);
