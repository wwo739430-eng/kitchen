-- ==========================================
-- 文件摘要: 添加八大菜系及各国料理菜谱
-- 
-- 变更说明:
-- 1. 添加八大菜系：川、鲁、粤、苏、闽、浙、湘、徽
-- 2. 添加西餐、韩餐、日餐料理
-- 3. 每个菜系添加2-3道代表性菜品
-- 4. 所有菜谱包含详细烹饪步骤
-- ==========================================

-- 川菜
INSERT INTO recipes (name, image, cook_time, calories_tag, mood_type, steps, servings) VALUES
('麻婆豆腐', 'https://nocode.meituan.com/photo/search?keyword=mapo-tofu&width=400&height=300', 20, '正常', '解馋,开心', ARRAY['嫩豆腐切块，放入加盐的开水中焯烫2分钟捞出', '锅中放油，下肉末炒至变色', '加入豆瓣酱炒出红油，放入姜蒜末爆香', '加入适量清水，放入豆腐中小火烧3分钟', '分三次加入水淀粉勾芡，撒上花椒粉和葱花'], 2),
('宫保鸡丁', 'https://nocode.meituan.com/photo/search?keyword=kungpao-chicken&width=400&height=300', 25, '高热量', '开心,解馋', ARRAY['鸡胸肉切丁，加料酒、生抽、淀粉腌制15分钟', '花生米炸至金黄酥脆备用', '调宫保汁：生抽、老抽、糖、醋、淀粉、水调匀', '热锅凉油，下鸡丁滑炒至变色盛出', '爆香干辣椒和花椒，下鸡丁和葱段翻炒', '倒入宫保汁大火收汁，最后加入花生米拌匀'], 2),
('水煮肉片', 'https://nocode.meituan.com/photo/search?keyword=shuizhu-pork&width=400&height=300', 35, '高热量', '解馋,压力大', ARRAY['猪里脊切薄片，用盐、料酒、蛋清、淀粉抓匀腌制', '豆芽、白菜焯水铺入碗底', '锅中放油，下豆瓣酱和火锅底料炒出红油', '加入清水烧开，下肉片煮至变色', '将肉片和汤倒入碗中，撒上蒜末、辣椒面、花椒', '淋上热油激发出香味，撒葱花即可'], 3);

-- 鲁菜
INSERT INTO recipes (name, image, cook_time, calories_tag, mood_type, steps, servings) VALUES
('糖醋里脊', 'https://nocode.meituan.com/photo/search?keyword=sweet-sour-pork&width=400&height=300', 30, '高热量', '开心,解馋', ARRAY['猪里脊切条，加盐、料酒腌制10分钟', '挂糊：淀粉加鸡蛋调成糊状，里脊裹匀', '油温六成热，下里脊炸至金黄捞出', '调糖醋汁：番茄酱、糖、醋、生抽、水淀粉', '锅中留底油，倒入糖醋汁烧至浓稠', '放入炸好的里脊快速翻炒裹匀酱汁'], 3),
('葱烧海参', 'https://nocode.meituan.com/photo/search?keyword=scallion-sea-cucumber&width=400&height=300', 25, '低热量', '正常饮食,低落', ARRAY['水发海参洗净，切成大片', '大葱切段，炸至金黄捞出，葱油备用', '锅中加高汤，放入海参、料酒、生抽烧入味', '加入炸好的葱段，小火烧5分钟', '勾芡收汁，淋上葱油即可'], 2),
('九转大肠', 'https://nocode.meituan.com/photo/search?keyword=nine-turn-intestine&width=400&height=300', 45, '高热量', '解馋', ARRAY['猪大肠洗净，套叠后焯水', '加葱、姜、料酒煮至八成熟', '锅中放少许油，下大肠煎至两面金黄', '加入糖炒糖色，放调料（盐、醋、胡椒、砂仁、肉桂）', '小火烧30分钟至汤汁浓稠', '出锅前撒香菜末'], 3);

-- 粤菜
INSERT INTO recipes (name, image, cook_time, calories_tag, mood_type, steps, servings) VALUES
('白切鸡', 'https://nocode.meituan.com/photo/search?keyword=white-cut-chicken&width=400&height=300', 40, '低热量', '正常饮食,开心', ARRAY['三黄鸡洗净，鸡脚塞入腹腔', '开水下锅，提着鸡脖子三起三落烫皮', '小火煮15分钟后关火焖10分钟', '捞出立即放入冰水中浸泡至凉透', '斩块装盘，配姜葱蘸料（姜末、葱末、盐、热油）'], 3),
('干炒牛河', 'https://nocode.meituan.com/photo/search?keyword=beef-chow-fun&width=400&height=300', 15, '高热量', '解馋,开心', ARRAY['牛肉切片，加生抽、淀粉、油腌制', '河粉用手轻轻拨散，豆芽洗净', '热锅热油，下牛肉快速滑炒至变色盛出', '锅中再加油，下河粉中小火煎至微焦', '加入豆芽、牛肉、葱段、生抽、老抽快速翻炒', '翻炒均匀后出锅，保持河粉不碎'], 2),
('虾饺', 'https://nocode.meituan.com/photo/search?keyword=shrimp-dumpling&width=400&height=300', 50, '正常', '开心,低落', ARRAY['虾仁去沙线洗净，部分拍成泥，部分切丁', '加盐、糖、胡椒粉、香油拌匀腌制', '澄粉和生粉混合，开水烫面揉成光滑面团', '分成小剂子，擀成薄圆皮', '包入虾馅，捏出褶皱', '蒸笼刷油，大火蒸6分钟即可'], 4);

-- 苏菜
INSERT INTO recipes (name, image, cook_time, calories_tag, mood_type, steps, servings) VALUES
('松鼠桂鱼', 'https://nocode.meituan.com/photo/search?keyword=squirrel-fish&width=400&height=300', 40, '高热量', '开心,解馋', ARRAY['桂鱼去骨，鱼肉切菱形花刀，不要切断', '加盐、料酒腌制，裹上干淀粉', '油温七成热，手提鱼尾炸至定型', '翻面炸至金黄酥脆捞出装盘', '锅中留底油，下番茄酱、糖、醋、水烧开', '勾芡后淋在鱼身上，撒上松子'], 3),
('狮子头', 'https://nocode.meituan.com/photo/search?keyword=lion-head-meatball&width=400&height=300', 60, '高热量', '低落,解馋', ARRAY['五花肉切成小丁，不要剁太碎', '加葱姜水、盐、料酒、蛋清、淀粉顺一个方向搅打上劲', '锅中放水，将肉馅团成大丸子，小火慢煮', '定型后捞出，另起锅加高汤和丸子', '小火炖1小时，加入青菜心即可'], 4),
('盐水鸭', 'https://nocode.meituan.com/photo/search?keyword=salted-duck&width=400&height=300', 120, '正常', '正常饮食', ARRAY['鸭子洗净，花椒盐均匀涂抹内外', '放入冰箱腌制24小时', '洗去表面盐粒，冷水下锅加葱姜料酒', '小火煮40分钟，关火焖20分钟', '捞出晾凉，斩块装盘'], 4);

-- 闽菜
INSERT INTO recipes (name, image, cook_time, calories_tag, mood_type, steps, servings) VALUES
('佛跳墙', 'https://nocode.meituan.com/photo/search?keyword=buddha-jumps-wall&width=400&height=300', 180, '高热量', '开心,压力大', ARRAY['鲍鱼、海参、鱼翅、干贝提前泡发', '排骨、鸡块焯水备用', '猪肚、蹄筋处理干净切小块', '所有食材分层放入炖盅', '加入高汤、花雕酒、姜片', '密封炖盅，小火慢炖3小时', '最后加盐调味即可'], 6),
('荔枝肉', 'https://nocode.meituan.com/photo/search?keyword=litchi-pork&width=400&height=300', 30, '高热量', '解馋,开心', ARRAY['猪瘦肉切十字花刀，切成菱形块', '加盐、料酒腌制，裹上淀粉', '油温六成热，炸至金黄酥脆', '土豆切块炸至金黄', '调汁：番茄酱、糖、醋、生抽、水淀粉', '锅中留底油，倒入汁料烧至浓稠', '放入肉和土豆快速翻炒均匀'], 3),
('沙茶面', 'https://nocode.meituan.com/photo/search?keyword=satay-noodles&width=400&height=300', 25, '正常', '低落,解馋', ARRAY['碱水面煮熟捞出', '准备配料：豆芽、青菜、虾仁、肉片', '锅中加水烧开，放入沙茶酱调匀', '依次放入配料煮熟', '将面条放入碗中，浇上沙茶汤', '撒上蒜末、香菜、辣椒油'], 2);

-- 浙菜
INSERT INTO recipes (name, image, cook_time, calories_tag, mood_type, steps, servings) VALUES
('西湖醋鱼', 'https://nocode.meituan.com/photo/search?keyword=west-lake-vinegar-fish&width=400&height=300', 30, '正常', '低落,正常饮食', ARRAY['草鱼洗净，从背部剖开，尾部相连', '锅中加水加葱姜料酒烧开', '手提鱼头，将鱼身入水烫一下定型', '整条鱼入锅小火煮3分钟', '捞出装盘，淋上糖醋汁（糖、醋、生抽、水淀粉）', '撒上姜末即可'], 2),
('东坡肉', 'https://nocode.meituan.com/photo/search?keyword=dongpo-pork&width=400&height=300', 120, '高热量', '解馋,开心', ARRAY['五花肉切块，焯水去血沫', '砂锅底铺姜片和葱段', '肉皮朝下码放整齐', '加料酒、生抽、老抽、冰糖、八角', '加水没过肉块，大火烧开转小火', '炖煮1.5小时，大火收汁即可'], 4),
('龙井虾仁', 'https://nocode.meituan.com/photo/search?keyword=longjing-shrimp&width=400&height=300', 15, '低热量', '正常饮食,开心', ARRAY['虾仁去沙线洗净，吸干水分', '加盐、蛋清、淀粉抓匀上浆', '龙井茶泡开，取茶汤备用', '热锅凉油，下虾仁滑炒至变色', '倒入茶汤，加盐调味', '翻炒均匀后出锅，可点缀茶叶'], 2);

-- 湘菜
INSERT INTO recipes (name, image, cook_time, calories_tag, mood_type, steps, servings) VALUES
('剁椒鱼头', 'https://nocode.meituan.com/photo/search?keyword=chopped-chili-fish-head&width=400&height=300', 25, '正常', '解馋,压力大', ARRAY['鱼头处理干净，对半切开不切断', '加料酒、盐腌制15分钟', '盘底铺姜片葱段，放上鱼头', '均匀铺上剁椒和野山椒', '蒸锅水开后放入，大火蒸15分钟', '取出撒上葱花，淋上热油'], 3),
('辣椒炒肉', 'https://nocode.meituan.com/photo/search?keyword=hunan-pepper-pork&width=400&height=300', 15, '高热量', '解馋,开心', ARRAY['五花肉切片，螺丝椒切滚刀块', '干锅不放油，下辣椒煸至虎皮盛出', '锅中少许油，下肉片煸炒出油', '加入蒜末、豆豉爆香', '倒入辣椒，加生抽、老抽、糖调味', '大火快速翻炒均匀'], 2),
('口味虾', 'https://nocode.meituan.com/photo/search?keyword=hunan-crayfish&width=400&height=300', 40, '高热量', '解馋,开心', ARRAY['小龙虾刷洗干净，去虾线', '油温七成热，下小龙虾炸至变红', '锅中留油，下大量蒜末、姜末、干辣椒、花椒爆香', '加入豆瓣酱炒出红油', '倒入小龙虾，加啤酒没过', '大火烧开转小火煮15分钟，关火浸泡入味'], 3);

-- 徽菜
INSERT INTO recipes (name, image, cook_time, calories_tag, mood_type, steps, servings) VALUES
('臭鳜鱼', 'https://nocode.meituan.com/photo/search?keyword=stinky-mandarin-fish&width=400&height=300', 30, '正常', '解馋', ARRAY['腌制好的臭鳜鱼洗净', '两面煎至金黄盛出', '锅中爆香姜蒜末、干辣椒', '加入生抽、糖、料酒、水烧开', '放入鱼小火烧10分钟', '大火收汁，撒上葱花'], 2),
('胡适一品锅', 'https://nocode.meituan.com/photo/search?keyword=hu-shi-pot&width=400&height=300', 60, '高热量', '开心,低落', ARRAY['锅底铺白菜、粉丝', '依次码放炸豆腐、肉圆、蛋饺、鸡肉、鸭肉', '加入高汤、料酒、生抽', '大火烧开转小火炖煮40分钟', '最后加盐调味，撒上香菜'], 4),
('毛豆腐', 'https://nocode.meituan.com/photo/search?keyword=mao-tofu&width=400&height=300', 20, '正常', '解馋', ARRAY['毛豆腐洗净，切成厚片', '平底锅刷油，小火煎至两面金黄', '撒上盐、胡椒粉、辣椒粉', '淋上香油，撒上葱花'], 2);

-- 西餐
INSERT INTO recipes (name, image, cook_time, calories_tag, mood_type, steps, servings) VALUES
('奶油蘑菇汤', 'https://nocode.meituan.com/photo/search?keyword=cream-mushroom-soup&width=400&height=300', 30, '高热量', '低落,解馋', ARRAY['口蘑切片，洋葱切碎', '锅中融化黄油，下洋葱炒香', '加入蘑菇炒软', '撒入面粉炒匀', '分次加入牛奶和鸡汤，不停搅拌', '小火煮至浓稠，加盐、黑胡椒调味', '最后加入淡奶油搅匀'], 2),
('煎牛排', 'https://nocode.meituan.com/photo/search?keyword=pan-seared-steak&width=400&height=300', 15, '正常', '开心,解馋', ARRAY['牛排室温放置30分钟，两面撒盐和黑胡椒', '锅烧至冒烟，加入植物油', '放入牛排，每面煎2-3分钟', '加入黄油、大蒜、百里香', '将融化的黄油淋在牛排上', '取出静置5分钟后切块'], 1),
('意大利肉酱面', 'https://nocode.meituan.com/photo/search?keyword=spaghetti-bolognese&width=400&height=300', 45, '高热量', '开心,低落', ARRAY['洋葱、胡萝卜、芹菜切碎', '锅中炒香洋葱碎，加入牛肉末炒散', '加入胡萝卜、芹菜继续翻炒', '倒入番茄罐头和红酒', '小火慢炖30分钟，加盐、糖、黑胡椒调味', '意面煮熟，拌入肉酱，撒上芝士粉'], 2),
('凯撒沙拉', 'https://nocode.meituan.com/photo/search?keyword=caesar-salad&width=400&height=300', 10, '低热量', '减肥,正常饮食', ARRAY['罗马生菜洗净撕成小块', '面包丁烤箱180度烤5分钟至酥脆', '制作凯撒酱：蛋黄酱、帕玛森芝士、柠檬汁、蒜泥、黑胡椒', '生菜放入大碗，倒入酱汁拌匀', '撒上面包丁和额外的芝士片', '可加入烤鸡胸肉增加蛋白质'], 1);

-- 韩餐
INSERT INTO recipes (name, image, cook_time, calories_tag, mood_type, steps, servings) VALUES
('韩式拌饭', 'https://nocode.meituan.com/photo/search?keyword=bibimbap&width=400&height=300', 30, '正常', '开心,一般', ARRAY['米饭煮好保温', '胡萝卜、黄瓜、豆芽、菠菜分别焯水调味', '牛肉切丝加生抽、糖、蒜末炒熟', '煎一个太阳蛋', '所有配菜码在米饭上，中间放蛋', '加入韩式辣酱，拌匀即可食用'], 1),
('泡菜汤', 'https://nocode.meituan.com/photo/search?keyword=kimchi-stew&width=400&height=300', 25, '正常', '低落,解馋', ARRAY['五花肉切片，辣白菜切段', '锅中放少许油，炒香五花肉', '加入辣白菜翻炒', '加入韩式辣酱、生抽、糖', '倒入淘米水烧开', '加入豆腐块、洋葱丝', '小火煮15分钟，撒葱花'], 2),
('韩式炸鸡', 'https://nocode.meituan.com/photo/search?keyword=korean-fried-chicken&width=400&height=300', 40, '高热量', '解馋,开心', ARRAY['鸡翅加盐、黑胡椒、料酒腌制', '裹上淀粉，油温六成热炸至金黄', '升高油温复炸一次至酥脆', '制作酱汁：韩式辣酱、番茄酱、蜂蜜、蒜末、水', '锅中倒入酱汁烧至浓稠', '放入炸鸡裹匀酱汁，撒花生碎'], 2),
('石锅拌饭', 'https://nocode.meituan.com/photo/search?keyword=dolsot-bibimbap&width=400&height=300', 35, '正常', '开心,解馋', ARRAY['石锅刷油，放入米饭铺平', '各种配菜分别炒熟调味', '将配菜码在米饭上', '中间放一个生蛋黄', '石锅上火加热至发出滋滋声', '淋上香油和韩式辣酱，拌匀食用'], 1);

-- 日餐
INSERT INTO recipes (name, image, cook_time, calories_tag, mood_type, steps, servings) VALUES
('日式咖喱饭', 'https://nocode.meituan.com/photo/search?keyword=japanese-curry&width=400&height=300', 40, '正常', '低落,开心', ARRAY['洋葱切丝，土豆胡萝卜切小块', '鸡肉或牛肉切块', '锅中炒香洋葱至金黄', '加入肉块炒变色', '加入土豆、胡萝卜翻炒', '加水没过食材，大火烧开转小火煮20分钟', '关火，加入咖喱块搅拌融化', '小火煮至浓稠，浇在米饭上'], 2),
('照烧鸡腿', 'https://nocode.meituan.com/photo/search?keyword=teriyaki-chicken&width=400&height=300', 25, '正常', '开心,解馋', ARRAY['鸡腿去骨，用刀背拍松', '加盐、黑胡椒、料酒腌制', '调照烧汁：生抽、味淋、糖', '平底锅少油，鸡皮朝下煎至金黄', '翻面继续煎，倒入照烧汁', '小火收汁，将酱汁裹在鸡肉上', '切块装盘，撒白芝麻'], 2),
('寿司卷', 'https://nocode.meituan.com/photo/search?keyword=sushi-roll&width=400&height=300', 30, '低热量', '开心,正常饮食', ARRAY['寿司醋加入热米饭中拌匀晾凉', '寿司帘上铺海苔，光面朝下', '手上沾水，将米饭均匀铺在海苔上', '翻面，米饭朝下', '放上黄瓜条、蟹肉棒、玉子烧', '卷起寿司帘，用力压实', '切成6-8块，摆盘'], 2),
('味噌汤', 'https://nocode.meituan.com/photo/search?keyword=miso-soup&width=400&height=300', 10, '低热量', '低落,正常饮食', ARRAY['豆腐切小块，海带泡软', '锅中加水和昆布煮开，捞出昆布', '加入豆腐、海带、葱花', '取适量味噌放在漏勺中，浸入汤中用筷子搅拌化开', '汤将开未开时关火', '撒上葱花即可'], 1);

-- 添加所有菜谱的食材关联数据
INSERT INTO recipe_ingredients (recipe_id, ingredient_name, amount, is_main) VALUES
-- 川菜
(7, '嫩豆腐', '1块', true),
(7, '猪肉末', '100克', true),
(7, '豆瓣酱', '2勺', false),
(7, '花椒粉', '适量', false),
(8, '鸡胸肉', '300克', true),
(8, '花生米', '50克', true),
(8, '干辣椒', '10个', false),
(9, '猪里脊', '300克', true),
(9, '豆芽', '200克', true),
(9, '豆瓣酱', '2勺', false),
-- 鲁菜
(10, '猪里脊', '300克', true),
(10, '淀粉', '适量', false),
(10, '番茄酱', '3勺', false),
(11, '海参', '4只', true),
(11, '大葱', '2根', true),
(12, '猪大肠', '500克', true),
(12, '八角', '2个', false),
-- 粤菜
(13, '三黄鸡', '1只', true),
(13, '姜', '1块', false),
(13, '葱', '3根', false),
(14, '河粉', '300克', true),
(14, '牛肉', '150克', true),
(14, '豆芽', '100克', false),
(15, '虾仁', '300克', true),
(15, '澄粉', '150克', true),
-- 苏菜
(16, '桂鱼', '1条', true),
(16, '番茄酱', '3勺', false),
(16, '松子', '20克', false),
(17, '五花肉', '500克', true),
(17, '青菜', '4颗', false),
(18, '鸭子', '1只', true),
(18, '花椒', '20克', false),
-- 闽菜
(19, '鲍鱼', '4只', true),
(19, '海参', '2只', true),
(19, '排骨', '200克', false),
(20, '猪瘦肉', '300克', true),
(20, '土豆', '2个', true),
(20, '番茄酱', '3勺', false),
(21, '碱水面', '200克', true),
(21, '沙茶酱', '3勺', true),
-- 浙菜
(22, '草鱼', '1条', true),
(22, '醋', '3勺', false),
(23, '五花肉', '800克', true),
(23, '冰糖', '50克', false),
(24, '虾仁', '300克', true),
(24, '龙井茶', '10克', false),
-- 湘菜
(25, '鱼头', '1个', true),
(25, '剁椒', '100克', true),
(25, '野山椒', '30克', false),
(26, '五花肉', '200克', true),
(26, '螺丝椒', '200克', true),
(26, '豆豉', '1勺', false),
(27, '小龙虾', '1斤', true),
(27, '啤酒', '1罐', false),
-- 徽菜
(28, '臭鳜鱼', '1条', true),
(28, '干辣椒', '10个', false),
(29, '白菜', '200克', true),
(29, '粉丝', '100克', true),
(29, '蛋饺', '6个', false),
(30, '毛豆腐', '8块', true),
(30, '辣椒粉', '适量', false),
-- 西餐
(31, '口蘑', '200克', true),
(31, '洋葱', '半个', false),
(31, '淡奶油', '100ml', false),
(32, '牛排', '200克', true),
(32, '黄油', '20克', false),
(33, '意大利面', '200克', true),
(33, '牛肉末', '200克', true),
(33, '番茄罐头', '1罐', false),
(34, '罗马生菜', '1颗', true),
(34, '面包', '2片', false),
(34, '帕玛森芝士', '30克', false),
-- 韩餐
(35, '米饭', '1碗', true),
(35, '辣白菜', '100克', true),
(35, '牛肉', '100克', false),
(36, '五花肉', '150克', true),
(36, '豆腐', '1块', false),
(37, '鸡翅', '10个', true),
(37, '韩式辣酱', '3勺', false),
(38, '米饭', '1碗', true),
(38, '鸡蛋', '1个', true),
-- 日餐
(39, '土豆', '2个', true),
(39, '胡萝卜', '1根', false),
(39, '咖喱块', '4块', true),
(40, '鸡腿', '2个', true),
(40, '味淋', '2勺', false),
(41, '海苔', '2张', true),
(41, '蟹肉棒', '4根', false),
(42, '豆腐', '半块', true),
(42, '味噌', '2勺', true);
