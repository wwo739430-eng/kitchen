-- ==========================================
-- 文件摘要: 添加更多带调料关联的菜谱
-- 
-- 变更说明:
-- 1. 添加以调料为特色的菜谱
-- 2. 确保每道菜谱都关联常用调料
-- 3. 添加调料密集型菜谱（如卤味、酱料菜）
-- ==========================================

-- 添加卤味系列（调料密集型）
INSERT INTO recipes (name, image, cook_time, calories_tag, mood_type, steps, servings) VALUES
('卤牛肉', 'https://nocode.meituan.com/photo/search?keyword=braised-beef&width=400&height=300', 120, '高热量', '解馋,压力大', ARRAY['牛腱子肉洗净，冷水下锅焯水去血沫', '锅中加水，放入八角、桂皮、香叶、花椒、干辣椒', '加入生抽、老抽、料酒、冰糖、姜片', '放入牛肉，大火烧开转小火煮1.5小时', '关火浸泡2小时入味', '切片装盘，可配蒜泥醋汁'], 4),
('卤鸡蛋', 'https://nocode.meituan.com/photo/search?keyword=braised-egg&width=400&height=300', 40, '正常', '一般,解馋', ARRAY['鸡蛋煮熟剥壳', '锅中加水，放入八角、桂皮、香叶、茶叶', '加入生抽、老抽、冰糖', '放入鸡蛋，大火烧开转小火煮20分钟', '关火浸泡过夜更入味'], 6),
('卤豆腐干', 'https://nocode.meituan.com/photo/search?keyword=braised-tofu&width=400&height=300', 30, '正常', '解馋', ARRAY['豆腐干洗净切小块', '锅中加水，放入八角、桂皮、香叶', '加入生抽、老抽、料酒、冰糖', '放入豆腐干，大火烧开转小火煮15分钟', '关火浸泡入味'], 4),
('五香花生', 'https://nocode.meituan.com/photo/search?keyword=five-spice-peanut&width=400&height=300', 30, '正常', '解馋,开心', ARRAY['花生洗净，加水浸泡2小时', '锅中加水，放入八角、桂皮、香叶、花椒', '加入盐、五香粉', '放入花生，大火煮开转小火煮20分钟', '关火浸泡入味，沥干水分'], 4);

-- 添加酱料特色菜
INSERT INTO recipes (name, image, cook_time, calories_tag, mood_type, steps, servings) VALUES
('麻酱拌面', 'https://nocode.meituan.com/photo/search?keyword=sesame-paste-noodles&width=400&height=300', 10, '高热量', '低落,疲惫', ARRAY['芝麻酱加温水调稀', '加入生抽、醋、糖、蒜泥、香油调匀', '面条煮熟过凉水', '黄瓜切丝', '将酱汁浇在面条上，铺上黄瓜丝拌匀'], 1),
('酱油炒饭', 'https://nocode.meituan.com/photo/search?keyword=soy-sauce-fried-rice&width=400&height=300', 8, '高热量', '一般', ARRAY['隔夜米饭打散', '锅中放油，爆香葱花', '倒入米饭炒散', '加入生抽、老抽翻炒均匀', '撒上葱花出锅'], 1),
('醋溜土豆丝', 'https://nocode.meituan.com/photo/search?keyword=vinegar-shredded-potato&width=400&height=300', 8, '正常', '一般', ARRAY['土豆切丝，用清水冲洗掉淀粉', '锅中放油，爆香干辣椒和蒜片', '倒入土豆丝大火快炒', '加入醋、盐、糖调味', '翻炒均匀出锅'], 2),
('蚝油生菜', 'https://nocode.meituan.com/photo/search?keyword=oyster-sauce-lettuce&width=400&height=300', 5, '低热量', '一般,低落', ARRAY['生菜洗净', '锅中烧水，加少许油盐', '生菜焯水30秒捞出装盘', '淋上蚝油和热油'], 2),
('黑胡椒牛柳', 'https://nocode.meituan.com/photo/search?keyword=black-pepper-beef-strips&width=400&height=300', 15, '正常', '开心,解馋', ARRAY['牛肉切条，加盐、黑胡椒、淀粉腌制', '洋葱、青椒切丝', '热锅热油，滑炒牛肉变色盛出', '爆香洋葱青椒', '倒入牛肉，加黑椒酱翻炒均匀'], 2);

-- 添加快手调料菜（10分钟内）
INSERT INTO recipes (name, image, cook_time, calories_tag, mood_type, steps, servings) VALUES
('蒜蓉蒸茄子', 'https://nocode.meituan.com/photo/search?keyword=garlic-steamed-eggplant&width=400&height=300', 10, '低热量', '一般', ARRAY['茄子切条', '上锅蒸8分钟至软', '取出撕成条', '淋上蒜蓉、生抽、香油调成的汁', '撒上葱花'], 2),
('凉拌木耳黄瓜', 'https://nocode.meituan.com/photo/search?keyword=cold-wood-ear-cucumber&width=400&height=300', 8, '低热量', '解馋', ARRAY['木耳泡发焯水', '黄瓜拍碎切段', '加入蒜末、生抽、醋、辣椒油、香油', '拌匀腌制10分钟'], 2),
('姜汁菠菜', 'https://nocode.meituan.com/photo/search?keyword=ginger-spinach&width=400&height=300', 8, '低热量', '低落', ARRAY['菠菜洗净焯水', '捞出过凉水挤干', '姜末加生抽、醋、香油调成姜汁', '淋在菠菜上拌匀'], 2),
('葱油拌面', 'https://nocode.meituan.com/photo/search?keyword=scallion-oil-noodles&width=400&height=300', 10, '高热量', '疲惫', ARRAY['小葱切段，小火炸至金黄', '捞出葱段，葱油中加入生抽、糖', '面条煮熟过凉水', '淋上葱油拌匀，撒葱段'], 1);

-- 添加菜谱食材关联数据 - 卤味系列（recipe_id 从114开始）
INSERT INTO recipe_ingredients (recipe_id, ingredient_name, amount, is_main) VALUES
(114, '牛腱子肉', '800克', true),
(114, '八角', '3个', false),
(114, '桂皮', '1块', false),
(114, '香叶', '3片', false),
(114, '花椒', '10粒', false),
(114, '生抽', '4勺', false),
(114, '老抽', '2勺', false),
(114, '料酒', '3勺', false),
(114, '冰糖', '30克', false),
(114, '姜片', '5片', false),
(115, '鸡蛋', '6个', true),
(115, '八角', '2个', false),
(115, '桂皮', '1块', false),
(115, '香叶', '2片', false),
(115, '茶叶', '10克', false),
(115, '生抽', '3勺', false),
(115, '老抽', '1勺', false),
(115, '冰糖', '20克', false),
(116, '豆腐干', '500克', true),
(116, '八角', '2个', false),
(116, '桂皮', '1块', false),
(116, '香叶', '2片', false),
(116, '生抽', '3勺', false),
(116, '老抽', '1勺', false),
(116, '料酒', '2勺', false),
(116, '冰糖', '15克', false),
(117, '花生', '500克', true),
(117, '八角', '3个', false),
(117, '桂皮', '1块', false),
(117, '香叶', '3片', false),
(117, '花椒', '10粒', false),
(117, '盐', '15克', false),
(117, '五香粉', '1勺', false);

-- 酱料特色菜食材
INSERT INTO recipe_ingredients (recipe_id, ingredient_name, amount, is_main) VALUES
(118, '面条', '150克', true),
(118, '芝麻酱', '3勺', true),
(118, '生抽', '1勺', false),
(118, '醋', '1勺', false),
(118, '糖', '半勺', false),
(118, '蒜泥', '1勺', false),
(118, '香油', '1勺', false),
(118, '黄瓜', '半根', false),
(119, '米饭', '1碗', true),
(119, '生抽', '2勺', false),
(119, '老抽', '半勺', false),
(119, '葱花', '适量', false),
(119, '油', '2勺', false),
(120, '土豆', '2个', true),
(120, '干辣椒', '3个', false),
(120, '蒜片', '3瓣', false),
(120, '醋', '2勺', false),
(120, '盐', '适量', false),
(120, '糖', '半勺', false),
(121, '生菜', '2颗', true),
(121, '蚝油', '2勺', true),
(121, '油', '1勺', false),
(122, '牛肉', '300克', true),
(122, '黑胡椒酱', '2勺', true),
(122, '洋葱', '半个', false),
(122, '青椒', '1个', false),
(122, '盐', '适量', false);

-- 快手调料菜食材
INSERT INTO recipe_ingredients (recipe_id, ingredient_name, amount, is_main) VALUES
(123, '茄子', '2根', true),
(123, '大蒜', '半头', false),
(123, '生抽', '2勺', false),
(123, '香油', '1勺', false),
(123, '葱花', '适量', false),
(124, '木耳', '20克', true),
(124, '黄瓜', '2根', true),
(124, '蒜末', '3瓣', false),
(124, '生抽', '2勺', false),
(124, '醋', '2勺', false),
(124, '辣椒油', '1勺', false),
(124, '香油', '1勺', false),
(125, '菠菜', '300克', true),
(125, '姜', '1块', false),
(125, '生抽', '2勺', false),
(125, '醋', '1勺', false),
(125, '香油', '1勺', false),
(126, '面条', '150克', true),
(126, '小葱', '1把', true),
(126, '生抽', '3勺', false),
(126, '糖', '1勺', false),
(126, '油', '3勺', false);

-- 补充常用调料到 ingredients 表
INSERT INTO ingredients (name, image, quantity, expiry_days, storage_location, user_id) VALUES
('卤料包', 'https://nocode.meituan.com/photo/search?keyword=braise-spice-packet&width=200&height=200', '2包', 365, '调料', ''),
('茶叶', 'https://nocode.meituan.com/photo/search?keyword=tea-leaves&width=200&height=200', '50克', 365, '常温', ''),
('五香粉', 'https://nocode.meituan.com/photo/search?keyword=five-spice-powder&width=200&height=200', '1瓶', 365, '调料', ''),
('蒜泥', 'https://nocode.meituan.com/photo/search?keyword=minced-garlic&width=200&height=200', '1罐', 90, '冷藏', ''),
('花椒油', 'https://nocode.meituan.com/photo/search?keyword=sichuan-pepper-oil&width=200&height=200', '1瓶', 365, '调料', ''),
('黑椒酱', 'https://nocode.meituan.com/photo/search?keyword=black-pepper-sauce&width=200&height=200', '1瓶', 180, '调料', ''),
('蒸鱼豉油', 'https://nocode.meituan.com/photo/search?keyword=steamed-fish-soy-sauce&width=200&height=200', '1瓶', 365, '调料', ''),
('豆豉', 'https://nocode.meituan.com/photo/search?keyword=black-bean&width=200&height=200', '1罐', 180, '调料', '');
