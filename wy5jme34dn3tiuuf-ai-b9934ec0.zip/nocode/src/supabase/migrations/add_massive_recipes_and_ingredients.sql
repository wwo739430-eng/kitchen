-- ==========================================
-- 文件摘要: 大规模补充食谱、食材和调料数据
-- 
-- 变更说明:
-- 1. 添加30道新菜谱，涵盖各类烹饪场景
-- 2. 添加50种基础食材和调料
-- 3. 完善食材关联关系
-- ==========================================

-- 家常快手菜系列（10-15分钟）
INSERT INTO recipes (name, image, cook_time, calories_tag, mood_type, steps, servings) VALUES
('蒜蓉粉丝娃娃菜', 'https://nocode.meituan.com/photo/search?keyword=garlic-vermicelli-baby-cabbage&width=400&height=300', 12, '低热量', '一般,低落', ARRAY['娃娃菜洗净对半切开', '粉丝用温水泡软', '盘中铺娃娃菜和粉丝', '淋上蒜蓉酱', '蒸锅水开后蒸8分钟', '淋上生抽和热油'], 2),
('干煸四季豆', 'https://nocode.meituan.com/photo/search?keyword=dry-fried-green-beans&width=400&height=300', 15, '正常', '解馋,开心', ARRAY['四季豆去筋掰成段', '锅中不放油，干煸四季豆至虎皮', '盛出备用', '锅中放油，爆香肉末和干辣椒', '倒入四季豆，加生抽、糖调味', '翻炒均匀出锅'], 2),
('蒜蓉蒸茄子', 'https://nocode.meituan.com/photo/search?keyword=garlic-steamed-eggplant&width=400&height=300', 10, '低热量', '一般', ARRAY['茄子切条', '上锅蒸8分钟至软', '取出撕成条', '淋上蒜蓉、生抽、香油调成的汁', '撒上葱花'], 2),
('炒豆芽', 'https://nocode.meituan.com/photo/search?keyword=stir-fried-bean-sprouts&width=400&height=300', 5, '低热量', '一般', ARRAY['豆芽洗净沥干', '锅中热油，爆香花椒', '倒入豆芽大火快炒', '加盐、醋调味', '炒至断生出锅'], 2),
('清炒芦笋', 'https://nocode.meituan.com/photo/search?keyword=sauteed-asparagus&width=400&height=300', 8, '低热量', '一般,低落', ARRAY['芦笋去老根切段', '锅中烧水，加少许油盐，焯烫1分钟', '捞出过凉水', '锅中爆香蒜末', '倒入芦笋快速翻炒，加盐调味'], 2),
('凉拌木耳', 'https://nocode.meituan.com/photo/search?keyword=cold-wood-ear&width=400&height=300', 10, '低热量', '解馋,开心', ARRAY['木耳泡发洗净', '焯水2分钟捞出', '加入蒜末、生抽、醋、辣椒油', '拌匀腌制10分钟', '撒上香菜'], 2),
('韭菜炒蛋', 'https://nocode.meituan.com/photo/search?keyword=chive-egg&width=400&height=300', 8, '正常', '一般,开心', ARRAY['韭菜切段，鸡蛋打散', '先炒蛋盛出', '锅中留底油炒韭菜', '加入鸡蛋，加盐调味', '翻炒均匀'], 2),
('蒜蓉油麦菜', 'https://nocode.meituan.com/photo/search?keyword=garlic-lettuce&width=400&height=300', 5, '低热量', '一般', ARRAY['油麦菜洗净切段', '锅中爆香蒜末', '大火快炒油麦菜', '加盐调味，炒至断生'], 2),
('蚝油生菜', 'https://nocode.meituan.com/photo/search?keyword=oyster-sauce-lettuce&width=400&height=300', 5, '低热量', '一般', ARRAY['生菜洗净', '锅中烧水，加少许油盐', '焯烫生菜30秒捞出装盘', '淋上蚝油和热油'], 2),
('麻酱菠菜', 'https://nocode.meituan.com/photo/search?keyword=sesame-spinach&width=400&height=300', 8, '正常', '一般', ARRAY['菠菜洗净焯水', '捞出过凉水挤干', '芝麻酱加温水、盐、糖调开', '淋在菠菜上拌匀'], 2);

-- 肉类菜谱（30-45分钟）
INSERT INTO recipes (name, image, cook_time, calories_tag, mood_type, steps, servings) VALUES
('可乐鸡翅', 'https://nocode.meituan.com/photo/search?keyword=cola-chicken-wings&width=400&height=300', 30, '高热量', '解馋,开心', ARRAY['鸡翅两面划刀，料酒腌制', '煎至两面金黄', '倒入可乐没过鸡翅', '加生抽、老抽调味', '中火炖至汤汁浓稠'], 3),
('糖醋排骨', 'https://nocode.meituan.com/photo/search?keyword=sweet-sour-ribs&width=400&height=300', 45, '高热量', '开心,解馋', ARRAY['排骨焯水去血沫', '炸至金黄', '锅中放糖炒糖色', '倒入排骨翻炒', '加醋、生抽、水炖煮30分钟', '大火收汁'], 3),
('小炒肉', 'https://nocode.meituan.com/photo/search?keyword=stir-fried-pork&width=400&height=300', 20, '高热量', '解馋,压力大', ARRAY['五花肉切片，青椒切块', '干锅煸香青椒盛出', '锅中少许油，炒肉出油', '加蒜末、豆豉、生抽', '倒入青椒翻炒均匀'], 2),
('孜然羊肉', 'https://nocode.meituan.com/photo/search?keyword=cumin-lamb&width=400&height=300', 25, '高热量', '解馋,开心', ARRAY['羊肉切片，加盐、料酒、淀粉腌制', '锅中热油，滑炒羊肉变色盛出', '爆香洋葱丝', '倒入羊肉，加孜然粉、辣椒粉', '翻炒均匀撒香菜'], 2),
('回锅肉', 'https://nocode.meituan.com/photo/search?keyword=twice-cooked-pork&width=400&height=300', 35, '高热量', '解馋', ARRAY['五花肉煮熟切片', '锅中少许油，煸肉出油', '拨到一边，爆香豆瓣酱', '加青椒、蒜苗翻炒', '加生抽、糖调味'], 3),
('蒜香排骨', 'https://nocode.meituan.com/photo/search?keyword=garlic-ribs&width=400&height=300', 40, '高热量', '开心,解馋', ARRAY['排骨加蒜末、生抽、料酒腌制30分钟', '裹上淀粉', '油温六成热炸至金黄', '升高油温复炸', '撒上椒盐'], 3),
('黑椒牛柳', 'https://nocode.meituan.com/photo/search?keyword=black-pepper-beef&width=400&height=300', 20, '正常', '开心,解馋', ARRAY['牛肉切条，加盐、黑胡椒、淀粉腌制', '洋葱、青椒切丝', '热锅热油，滑炒牛肉变色盛出', '爆香洋葱青椒', '倒入牛肉，加黑椒酱翻炒均匀'], 2),
('红烧肉', 'https://nocode.meituan.com/photo/search?keyword=braised-pork&width=400&height=300', 60, '高热量', '低落,解馋', ARRAY['五花肉切块焯水', '锅中放少许油，加冰糖炒糖色', '倒入肉块翻炒上色', '加生抽、老抽、料酒', '加水没过肉，小火炖45分钟', '大火收汁'], 4);

-- 海鲜类菜谱（15-30分钟）
INSERT INTO recipes (name, image, cook_time, calories_tag, mood_type, steps, servings) VALUES
('清蒸鲈鱼', 'https://nocode.meituan.com/photo/search?keyword=steamed-seabass&width=400&height=300', 20, '低热量', '正常饮食,低落', ARRAY['鲈鱼处理干净，两面划刀', '抹盐和料酒腌制10分钟', '盘中铺姜片葱段，放上鱼', '水开后蒸8-10分钟', '倒掉蒸鱼水，淋蒸鱼豉油和热油'], 2),
('蒜蓉粉丝蒸扇贝', 'https://nocode.meituan.com/photo/search?keyword=scallop-garlic&width=400&height=300', 15, '正常', '开心,解馋', ARRAY['扇贝洗净，去除内脏', '粉丝泡软盘在扇贝上', '铺上蒜蓉酱', '蒸8分钟', '淋热油撒葱花'], 2),
('椒盐虾', 'https://nocode.meituan.com/photo/search?keyword=salt-pepper-shrimp&width=400&height=300', 15, '高热量', '解馋,开心', ARRAY['虾剪去虾须，开背去虾线', '裹上淀粉', '油温七成热炸至金黄酥脆', '锅中留底油，爆香蒜末、椒盐', '倒入虾翻炒均匀'], 2),
('酸菜鱼', 'https://nocode.meituan.com/photo/search?keyword=fish-with-pickled-cabbage&width=400&height=300', 35, '正常', '解馋,压力大', ARRAY['鱼片加盐、料酒、蛋清、淀粉腌制', '鱼骨煎至金黄', '爆香酸菜、泡椒、姜片', '加水煮开，放入鱼骨煮10分钟', '捞出鱼骨酸菜，下鱼片滑熟', '盛出撒花椒干辣椒，淋热油'], 3),
('香煎三文鱼', 'https://nocode.meituan.com/photo/search?keyword=pan-seared-salmon&width=400&height=300', 12, '正常', '开心,正常饮食', ARRAY['三文鱼抹盐和黑胡椒腌制', '平底锅刷油，鱼皮朝下煎至金黄', '翻面煎2分钟', '挤上柠檬汁'], 1),
('花蛤蒸蛋', 'https://nocode.meituan.com/photo/search?keyword=clam-steamed-egg&width=400&height=300', 20, '正常', '低落,一般', ARRAY['花蛤盐水吐沙后焯水开口', '鸡蛋打散加1.5倍温水', '蛋液过筛，倒入装有花蛤的盘中', '盖上保鲜膜蒸12分钟', '淋上生抽和香油'], 2),
('蒜蓉生蚝', 'https://nocode.meituan.com/photo/search?keyword=garlic-oyster&width=400&height=300', 15, '高热量', '解馋,开心', ARRAY['生蚝洗净摆盘', '铺上蒜蓉酱', '蒸8分钟', '撒葱花淋热油'], 2);

-- 主食类（15-30分钟）
INSERT INTO recipes (name, image, cook_time, calories_tag, mood_type, steps, servings) VALUES
('蛋炒饭', 'https://nocode.meituan.com/photo/search?keyword=egg-fried-rice&width=400&height=300', 10, '高热量', '一般,开心', ARRAY['鸡蛋炒熟盛出', '锅中爆香葱花', '倒入米饭炒散', '加入鸡蛋、盐、生抽', '翻炒均匀撒葱花'], 1),
('扬州炒饭', 'https://nocode.meituan.com/photo/search?keyword=yangzhou-fried-rice&width=400&height=300', 15, '高热量', '开心', ARRAY['鸡蛋、火腿、虾仁、豌豆分别炒熟', '锅中爆香葱花，倒入米饭', '加入所有配料', '加盐、生抽调味翻炒均匀'], 2),
('炒面', 'https://nocode.meituan.com/photo/search?keyword=stir-fried-noodles&width=400&height=300', 12, '高热量', '一般,解馋', ARRAY['面条煮熟过凉水', '锅中爆香肉丝、青菜', '倒入面条', '加生抽、老抽、糖调味', '翻炒均匀'], 1),
('意大利面', 'https://nocode.meituan.com/photo/search?keyword=spaghetti-bolognese&width=400&height=300', 30, '正常', '开心,低落', ARRAY['意面煮熟备用', '炒香洋葱肉末', '加入番茄罐头炖煮', '倒入意面拌匀', '撒上芝士粉'], 2),
('葱油拌面', 'https://nocode.meituan.com/photo/search?keyword=scallion-oil-noodles&width=400&height=300', 15, '高热量', '低落,一般', ARRAY['小葱切段', '小火慢炸葱段至金黄', '捞出葱段，葱油中加入生抽、糖', '面条煮熟过凉水', '淋上葱油拌匀，撒葱段'], 1),
('咖喱饭', 'https://nocode.meituan.com/photo/search?keyword=curry-rice&width=400&height=300', 30, '正常', '开心,低落', ARRAY['洋葱、土豆、胡萝卜切块', '炒香洋葱，加入肉块炒变色', '加入土豆胡萝卜翻炒', '加水炖煮20分钟', '关火加入咖喱块融化', '小火煮至浓稠，浇在米饭上'], 2),
('石锅拌饭', 'https://nocode.meituan.com/photo/search?keyword=bibimbap&width=400&height=300', 25, '正常', '开心,解馋', ARRAY['各种配菜分别炒熟调味', '石锅刷油铺米饭', '码上配菜', '中间放生蛋黄', '淋香油和韩式辣酱拌匀'], 1);

-- 早餐系列（5-20分钟）
INSERT INTO recipes (name, image, cook_time, calories_tag, mood_type, steps, servings) VALUES
('煎蛋吐司', 'https://nocode.meituan.com/photo/search?keyword=egg-toast&width=400&height=300', 8, '正常', '开心,一般', ARRAY['吐司中间挖洞', '打入鸡蛋', '小火煎至蛋熟', '撒上黑胡椒'], 1),
('香蕉松饼', 'https://nocode.meituan.com/photo/search?keyword=banana-pancake&width=400&height=300', 15, '高热量', '开心,低落', ARRAY['香蕉捣泥，加鸡蛋、牛奶、面粉搅匀', '平底锅刷油，倒入面糊', '小火煎至表面冒泡翻面', '煎至两面金黄'], 2),
('蔬菜蛋饼', 'https://nocode.meituan.com/photo/search?keyword=vegetable-omelet&width=400&height=300', 10, '正常', '一般', ARRAY['蔬菜切丝', '鸡蛋打散，加入蔬菜和盐', '平底锅煎成蛋饼'], 1),
('燕麦粥', 'https://nocode.meituan.com/photo/search?keyword=oatmeal&width=400&height=300', 10, '低热量', '低落,疲惫', ARRAY['燕麦加水煮开', '小火煮5分钟', '加入牛奶', '可加入水果或蜂蜜'], 1),
('包子', 'https://nocode.meituan.com/photo/search?keyword=steamed-bun&width=400&height=300', 15, '正常', '一般,开心', ARRAY['蒸锅水开后放入包子', '大火蒸15分钟', '关火焖2分钟'], 2),
('馄饨', 'https://nocode.meituan.com/photo/search?keyword=wonton&width=400&height=300', 10, '正常', '一般,低落', ARRAY['水开下馄饨', '煮至浮起', '加紫菜、虾皮、葱花', '加盐、香油调味'], 1);

-- 汤品类（20-60分钟）
INSERT INTO recipes (name, image, cook_time, calories_tag, mood_type, steps, servings) VALUES
('鸡蛋汤', 'https://nocode.meituan.com/photo/search?keyword=egg-drop-soup&width=400&height=300', 5, '低热量', '一般,低落', ARRAY['水烧开', '淋入蛋液形成蛋花', '加盐、香油、葱花'], 2),
('青菜豆腐汤', 'https://nocode.meituan.com/photo/search?keyword=vegetable-tofu-soup&width=400&height=300', 10, '低热量', '一般', ARRAY['豆腐切块', '水开放入豆腐', '加入青菜煮2分钟', '加盐、香油调味'], 2),
('萝卜排骨汤', 'https://nocode.meituan.com/photo/search?keyword=radish-pork-rib-soup&width=400&height=300', 60, '正常', '低落,一般', ARRAY['排骨焯水', '萝卜切块', '排骨加水炖煮40分钟', '加入萝卜煮20分钟', '加盐调味'], 3),
('银耳莲子汤', 'https://nocode.meituan.com/photo/search?keyword=silver-ear-lotus-soup&width=400&height=300', 90, '低热量', '低落', ARRAY['银耳泡发撕小朵', '莲子泡发', '加水炖煮1小时', '加入冰糖、枸杞'], 4);

-- 小吃/夜宵系列（10-30分钟）
INSERT INTO recipes (name, image, cook_time, calories_tag, mood_type, steps, servings) VALUES
('煎饺', 'https://nocode.meituan.com/photo/search?keyword=fried-dumpling&width=400&height=300', 15, '高热量', '解馋,压力大', ARRAY['平底锅刷油，放入饺子', '加少量水盖盖焖煎', '水干后继续煎至底部金黄'], 2),
('炸薯条', 'https://nocode.meituan.com/photo/search?keyword=french-fries&width=400&height=300', 20, '高热量', '解馋,开心', ARRAY['土豆切条，清水浸泡去淀粉', '焯水2分钟捞出沥干', '油温六成热炸至微黄', '升高油温复炸至金黄', '撒盐'], 2),
('烤红薯', 'https://nocode.meituan.com/photo/search?keyword=baked-sweet-potato&width=400&height=300', 60, '正常', '低落,解馋', ARRAY['红薯洗净', '烤箱200度烤60分钟', '翻面再烤20分钟'], 2),
('糖葫芦', 'https://nocode.meituan.com/photo/search?keyword=candied-hawthorn&width=400&height=300', 30, '高热量', '开心', ARRAY['山楂洗净去核串成串', '糖加水小火熬至琥珀色', '山楂串蘸糖浆', '放在油纸上晾凉'], 4);

-- 添加食材关联数据 - 家常快手菜 (recipe_id 68-77)
INSERT INTO recipe_ingredients (recipe_id, ingredient_name, amount, is_main) VALUES
(68, '娃娃菜', '2颗', true),
(68, '粉丝', '1把', true),
(68, '大蒜', '1头', false),
(69, '四季豆', '300克', true),
(69, '肉末', '100克', false),
(69, '干辣椒', '5个', false),
(70, '茄子', '2根', true),
(70, '大蒜', '半头', false),
(71, '豆芽', '400克', true),
(71, '花椒', '适量', false),
(72, '芦笋', '300克', true),
(72, '大蒜', '3瓣', false),
(73, '木耳', '20克', true),
(73, '辣椒油', '2勺', false),
(74, '韭菜', '300克', true),
(74, '鸡蛋', '3个', true),
(75, '油麦菜', '2颗', true),
(75, '大蒜', '4瓣', false),
(76, '生菜', '2颗', true),
(76, '蚝油', '2勺', false),
(77, '菠菜', '300克', true),
(77, '芝麻酱', '3勺', false);

-- 肉类菜谱食材 (recipe_id 78-85)
INSERT INTO recipe_ingredients (recipe_id, ingredient_name, amount, is_main) VALUES
(78, '鸡翅', '10个', true),
(78, '可乐', '1罐', true),
(79, '排骨', '500克', true),
(79, '醋', '3勺', false),
(79, '糖', '3勺', false),
(80, '五花肉', '300克', true),
(80, '青椒', '3个', true),
(81, '羊肉', '300克', true),
(81, '孜然粉', '2勺', false),
(81, '洋葱', '半个', false),
(82, '五花肉', '400克', true),
(82, '蒜苗', '3根', false),
(82, '豆瓣酱', '2勺', false),
(83, '排骨', '500克', true),
(83, '大蒜', '2头', false),
(84, '牛肉', '300克', true),
(84, '黑胡椒酱', '2勺', false),
(84, '洋葱', '半个', false),
(85, '五花肉', '800克', true),
(85, '冰糖', '50克', false);

-- 海鲜类食材 (recipe_id 86-92)
INSERT INTO recipe_ingredients (recipe_id, ingredient_name, amount, is_main) VALUES
(86, '鲈鱼', '1条', true),
(86, '蒸鱼豉油', '3勺', false),
(87, '扇贝', '6个', true),
(87, '粉丝', '1把', false),
(88, '虾', '400克', true),
(88, '椒盐', '适量', false),
(89, '鱼片', '500克', true),
(89, '酸菜', '200克', true),
(89, '泡椒', '10个', false),
(90, '三文鱼', '200克', true),
(90, '柠檬', '半个', false),
(91, '花蛤', '300克', true),
(91, '鸡蛋', '2个', false),
(92, '生蚝', '6个', true),
(92, '蒜蓉酱', '3勺', false);

-- 主食类食材 (recipe_id 93-99)
INSERT INTO recipe_ingredients (recipe_id, ingredient_name, amount, is_main) VALUES
(93, '米饭', '1碗', true),
(93, '鸡蛋', '2个', true),
(94, '米饭', '2碗', true),
(94, '火腿', '50克', false),
(94, '虾仁', '50克', false),
(94, '豌豆', '30克', false),
(95, '面条', '200克', true),
(95, '肉丝', '100克', false),
(95, '青菜', '2颗', false),
(96, '意大利面', '200克', true),
(96, '肉末', '150克', false),
(96, '番茄罐头', '1罐', false),
(97, '面条', '200克', true),
(97, '小葱', '1把', true),
(98, '土豆', '2个', true),
(98, '胡萝卜', '1根', false),
(98, '咖喱块', '4块', true),
(99, '米饭', '1碗', true),
(99, '鸡蛋', '1个', true),
(99, '韩式辣酱', '2勺', false);

-- 早餐系列食材 (recipe_id 100-105)
INSERT INTO recipe_ingredients (recipe_id, ingredient_name, amount, is_main) VALUES
(100, '吐司', '2片', true),
(100, '鸡蛋', '2个', true),
(101, '香蕉', '2根', true),
(101, '面粉', '100克', false),
(101, '牛奶', '100ml', false),
(102, '鸡蛋', '2个', true),
(102, '蔬菜', '适量', false),
(103, '燕麦', '50克', true),
(103, '牛奶', '250ml', true),
(104, '包子', '4个', true),
(105, '馄饨', '10个', true),
(105, '紫菜', '适量', false);

-- 汤品系列食材 (recipe_id 106-109)
INSERT INTO recipe_ingredients (recipe_id, ingredient_name, amount, is_main) VALUES
(106, '鸡蛋', '2个', true),
(107, '豆腐', '1块', true),
(107, '青菜', '2颗', true),
(108, '排骨', '500克', true),
(108, '萝卜', '1根', true),
(109, '银耳', '1朵', true),
(109, '莲子', '50克', true),
(109, '冰糖', '适量', false);

-- 小吃系列食材 (recipe_id 110-113)
INSERT INTO recipe_ingredients (recipe_id, ingredient_name, amount, is_main) VALUES
(110, '饺子', '10个', true),
(111, '土豆', '3个', true),
(112, '红薯', '4个', true),
(113, '山楂', '500克', true),
(113, '冰糖', '200克', false);

-- 大规模补充基础食材和调料数据
INSERT INTO ingredients (name, image, quantity, expiry_days, storage_location, user_id) VALUES
-- 新鲜蔬菜
('小白菜', 'https://nocode.meituan.com/photo/search?keyword=baby-bok-choy&width=200&height=200', '300克', 5, '冷藏', ''),
('油麦菜', 'https://nocode.meituan.com/photo/search?keyword=romaine-lettuce&width=200&height=200', '2颗', 5, '冷藏', ''),
('娃娃菜', 'https://nocode.meituan.com/photo/search?keyword=baby-cabbage&width=200&height=200', '2颗', 7, '冷藏', ''),
('芦笋', 'https://nocode.meituan.com/photo/search?keyword=asparagus&width=200&height=200', '1把', 5, '冷藏', ''),
('莲藕', 'https://nocode.meituan.com/photo/search?keyword=lotus-root&width=200&height=200', '2节', 10, '冷藏', ''),
('山药', 'https://nocode.meituan.com/photo/search?keyword=yam&width=200&height=200', '1根', 14, '冷藏', ''),
('芋头', 'https://nocode.meituan.com/photo/search?keyword=taro&width=200&height=200', '500克', 14, '常温', ''),
('红薯', 'https://nocode.meituan.com/photo/search?keyword=sweet-potato&width=200&height=200', '1公斤', 30, '常温', ''),
('紫薯', 'https://nocode.meituan.com/photo/search?keyword=purple-sweet-potato&width=200&height=200', '500克', 30, '常温', ''),
('韭菜', 'https://nocode.meituan.com/photo/search?keyword=chives&width=200&height=200', '300克', 5, '冷藏', ''),
('韭黄', 'https://nocode.meituan.com/photo/search?keyword=yellow-chives&width=200&height=200', '200克', 5, '冷藏', ''),
('蒜苗', 'https://nocode.meituan.com/photo/search?keyword=garlic-sprouts&width=200&height=200', '1把', 7, '冷藏', ''),
('大葱', 'https://nocode.meituan.com/photo/search?keyword=scallion&width=200&height=200', '2根', 14, '冷藏', ''),
('小葱', 'https://nocode.meituan.com/photo/search?keyword=green-onion&width=200&height=200', '1把', 7, '冷藏', ''),
('香菜', 'https://nocode.meituan.com/photo/search?keyword=cilantro&width=200&height=200', '100克', 5, '冷藏', ''),
('芹菜', 'https://nocode.meituan.com/photo/search?keyword=celery&width=200&height=200', '300克', 7, '冷藏', ''),
('莴笋', 'https://nocode.meituan.com/photo/search?keyword=celtuce&width=200&height=200', '2根', 7, '冷藏', ''),
('竹笋', 'https://nocode.meituan.com/photo/search?keyword=bamboo-shoot&width=200&height=200', '300克', 7, '冷藏', ''),
('茭白', 'https://nocode.meituan.com/photo/search?keyword=water-bamboo&width=200&height=200', '4根', 7, '冷藏', ''),
('芥蓝', 'https://nocode.meituan.com/photo/search?keyword=chinese-broccoli&width=200&height=200', '300克', 5, '冷藏', ''),

-- 菌菇类
('香菇', 'https://nocode.meituan.com/photo/search?keyword=shiitake-mushroom&width=200&height=200', '200克', 7, '冷藏', ''),
('金针菇', 'https://nocode.meituan.com/photo/search?keyword=enoki-mushroom&width=200&height=200', '1把', 5, '冷藏', ''),
('杏鲍菇', 'https://nocode.meituan.com/photo/search?keyword=king-oyster-mushroom&width=200&height=200', '2根', 7, '冷藏', ''),
('平菇', 'https://nocode.meituan.com/photo/search?keyword=oyster-mushroom&width=200&height=200', '300克', 5, '冷藏', ''),
('木耳', 'https://nocode.meituan.com/photo/search?keyword=wood-ear-mushroom&width=200&height=200', '50克干', 365, '常温', ''),
('银耳', 'https://nocode.meituan.com/photo/search?keyword=silver-ear-mushroom&width=200&height=200', '1朵', 365, '常温', ''),

-- 豆制品
('北豆腐', 'https://nocode.meituan.com/photo/search?keyword=firm-tofu&width=200&height=200', '1块', 3, '冷藏', ''),
('嫩豆腐', 'https://nocode.meituan.com/photo/search?keyword=soft-tofu&width=200&height=200', '1盒', 3, '冷藏', ''),
('豆干', 'https://nocode.meituan.com/photo/search?keyword=dried-tofu&width=200&height=200', '300克', 7, '冷藏', ''),
('豆皮', 'https://nocode.meituan.com/photo/search?keyword=tofu-skin&width=200&height=200', '200克', 7, '冷藏', ''),
('腐竹', 'https://nocode.meituan.com/photo/search?keyword=bean-curd-stick&width=200&height=200', '100克', 365, '常温', ''),
('千张', 'https://nocode.meituan.com/photo/search?keyword=tofu-sheet&width=200&height=200', '200克', 5, '冷藏', ''),

-- 肉类
('五花肉', 'https://nocode.meituan.com/photo/search?keyword=pork-belly&width=200&height=200', '500克', 3, '冷藏', ''),
('里脊肉', 'https://nocode.meituan.com/photo/search?keyword=pork-tenderloin&width=200&height=200', '300克', 3, '冷藏', ''),
('梅花肉', 'https://nocode.meituan.com/photo/search?keyword=pork-shoulder&width=200&height=200', '400克', 3, '冷藏', ''),
('猪蹄', 'https://nocode.meituan.com/photo/search?keyword=pork-trotter&width=200&height=200', '2只', 3, '冷藏', ''),
('牛肉', 'https://nocode.meituan.com/photo/search?keyword=beef&width=200&height=200', '500克', 3, '冷藏', ''),
('牛腩', 'https://nocode.meituan.com/photo/search?keyword=beef-brisket&width=200&height=200', '500克', 3, '冷藏', ''),
('肥牛卷', 'https://nocode.meituan.com/photo/search?keyword=beef-slices&width=200&height=200', '300克', 3, '冷藏', ''),
('羊肉', 'https://nocode.meituan.com/photo/search?keyword=lamb&width=200&height=200', '500克', 3, '冷藏', ''),
('羊排', 'https://nocode.meituan.com/photo/search?keyword=lamb-chop&width=200&height=200', '400克', 3, '冷藏', ''),
('鸡腿', 'https://nocode.meituan.com/photo/search?keyword=chicken-drumstick&width=200&height=200', '4个', 3, '冷藏', ''),
('鸡胸肉', 'https://nocode.meituan.com/photo/search?keyword=chicken-breast&width=200&height=200', '300克', 3, '冷藏', ''),
('鸡翅', 'https://nocode.meituan.com/photo/search?keyword=chicken-wings&width=200&height=200', '10个', 3, '冷藏', ''),
('鸡爪', 'https://nocode.meituan.com/photo/search?keyword=chicken-feet&width=200&height=200', '500克', 3, '冷藏', ''),

-- 海鲜
('鲈鱼', 'https://nocode.meituan.com/photo/search?keyword=seabass&width=200&height=200', '1条', 2, '冷藏', ''),
('鲫鱼', 'https://nocode.meituan.com/photo/search?keyword=crucian-carp&width=200&height=200', '1条', 2, '冷藏', ''),
('草鱼', 'https://nocode.meituan.com/photo/search?keyword=grass-carp&width=200&height=200', '1条', 2, '冷藏', ''),
('带鱼', 'https://nocode.meituan.com/photo/search?keyword=belt-fish&width=200&height=200', '1条', 2, '冷藏', ''),
('黄花鱼', 'https://nocode.meituan.com/photo/search?keyword=yellow-croaker&width=200&height=200', '2条', 2, '冷藏', ''),
('三文鱼', 'https://nocode.meituan.com/photo/search?keyword=salmon&width=200&height=200', '200克', 2, '冷藏', ''),
('虾', 'https://nocode.meituan.com/photo/search?keyword=shrimp&width=200&height=200', '500克', 2, '冷藏', ''),
('虾仁', 'https://nocode.meituan.com/photo/search?keyword=shrimp-meat&width=200&height=200', '300克', 2, '冷藏', ''),
('扇贝', 'https://nocode.meituan.com/photo/search?keyword=scallop&width=200&height=200', '6个', 2, '冷藏', ''),
('生蚝', 'https://nocode.meituan.com/photo/search?keyword=oyster&width=200&height=200', '6个', 2, '冷藏', ''),
('花蛤', 'https://nocode.meituan.com/photo/search?keyword=clam&width=200&height=200', '500克', 2, '冷藏', ''),
('鱿鱼', 'https://nocode.meituan.com/photo/search?keyword=squid&width=200&height=200', '300克', 2, '冷藏', ''),

-- 蛋类
('鸡蛋', 'https://nocode.meituan.com/photo/search?keyword=egg&width=200&height=200', '12个', 30, '冷藏', ''),
('鸭蛋', 'https://nocode.meituan.com/photo/search?keyword=duck-egg&width=200&height=200', '6个', 30, '冷藏', ''),
('鹌鹑蛋', 'https://nocode.meituan.com/photo/search?keyword=quail-egg&width=200&height=200', '24个', 30, '冷藏', ''),

-- 主食类
('大米', 'https://nocode.meituan.com/photo/search?keyword=rice&width=200&height=200', '5公斤', 365, '常温', ''),
('糯米', 'https://nocode.meituan.com/photo/search?keyword=glutinous-rice&width=200&height=200', '1公斤', 365, '常温', ''),
('小米', 'https://nocode.meituan.com/photo/search?keyword=millet&width=200&height=200', '500克', 365, '常温', ''),
('黑米', 'https://nocode.meituan.com/photo/search?keyword=black-rice&width=200&height=200', '500克', 365, '常温', ''),
('糙米', 'https://nocode.meituan.com/photo/search?keyword=brown-rice&width=200&height=200', '1公斤', 365, '常温', ''),
('挂面', 'https://nocode.meituan.com/photo/search?keyword=noodles&width=200&height=200', '500克', 180, '常温', ''),
('方便面', 'https://nocode.meituan.com/photo/search?keyword=instant-noodles&width=200&height=200', '5包', 180, '常温', ''),
('意大利面', 'https://nocode.meituan.com/photo/search?keyword=spaghetti&width=200&height=200', '500克', 365, '常温', ''),
('通心粉', 'https://nocode.meituan.com/photo/search?keyword=macaroni&width=200&height=200', '400克', 365, '常温', ''),
('红薯粉', 'https://nocode.meituan.com/photo/search?keyword=sweet-potato-noodles&width=200&height=200', '200克', 365, '常温', ''),
('粉丝', 'https://nocode.meituan.com/photo/search?keyword=vermicelli&width=200&height=200', '100克', 365, '常温', ''),
('饺子皮', 'https://nocode.meituan.com/photo/search?keyword=dumpling-wrapper&width=200&height=200', '1包', 3, '冷藏', ''),
('馄饨皮', 'https://nocode.meituan.com/photo/search?keyword=wonton-wrapper&width=200&height=200', '1包', 3, '冷藏', ''),
('手抓饼', 'https://nocode.meituan.com/photo/search?keyword=hand-grab-pancake&width=200&height=200', '5张', 180, '冷冻', ''),
('馒头', 'https://nocode.meituan.com/photo/search?keyword=steamed-bun&width=200&height=200', '6个', 3, '常温', ''),
('包子', 'https://nocode.meituan.com/photo/search?keyword=steamed-stuffed-bun&width=200&height=200', '6个', 3, '冷藏', ''),
('饺子', 'https://nocode.meituan.com/photo/search?keyword=dumpling&width=200&height=200', '20个', 180, '冷冻', ''),
('馄饨', 'https://nocode.meituan.com/photo/search?keyword=wonton&width=200&height=200', '20个', 180, '冷冻', ''),
('汤圆', 'https://nocode.meituan.com/photo/search?keyword=tangyuan&width=200&height=200', '1包', 180, '冷冻', ''),

-- 调料补充
('料酒', 'https://nocode.meituan.com/photo/search?keyword=cooking-wine&width=200&height=200', '1瓶', 365, '调料', ''),
('生抽', 'https://nocode.meituan.com/photo/search?keyword=light-soy-sauce&width=200&height=200', '1瓶', 365, '调料', ''),
('老抽', 'https://nocode.meituan.com/photo/search?keyword=dark-soy-sauce&width=200&height=200', '1瓶', 365, '调料', ''),
('香醋', 'https://nocode.meituan.com/photo/search?keyword=vinegar&width=200&height=200', '1瓶', 365, '调料', ''),
('陈醋', 'https://nocode.meituan.com/photo/search?keyword=mature-vinegar&width=200&height=200', '1瓶', 365, '调料', ''),
('白醋', 'https://nocode.meituan.com/photo/search?keyword=white-vinegar&width=200&height=200', '1瓶', 365, '调料', ''),
('蚝油', 'https://nocode.meituan.com/photo/search?keyword=oyster-sauce&width=200&height=200', '1瓶', 180, '调料', ''),
('蒸鱼豉油', 'https://nocode.meituan.com/photo/search?keyword=steamed-fish-soy-sauce&width=200&height=200', '1瓶', 365, '调料', ''),
('鱼露', 'https://nocode.meituan.com/photo/search?keyword=fish-sauce&width=200&height=200', '1瓶', 365, '调料', ''),
('虾油', 'https://nocode.meituan.com/photo/search?keyword=shrimp-oil&width=200&height=200', '1瓶', 365, '调料', ''),
('香油', 'https://nocode.meituan.com/photo/search?keyword=sesame-oil&width=200&height=200', '1瓶', 365, '调料', ''),
('花椒油', 'https://nocode.meituan.com/photo/search?keyword=sichuan-pepper-oil&width=200&height=200', '1瓶', 365, '调料', ''),
('辣椒油', 'https://nocode.meituan.com/photo/search?keyword=chili-oil&width=200&height=200', '1瓶', 180, '调料', ''),
('豆瓣酱', 'https://nocode.meituan.com/photo/search?keyword=bean-paste&width=200&height=200', '1瓶', 365, '调料', ''),
('黄豆酱', 'https://nocode.meituan.com/photo/search?keyword=soybean-paste&width=200&height=200', '1瓶', 365, '调料', ''),
('甜面酱', 'https://nocode.meituan.com/photo/search?keyword=sweet-bean-sauce&width=200&height=200', '1瓶', 180, '调料', ''),
('番茄酱', 'https://nocode.meituan.com/photo/search?keyword=tomato-sauce&width=200&height=200', '1瓶', 365, '调料', ''),
('沙拉酱', 'https://nocode.meituan.com/photo/search?keyword=salad-dressing&width=200&height=200', '1瓶', 90, '调料', ''),
('芝麻酱', 'https://nocode.meituan.com/photo/search?keyword=sesame-paste&width=200&height=200', '1瓶', 180, '调料', ''),
('花生酱', 'https://nocode.meituan.com/photo/search?keyword=peanut-butter&width=200&height=200', '1瓶', 180, '调料', ''),
('芥末酱', 'https://nocode.meituan.com/photo/search?keyword=wasabi&width=200&height=200', '1支', 365, '调料', ''),
('黑椒酱', 'https://nocode.meituan.com/photo/search?keyword=black-pepper-sauce&width=200&height=200', '1瓶', 365, '调料', ''),
('咖喱块', 'https://nocode.meituan.com/photo/search?keyword=curry-cube&width=200&height=200', '1盒', 365, '调料', ''),
('韩式辣酱', 'https://nocode.meituan.com/photo/search?keyword=korean-chili-paste&width=200&height=200', '1瓶', 365, '调料', ''),
('泰式甜辣酱', 'https://nocode.meituan.com/photo/search?keyword=sweet-chili-sauce&width=200&height=200', '1瓶', 365, '调料', ''),
('盐', 'https://nocode.meituan.com/photo/search?keyword=salt&width=200&height=200', '1袋', 730, '调料', ''),
('糖', 'https://nocode.meituan.com/photo/search?keyword=sugar&width=200&height=200', '1袋', 365, '调料', ''),
('冰糖', 'https://nocode.meituan.com/photo/search?keyword=rock-sugar&width=200&height=200', '200克', 365, '调料', ''),
('红糖', 'https://nocode.meituan.com/photo/search?keyword=brown-sugar&width=200&height=200', '200克', 365, '调料', ''),
('蜂蜜', 'https://nocode.meituan.com/photo/search?keyword=honey&width=200&height=200', '1瓶', 730, '调料', ''),
('胡椒粉', 'https://nocode.meituan.com/photo/search?keyword=pepper&width=200&height=200', '1瓶', 365, '调料', ''),
('五香粉', 'https://nocode.meituan.com/photo/search?keyword=five-spice&width=200&height=200', '1瓶', 365, '调料', ''),
('十三香', 'https://nocode.meituan.com/photo/search?keyword=thirteen-spice&width=200&height=200', '1盒', 365, '调料', ''),
('孜然粉', 'https://nocode.meituan.com/photo/search?keyword=cumin&width=200&height=200', '1瓶', 365, '调料', ''),
('辣椒粉', 'https://nocode.meituan.com/photo/search?keyword=chili-powder&width=200&height=200', '1瓶', 365, '调料', ''),
('花椒粉', 'https://nocode.meituan.com/photo/search?keyword=sichuan-pepper-powder&width=200&height=200', '1瓶', 365, '调料', ''),
('椒盐', 'https://nocode.meituan.com/photo/search?keyword=salt-pepper&width=200&height=200', '1瓶', 365, '调料', ''),
('鸡精', 'https://nocode.meituan.com/photo/search?keyword=chicken-powder&width=200&height=200', '1袋', 365, '调料', ''),
('味精', 'https://nocode.meituan.com/photo/search?keyword=msg&width=200&height=200', '1袋', 730, '调料', ''),
('淀粉', 'https://nocode.meituan.com/photo/search?keyword=starch&width=200&height=200', '1袋', 365, '调料', ''),
('面粉', 'https://nocode.meituan.com/photo/search?keyword=flour&width=200&height=200', '1公斤', 180, '常温', ''),
('糯米粉', 'https://nocode.meituan.com/photo/search?keyword=glutinous-rice-flour&width=200&height=200', '500克', 180, '常温', ''),
('酵母粉', 'https://nocode.meituan.com/photo/search?keyword=yeast&width=200&height=200', '1包', 365, '冷藏', ''),
('泡打粉', 'https://nocode.meituan.com/photo/search?keyword=baking-powder&width=200&height=200', '1包', 365, '调料', ''),
('小苏打', 'https://nocode.meituan.com/photo/search?keyword=baking-soda&width=200&height=200', '1包', 730, '调料', ''),

-- 香料类
('大葱', 'https://nocode.meituan.com/photo/search?keyword=scallion&width=200&height=200', '2根', 14, '冷藏', ''),
('小葱', 'https://nocode.meituan.com/photo/search?keyword=green-onion&width=200&height=200', '1把', 7, '冷藏', ''),
('大蒜', 'https://nocode.meituan.com/photo/search?keyword=garlic&width=200&height=200', '1头', 30, '常温', ''),
('生姜', 'https://nocode.meituan.com/photo/search?keyword=ginger&width=200&height=200', '100克', 30, '常温', ''),
('洋葱', 'https://nocode.meituan.com/photo/search?keyword=onion&width=200&height=200', '2个', 30, '常温', ''),
('香菜', 'https://nocode.meituan.com/photo/search?keyword=coriander&width=200&height=200', '1把', 5, '冷藏', ''),
('花椒', 'https://nocode.meituan.com/photo/search?keyword=sichuan-pepper&width=200&height=200', '20克', 365, '调料', ''),
('八角', 'https://nocode.meituan.com/photo/search?keyword=star-anise&width=200&height=200', '10个', 365, '调料', ''),
('桂皮', 'https://nocode.meituan.com/photo/search?keyword=cinnamon&width=200&height=200', '3块', 365, '调料', ''),
('香叶', 'https://nocode.meituan.com/photo/search?keyword=bay-leaf&width=200&height=200', '5片', 365, '调料', ''),
('干辣椒', 'https://nocode.meituan.com/photo/search?keyword=dried-chili&width=200&height=200', '20个', 180, '调料', ''),
('小米辣', 'https://nocode.meituan.com/photo/search?keyword=bird-eye-chili&width=200&height=200', '10个', 14, '冷藏', ''),
('泡椒', 'https://nocode.meituan.com/photo/search?keyword=pickled-chili&width=200&height=200', '1瓶', 365, '调料', ''),
('酸菜', 'https://nocode.meituan.com/photo/search?keyword=pickled-cabbage&width=200&height=200', '1包', 180, '冷藏', ''),
('雪菜', 'https://nocode.meituan.com/photo/search?keyword=preserved-vegetable&width=200&height=200', '1包', 180, '冷藏', ''),
('榨菜', 'https://nocode.meituan.com/photo/search?keyword=zhacai&width=200&height=200', '1包', 180, '常温', ''),
('梅干菜', 'https://nocode.meituan.com/photo/search?keyword=meigan-cai&width=200&height=200', '100克', 365, '常温', ''),

-- 干货类
('红枣', 'https://nocode.meituan.com/photo/search?keyword=red-date&width=200&height=200', '200克', 365, '常温', ''),
('枸杞', 'https://nocode.meituan.com/photo/search?keyword=goji-berry&width=200&height=200', '100克', 365, '常温', ''),
('莲子', 'https://nocode.meituan.com/photo/search?keyword=lotus-seed&width=200&height=200', '100克', 365, '常温', ''),
('百合', 'https://nocode.meituan.com/photo/search?keyword=lily-bulb&width=200&height=200', '50克', 365, '常温', ''),
('桂圆', 'https://nocode.meituan.com/photo/search?keyword=longan&width=200&height=200', '100克', 365, '常温', ''),
('花生', 'https://nocode.meituan.com/photo/search?keyword=peanut&width=200&height=200', '200克', 180, '常温', ''),
('芝麻', 'https://nocode.meituan.com/photo/search?keyword=sesame&width=200&height=200', '100克', 365, '常温', ''),
('核桃', 'https://nocode.meituan.com/photo/search?keyword=walnut&width=200&height=200', '200克', 180, '常温', ''),
('杏仁', 'https://nocode.meituan.com/photo/search?keyword=almond&width=200&height=200', '100克', 180, '常温', ''),
('葡萄干', 'https://nocode.meituan.com/photo/search?keyword=raisin&width=200&height=200', '100克', 180, '常温', ''),

-- 奶制品
('牛奶', 'https://nocode.meituan.com/photo/search?keyword=milk&width=200&height=200', '1升', 7, '冷藏', ''),
('酸奶', 'https://nocode.meituan.com/photo/search?keyword=yogurt&width=200&height=200', '200克×4', 21, '冷藏', ''),
('芝士片', 'https://nocode.meituan.com/photo/search?keyword=cheese-slice&width=200&height=200', '10片', 180, '冷藏', ''),
('马苏里拉芝士', 'https://nocode.meituan.com/photo/search?keyword=mozzarella&width=200&height=200', '200克', 180, '冷冻', ''),
('黄油', 'https://nocode.meituan.com/photo/search?keyword=butter&width=200&height=200', '100克', 180, '冷藏', ''),
('淡奶油', 'https://nocode.meituan.com/photo/search?keyword=whipping-cream&width=200&height=200', '250ml', 7, '冷藏', ''),

-- 水果类
('苹果', 'https://nocode.meituan.com/photo/search?keyword=apple&width=200&height=200', '4个', 30, '常温', ''),
('香蕉', 'https://nocode.meituan.com/photo/search?keyword=banana&width=200&height=200', '1把', 7, '常温', ''),
('橙子', 'https://nocode.meituan.com/photo/search?keyword=orange&width=200&height=200', '4个', 14, '常温', ''),
('柠檬', 'https://nocode.meituan.com/photo/search?keyword=lemon&width=200&height=200', '2个', 30, '常温', ''),
('草莓', 'https://nocode.meituan.com/photo/search?keyword=strawberry&width=200&height=200', '500克', 5, '冷藏', ''),
('蓝莓', 'https://nocode.meituan.com/photo/search?keyword=blueberry&width=200&height=200', '125克', 7, '冷藏', ''),
('西瓜', 'https://nocode.meituan.com/photo/search?keyword=watermelon&width=200&height=200', '1个', 7, '冷藏', ''),
('葡萄', 'https://nocode.meituan.com/photo/search?keyword=grape&width=200&height=200', '500克', 7, '冷藏', ''),
('桃子', 'https://nocode.meituan.com/photo/search?keyword=peach&width=200&height=200', '4个', 7, '常温', ''),
('芒果', 'https://nocode.meituan.com/photo/search?keyword=mango&width=200&height=200', '2个', 7, '常温', ''),
('菠萝', 'https://nocode.meituan.com/photo/search?keyword=pineapple&width=200&height=200', '1个', 7, '常温', ''),
('猕猴桃', 'https://nocode.meituan.com/photo/search?keyword=kiwi&width=200&height=200', '4个', 14, '常温', ''),
('火龙果', 'https://nocode.meituan.com/photo/search?keyword=dragon-fruit&width=200&height=200', '2个', 7, '常温', ''),
('牛油果', 'https://nocode.meituan.com/photo/search?keyword=avocado&width=200&height=200', '2个', 5, '冷藏', '');
