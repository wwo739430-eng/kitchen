import { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { 
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Camera, Scan, X, Check, Loader2 } from 'lucide-react';
import { toast } from 'sonner';

const AIIngredientScanner = ({ isOpen, onClose, onScanComplete }) => {
  const [scanning, setScanning] = useState(false);
  const [preview, setPreview] = useState(null);
  const [recognized, setRecognized] = useState(null);
  const fileInputRef = useRef(null);

  const handleFileSelect = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setPreview(event.target.result);
        startScan(event.target.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const startScan = async (imageData) => {
    setScanning(true);
    setRecognized(null);
    
    // 模拟AI识别过程
    toast.info('正在识别包装信息...');
    
    setTimeout(() => {
      // 模拟识别结果
      const mockResults = [
        {
          name: '纯牛奶',
          quantity: '250ml',
          expiryDays: 180,
          storageLocation: '常温',
          nutrition: '能量: 275kJ, 蛋白质: 3.2g, 脂肪: 3.8g',
          brand: '蒙牛',
          ingredients: '生牛乳'
        },
        {
          name: '法式小面包',
          quantity: '200g',
          expiryDays: 30,
          storageLocation: '常温',
          nutrition: '能量: 1450kJ, 蛋白质: 8.5g',
          brand: '盼盼',
          ingredients: '小麦粉、白砂糖、鸡蛋'
        },
        {
          name: '速冻水饺',
          quantity: '500g',
          expiryDays: 365,
          storageLocation: '冷冻',
          nutrition: '能量: 850kJ, 蛋白质: 12g',
          brand: '三全',
          ingredients: '猪肉、面粉、白菜'
        }
      ];
      
      const randomResult = mockResults[Math.floor(Math.random() * mockResults.length)];
      setRecognized(randomResult);
      setScanning(false);
      toast.success('识别成功！');
    }, 2000);
  };

  const handleConfirm = () => {
    if (recognized) {
      onScanComplete(recognized);
      handleClose();
    }
  };

  const handleClose = () => {
    setPreview(null);
    setRecognized(null);
    setScanning(false);
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-sm p-0 overflow-hidden">
        <DialogHeader className="p-4 pb-0">
          <DialogTitle className="flex items-center gap-2 text-lg">
            <Scan size={20} className="text-green-600" />
            AI智能扫描
          </DialogTitle>
        </DialogHeader>

        <div className="p-4 space-y-4">
          {!preview ? (
            <div className="space-y-4">
              <div className="bg-gradient-to-br from-green-50 to-blue-50 rounded-2xl p-6 text-center">
                <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center mx-auto mb-4 shadow-sm">
                  <Camera size={32} className="text-green-600" />
                </div>
                <p className="text-sm text-gray-600 mb-2">对准食品包装，自动识别</p>
                <p className="text-xs text-gray-400">支持识别：保质期、配料表、营养成分</p>
              </div>
              
              <div className="grid grid-cols-2 gap-3">
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="flex flex-col items-center p-4 bg-green-50 rounded-xl hover:bg-green-100 transition-colors"
                >
                  <Camera size={24} className="text-green-600 mb-2" />
                  <span className="text-sm text-green-700">拍照</span>
                </button>
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="flex flex-col items-center p-4 bg-blue-50 rounded-xl hover:bg-blue-100 transition-colors"
                >
                  <Scan size={24} className="text-blue-600 mb-2" />
                  <span className="text-sm text-blue-700">相册</span>
                </button>
              </div>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={handleFileSelect}
              />
            </div>
          ) : (
            <div className="space-y-4">
              {/* 预览图 */}
              <div className="relative">
                <img 
                  src={preview} 
                  alt="扫描预览" 
                  className="w-full h-48 object-cover rounded-xl"
                />
                {scanning && (
                  <div className="absolute inset-0 bg-black/50 rounded-xl flex items-center justify-center">
                    <div className="text-center">
                      <Loader2 size={32} className="text-white animate-spin mx-auto mb-2" />
                      <p className="text-white text-sm">AI识别中...</p>
                    </div>
                  </div>
                )}
                {/* 扫描线动画 */}
                {scanning && (
                  <div className="absolute inset-0 overflow-hidden rounded-xl">
                    <div className="h-1 bg-gradient-to-r from-transparent via-green-400 to-transparent w-full absolute animate-scan" />
                  </div>
                )}
              </div>

              {/* 识别结果 */}
              {recognized && (
                <div className="bg-green-50 rounded-xl p-4 space-y-3">
                  <div className="flex items-center gap-2 text-green-700">
                    <Check size={18} />
                    <span className="font-medium">识别成功</span>
                  </div>
                  
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-500">名称</span>
                      <span className="font-medium text-gray-800">{recognized.name}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">规格</span>
                      <span className="text-gray-800">{recognized.quantity}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">保质期</span>
                      <span className="text-gray-800">{recognized.expiryDays}天</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">储存</span>
                      <span className="text-gray-800">{recognized.storageLocation}</span>
                    </div>
                    {recognized.brand && (
                      <div className="flex justify-between">
                        <span className="text-gray-500">品牌</span>
                        <span className="text-gray-800">{recognized.brand}</span>
                      </div>
                    )}
                  </div>

                  <div className="pt-2 border-t border-green-200">
                    <p className="text-xs text-gray-500 mb-1">营养成分:</p>
                    <p className="text-xs text-gray-600">{recognized.nutrition}</p>
                  </div>
                </div>
              )}

              {/* 操作按钮 */}
              <div className="flex gap-2">
                <Button 
                  variant="outline" 
                  className="flex-1 rounded-xl"
                  onClick={() => {
                    setPreview(null);
                    setRecognized(null);
                  }}
                >
                  重新扫描
                </Button>
                {recognized && (
                  <Button 
                    className="flex-1 bg-green-500 hover:bg-green-600 rounded-xl"
                    onClick={handleConfirm}
                  >
                    确认添加
                  </Button>
                )}
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default AIIngredientScanner;
