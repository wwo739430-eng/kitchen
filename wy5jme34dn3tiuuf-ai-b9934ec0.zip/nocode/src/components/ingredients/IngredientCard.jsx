import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Edit2, Trash2, Minus, Plus } from 'lucide-react';
import { getIngredientEmoji } from '@/lib/recipeEmojis';
import { cn } from '@/lib/utils';

const STORAGE_STYLES = {
  '冷藏': { icon: '❄️', color: 'bg-blue-50 text-blue-600 border-blue-200', label: '冷藏' },
  '冷冻': { icon: '🧊', color: 'bg-cyan-50 text-cyan-600 border-cyan-200', label: '冷冻' },
  '常温': { icon: '🌡️', color: 'bg-orange-50 text-orange-600 border-orange-200', label: '常温' },
  '调料': { icon: '🧂', color: 'bg-purple-50 text-purple-600 border-purple-200', label: '调料' },
};

const IngredientCard = ({ ingredient, remainingDays, onEdit, onDelete, onUpdateQuantity }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editData, setEditData] = useState(ingredient);

  const getExpiryStatus = () => {
    if (remainingDays < 0) return { label: '已过期', color: 'bg-gray-100 text-gray-500' };
    if (remainingDays <= 1) return { label: '今天过期', color: 'bg-red-100 text-red-600' };
    if (remainingDays <= 3) return { label: `${remainingDays}天后过期`, color: 'bg-orange-100 text-orange-600' };
    return { label: `${remainingDays}天`, color: 'bg-green-100 text-green-600' };
  };

  const status = getExpiryStatus();
  const storageStyle = STORAGE_STYLES[ingredient.storage_location] || STORAGE_STYLES['常温'];

  const handleSave = () => {
    onEdit({ ...editData, id: ingredient.id });
    setIsEditing(false);
  };

  // 解析数量
  const parseQuantity = (qty) => {
    const match = qty.match(/(\d+)\s*(.*)/);
    if (match) {
      return { num: parseInt(match[1]), unit: match[2] || '' };
    }
    return { num: 0, unit: qty };
  };

  const { num, unit } = parseQuantity(ingredient.quantity);

  const handleAdjustQuantity = (delta) => {
    const newNum = Math.max(0, num + delta);
    const newQuantity = newNum > 0 ? `${newNum}${unit}` : unit;
    onUpdateQuantity?.(ingredient.id, newQuantity);
  };

  if (isEditing) {
    return (
      <Card className="border-green-200 shadow-sm">
        <CardContent className="p-3 space-y-2">
          <input
            value={editData.name}
            onChange={(e) => setEditData(prev => ({ ...prev, name: e.target.value }))}
            className="w-full px-3 py-2 text-sm border border-green-200 rounded-lg focus:outline-none focus:border-green-400"
          />
          <div className="flex gap-2">
            <input
              value={editData.quantity}
              onChange={(e) => setEditData(prev => ({ ...prev, quantity: e.target.value }))}
              className="flex-1 px-3 py-2 text-sm border border-green-200 rounded-lg focus:outline-none focus:border-green-400"
              placeholder="数量"
            />
            <input
              type="number"
              value={editData.expiry_days}
              onChange={(e) => setEditData(prev => ({ ...prev, expiry_days: parseInt(e.target.value) || 7 }))}
              className="w-20 px-3 py-2 text-sm border border-green-200 rounded-lg focus:outline-none focus:border-green-400"
              placeholder="天数"
            />
          </div>
          <div className="flex gap-2">
            <Button size="sm" className="flex-1 bg-green-500 hover:bg-green-600" onClick={handleSave}>
              保存
            </Button>
            <Button size="sm" variant="outline" onClick={() => setIsEditing(false)}>
              取消
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className={cn(
      "shadow-sm hover:shadow-md transition-all border-0",
      remainingDays <= 3 ? 'ring-2 ring-orange-200' : ''
    )}>
      <CardContent className="p-3">
        <div className="flex items-start gap-3">
          {/* 图片/Emoji */}
          <div className="w-16 h-16 rounded-xl bg-green-50 flex items-center justify-center text-3xl flex-shrink-0">
            {ingredient.image ? (
              <img src={ingredient.image} alt={ingredient.name} className="w-full h-full rounded-xl object-cover" />
            ) : (
              getIngredientEmoji(ingredient.name)
            )}
          </div>
          
          {/* 信息 */}
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <h4 className="font-medium text-gray-800 truncate">{ingredient.name}</h4>
              <Badge variant="outline" className={`text-xs ${storageStyle.color}`}>
                <span className="mr-1">{storageStyle.icon}</span>
                {storageStyle.label}
              </Badge>
            </div>
            
            {/* 数量调整 */}
            <div className="flex items-center gap-2 mt-2">
              <button
                onClick={() => handleAdjustQuantity(-1)}
                className="w-7 h-7 rounded-full bg-gray-100 hover:bg-gray-200 flex items-center justify-center text-gray-600"
              >
                <Minus size={14} />
              </button>
              <span className="text-sm font-medium text-gray-700 min-w-[3rem] text-center">
                {ingredient.quantity}
              </span>
              <button
                onClick={() => handleAdjustQuantity(1)}
                className="w-7 h-7 rounded-full bg-green-100 hover:bg-green-200 flex items-center justify-center text-green-600"
              >
                <Plus size={14} />
              </button>
            </div>
          </div>

          {/* 操作按钮 */}
          <div className="flex flex-col items-end gap-2">
            <Badge className={`text-xs ${status.color}`}>
              {status.label}
            </Badge>
            <div className="flex items-center gap-1">
              <Button
                size="icon"
                variant="ghost"
                className="h-7 w-7 text-gray-400 hover:text-green-500"
                onClick={() => setIsEditing(true)}
              >
                <Edit2 size={14} />
              </Button>
              <Button
                size="icon"
                variant="ghost"
                className="h-7 w-7 text-gray-400 hover:text-red-500"
                onClick={() => onDelete(ingredient.id)}
              >
                <Trash2 size={14} />
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default IngredientCard;
