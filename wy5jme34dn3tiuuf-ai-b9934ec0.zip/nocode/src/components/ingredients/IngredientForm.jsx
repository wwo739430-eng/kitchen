import { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Camera, Plus, X, Image as ImageIcon } from 'lucide-react';
import { getIngredientEmoji } from '@/lib/recipeEmojis';
import { toast } from 'sonner';

const STORAGE_LOCATIONS = [
  { value: '冷藏', label: '冷藏', icon: '❄️', color: 'bg-blue-50 text-blue-600' },
  { value: '冷冻', label: '冷冻', icon: '🧊', color: 'bg-cyan-50 text-cyan-600' },
  { value: '常温', label: '常温', icon: '🌡️', color: 'bg-orange-50 text-orange-600' },
  { value: '调料', label: '调料', icon: '🧂', color: 'bg-purple-50 text-purple-600' },
];

const COMMON_INGREDIENTS = [
  '鸡蛋', '西红柿', '土豆', '青椒', '洋葱', 
  '大蒜', '生姜', '胡萝卜', '黄瓜', '茄子',
  '鸡肉', '猪肉', '牛肉', '鱼', '虾',
  '豆腐', '白菜', '菠菜', '芹菜', '豆角',
  '生抽', '老抽', '料酒', '醋', '盐', '糖',
  '蚝油', '香油', '花椒', '八角', '桂皮'
];

const IngredientForm = ({ onSubmit, isLoading }) => {
  const [formData, setFormData] = useState({
    name: '',
    quantity: '',
    expiry_days: 7,
    storage_location: '冷藏',
    image: '',
  });
  const [showCommon, setShowCommon] = useState(false);
  const [showCamera, setShowCamera] = useState(false);
  const fileInputRef = useRef(null);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.name.trim()) {
      toast.error('请输入食材名称');
      return;
    }
    
    onSubmit({
      ...formData,
      name: formData.name.trim(),
      quantity: formData.quantity.trim() || '适量',
      image: formData.image || `https://nocode.meituan.com/photo/search?keyword=${encodeURIComponent(formData.name)}&width=200&height=200`,
    });
    
    // 重置表单
    setFormData({
      name: '',
      quantity: '',
      expiry_days: 7,
      storage_location: '冷藏',
      image: '',
    });
    setShowCommon(false);
    setShowCamera(false);
  };

  const selectCommon = (name) => {
    setFormData(prev => ({ 
      ...prev, 
      name,
      image: `https://nocode.meituan.com/photo/search?keyword=${encodeURIComponent(name)}&width=200&height=200`
    }));
    setShowCommon(false);
  };

  // 处理摄像头/图片选择
  const handleCameraClick = () => {
    setShowCamera(true);
  };

  const handleFileSelect = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setFormData(prev => ({ ...prev, image: event.target.result }));
        toast.success('图片已选择');
      };
      reader.readAsDataURL(file);
    }
    setShowCamera(false);
  };

  const handleTakePhoto = () => {
    // 模拟拍照功能
    toast.info('正在启动摄像头...');
    // 在实际小程序中，这里会调用 wx.chooseImage 或 camera API
    // 现在先打开文件选择器作为演示
    fileInputRef.current?.click();
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 bg-white p-4 rounded-2xl shadow-sm border border-green-100">
      {/* 图片选择和预览 */}
      <div className="space-y-2">
        <Label className="text-sm font-medium text-gray-700">食材图片</Label>
        <div className="flex items-center gap-3">
          {formData.image ? (
            <div className="relative">
              <img 
                src={formData.image} 
                alt="预览" 
                className="w-20 h-20 rounded-xl object-cover border-2 border-green-200"
              />
              <button
                type="button"
                onClick={() => setFormData(prev => ({ ...prev, image: '' }))}
                className="absolute -top-2 -right-2 w-6 h-6 bg-red-500 text-white rounded-full flex items-center justify-center text-xs"
              >
                <X size={14} />
              </button>
            </div>
          ) : (
            <div className="w-20 h-20 rounded-xl bg-green-50 border-2 border-dashed border-green-200 flex items-center justify-center text-3xl">
              {formData.name ? getIngredientEmoji(formData.name) : '🥬'}
            </div>
          )}
          <div className="flex gap-2">
            <button
              type="button"
              onClick={handleCameraClick}
              className="flex items-center gap-2 px-4 py-2 bg-green-100 text-green-700 rounded-xl hover:bg-green-200 transition-colors"
            >
              <Camera size={18} />
              <span className="text-sm">拍照</span>
            </button>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={handleFileSelect}
            />
          </div>
        </div>
      </div>

      {/* 相机弹窗 */}
      {showCamera && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl p-6 w-full max-w-sm">
            <div className="text-center mb-4">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-3">
                <Camera size={32} className="text-green-600" />
              </div>
              <h3 className="font-bold text-gray-800">添加食材图片</h3>
              <p className="text-sm text-gray-500 mt-1">拍照或从相册选择</p>
            </div>
            <div className="space-y-2">
              <button
                type="button"
                onClick={handleTakePhoto}
                className="w-full py-3 bg-green-500 text-white rounded-xl font-medium hover:bg-green-600 transition-colors"
              >
                📷 拍照
              </button>
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="w-full py-3 bg-gray-100 text-gray-700 rounded-xl font-medium hover:bg-gray-200 transition-colors"
              >
                🖼️ 从相册选择
              </button>
              <button
                type="button"
                onClick={() => setShowCamera(false)}
                className="w-full py-3 text-gray-500 hover:text-gray-700 transition-colors"
              >
                取消
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="space-y-2">
        <Label className="text-sm font-medium text-gray-700">食材名称</Label>
        <div className="relative">
          <Input
            value={formData.name}
            onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
            placeholder="输入食材名称..."
            className="pr-10 border-green-200 focus:border-green-400"
          />
          <button
            type="button"
            onClick={() => setShowCommon(!showCommon)}
            className="absolute right-2 top-1/2 -translate-y-1/2 text-green-500 hover:text-green-600 p-1"
          >
            {formData.name ? (
              <span className="text-lg">{getIngredientEmoji(formData.name)}</span>
            ) : (
              <ImageIcon size={18} />
            )}
          </button>
        </div>
        
        {showCommon && (
          <div className="flex flex-wrap gap-2 mt-2 p-3 bg-green-50 rounded-xl max-h-40 overflow-y-auto">
            {COMMON_INGREDIENTS.map(ing => (
              <button
                key={ing}
                type="button"
                onClick={() => selectCommon(ing)}
                className="px-3 py-1.5 text-sm bg-white border border-green-200 rounded-full hover:bg-green-100 hover:border-green-300 transition-colors flex items-center gap-1"
              >
                <span>{getIngredientEmoji(ing)}</span>
                {ing}
              </button>
            ))}
          </div>
        )}
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div className="space-y-2">
          <Label className="text-sm font-medium text-gray-700">数量</Label>
          <Input
            value={formData.quantity}
            onChange={(e) => setFormData(prev => ({ ...prev, quantity: e.target.value }))}
            placeholder="如: 3个, 500g"
            className="border-green-200 focus:border-green-400"
          />
        </div>
        <div className="space-y-2">
          <Label className="text-sm font-medium text-gray-700">保质期(天)</Label>
          <Input
            type="number"
            min={1}
            max={365}
            value={formData.expiry_days}
            onChange={(e) => setFormData(prev => ({ ...prev, expiry_days: parseInt(e.target.value) || 7 }))}
            className="border-green-200 focus:border-green-400"
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label className="text-sm font-medium text-gray-700">存放位置</Label>
        <div className="grid grid-cols-4 gap-2">
          {STORAGE_LOCATIONS.map(loc => (
            <button
              key={loc.value}
              type="button"
              onClick={() => setFormData(prev => ({ ...prev, storage_location: loc.value }))}
              className={`flex flex-col items-center p-3 rounded-xl border-2 transition-all ${
                formData.storage_location === loc.value
                  ? 'border-green-400 bg-green-50'
                  : 'border-gray-100 bg-white hover:border-green-200'
              }`}
            >
              <span className="text-xl mb-1">{loc.icon}</span>
              <span className={`text-xs font-medium ${
                formData.storage_location === loc.value ? 'text-green-700' : 'text-gray-600'
              }`}>
                {loc.label}
              </span>
            </button>
          ))}
        </div>
      </div>

      <Button 
        type="submit" 
        className="w-full bg-green-500 hover:bg-green-600 text-white rounded-xl h-12 font-medium"
        disabled={isLoading || !formData.name.trim()}
      >
        <Plus size={18} className="mr-2" />
        {isLoading ? '添加中...' : '添加食材'}
      </Button>
    </form>
  );
};

export default IngredientForm;
