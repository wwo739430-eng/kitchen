import { Alert, AlertDescription } from '@/components/ui/alert';
import { AlertTriangle } from 'lucide-react';

const ExpiringAlert = ({ ingredients, remainingDaysFn }) => {
  const expiringItems = ingredients
    .map(ing => ({
      ...ing,
      remaining: remainingDaysFn(ing.created_at, ing.expiry_days)
    }))
    .filter(ing => ing.remaining <= 2 && ing.remaining >= 0)
    .sort((a, b) => a.remaining - b.remaining);

  if (expiringItems.length === 0) return null;

  return (
    <Alert className="bg-orange-50 border-orange-200 text-orange-800">
      <AlertTriangle className="h-4 w-4 text-orange-500" />
      <AlertDescription>
        <span className="font-medium">食材提醒：</span>
        {expiringItems.slice(0, 3).map((item, idx) => (
          <span key={item.id}>
            {idx > 0 && '、'}
            {item.name}
            {item.remaining <= 0 ? '（已过期）' : `（${item.remaining}天后过期）`}
          </span>
        ))}
        {expiringItems.length > 3 && ` 等${expiringItems.length}种食材`}
        <span className="text-xs ml-2 opacity-75">推荐优先使用这些食材做菜</span>
      </AlertDescription>
    </Alert>
  );
};

export default ExpiringAlert;
