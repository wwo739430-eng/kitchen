import { useState } from 'react';
import { 
  Home, 
  Package, 
  Heart, 
  ShoppingCart, 
  Settings,
  ChefHat
} from 'lucide-react';
import { cn } from '@/lib/utils';

const menuItems = [
  { id: 'home', label: '首页', icon: Home },
  { id: 'ingredients', label: '食材', icon: Package },
  { id: 'favorites', label: '收藏', icon: Heart },
  { id: 'shopping', label: '购物', icon: ShoppingCart },
  { id: 'settings', label: '设置', icon: Settings },
];

const BottomNav = ({ activePage, onPageChange }) => {
  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-green-100 z-50 pb-safe">
      <div className="max-w-lg mx-auto flex items-center justify-around py-2">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = activePage === item.id;
          const isHome = item.id === 'home';
          
          return (
            <button
              key={item.id}
              onClick={() => onPageChange(item.id)}
              className="relative flex flex-col items-center py-1 px-3"
            >
              {/* 突起效果 - 首页在中间且有突起 */}
              {isHome && isActive && (
                <div className="absolute -top-6 w-14 h-14 bg-gradient-to-br from-green-400 to-green-600 rounded-full flex items-center justify-center shadow-lg shadow-green-200">
                  <ChefHat size={24} className="text-white" />
                </div>
              )}
              
              {/* 普通图标 */}
              <div className={cn(
                "transition-all duration-300",
                isHome ? (isActive ? "opacity-0" : "opacity-100") : "",
                !isHome && isActive ? "-translate-y-1" : ""
              )}>
                <Icon 
                  size={24} 
                  className={cn(
                    "transition-colors",
                    isActive ? "text-green-600" : "text-gray-400"
                  )} 
                />
              </div>
              
              {/* 标签 */}
              <span className={cn(
                "text-xs mt-1 transition-all duration-300",
                isActive ? "text-green-600 font-medium" : "text-gray-400",
                !isHome && isActive ? "-translate-y-1" : ""
              )}>
                {item.label}
              </span>
              
              {/* 活跃指示器 */}
              {isActive && !isHome && (
                <div className="absolute -bottom-1 w-1 h-1 bg-green-500 rounded-full" />
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
};

export default BottomNav;
