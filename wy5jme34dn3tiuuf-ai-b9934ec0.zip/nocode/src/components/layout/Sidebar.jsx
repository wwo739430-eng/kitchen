import { useState } from 'react';
import { 
  Home, 
  Package, 
  Heart, 
  ShoppingCart, 
  Settings,
  ChefHat,
  X
} from 'lucide-react';
import { cn } from '@/lib/utils';

const menuItems = [
  { id: 'home', label: '首页', icon: Home },
  { id: 'ingredients', label: '我的食材', icon: Package },
  { id: 'favorites', label: '收藏夹', icon: Heart },
  { id: 'shopping', label: '购物清单', icon: ShoppingCart },
  { id: 'settings', label: '设置', icon: Settings },
];

const Sidebar = ({ activePage, onPageChange, isOpen, onClose }) => {
  return (
    <>
      {/* 遮罩层 */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/30 z-40 lg:hidden"
          onClick={onClose}
        />
      )}
      
      {/* 侧边栏 */}
      <div className={cn(
        "fixed left-0 top-0 h-full w-64 bg-white z-50 transform transition-transform duration-300 ease-in-out",
        "lg:translate-x-0 lg:static lg:h-screen",
        isOpen ? "translate-x-0" : "-translate-x-full"
      )}>
        {/* Logo区域 */}
        <div className="p-6 border-b border-green-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-green-400 to-green-600 flex items-center justify-center">
              <ChefHat size={20} className="text-white" />
            </div>
            <div>
              <h1 className="font-bold text-green-800">心情厨房 AI</h1>
              <p className="text-xs text-green-600">Cloudy 正在烹饪！</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="absolute top-4 right-4 p-2 rounded-lg hover:bg-green-50 lg:hidden"
          >
            <X size={20} className="text-green-600" />
          </button>
        </div>

        {/* 菜单 */}
        <nav className="p-4 space-y-2">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = activePage === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  onPageChange(item.id);
                  onClose();
                }}
                className={cn(
                  "w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all",
                  isActive 
                    ? "bg-green-100 text-green-700 font-medium"
                    : "text-gray-600 hover:bg-green-50 hover:text-green-600"
                )}
              >
                <Icon size={20} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* 底部生成按钮 */}
        <div className="absolute bottom-6 left-4 right-4">
          <button className="w-full flex items-center justify-center gap-2 bg-green-500 hover:bg-green-600 text-white py-3 px-4 rounded-xl font-medium transition-colors shadow-lg shadow-green-200">
            <span className="text-lg">+</span>
            生成新食谱
          </button>
        </div>
      </div>
    </>
  );
};

export default Sidebar;
