import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Slider } from '@/components/ui/slider';
import { cn } from '@/lib/utils';
import { Zap, Coffee, Sun, Moon } from 'lucide-react';

const MOOD_LEVELS = [
  { value: 0, label: '心情低落', emoji: '😢', desc: '需要治愈', subDesc: '想来点温暖的食物', color: 'from-blue-400 to-indigo-500', bgColor: 'bg-blue-50' },
  { value: 1, label: '身体疲惫', emoji: '😔', desc: '需要能量', subDesc: '想要快速补充能量', color: 'from-yellow-400 to-orange-400', bgColor: 'bg-yellow-50' },
  { value: 2, label: '状态一般', emoji: '😐', desc: '平平淡淡', subDesc: '正常吃饭就好', color: 'from-green-400 to-emerald-500', bgColor: 'bg-green-50' },
  { value: 3, label: '心情不错', emoji: '😊', desc: '享受美食', subDesc: '有心情好好做顿饭', color: 'from-pink-400 to-rose-500', bgColor: 'bg-pink-50' },
  { value: 4, label: '阳光灿烂', emoji: '🤗', desc: '想尝试新菜', subDesc: '想要尝试新花样', color: 'from-purple-400 to-violet-500', bgColor: 'bg-purple-50' },
];

const MEAL_TYPES = [
  { id: 'simple', label: '简餐快手', emoji: '⚡', desc: '10分钟搞定', time: 10, icon: Zap },
  { id: 'normal', label: '家常美味', emoji: '🍳', desc: '30分钟烹饪', time: 30, icon: Coffee },
  { id: 'elaborate', label: '精致大餐', emoji: '👨‍🍳', desc: '60分钟用心', time: 60, icon: Sun },
];

const MoodAndMealSelector = ({ preferences, onUpdate }) => {
  const [moodLevel, setMoodLevel] = useState(2);
  const [mealType, setMealType] = useState('normal');

  const handleMoodChange = (value) => {
    const level = value[0];
    setMoodLevel(level);
    const moods = ['低落', '疲惫', '一般', '不错', '开心'];
    const updated = { 
      ...preferences, 
      current_mood: moods[level],
      moodLevel: level 
    };
    onUpdate(updated);
  };

  const handleMealSelect = (type) => {
    setMealType(type.id);
    const updated = { 
      ...preferences, 
      mealType: type.id,
      maxCookTime: type.time 
    };
    onUpdate(updated);
  };

  const currentMood = MOOD_LEVELS[moodLevel];

  return (
    <div className="space-y-4">
      {/* 心情选择 - 首位展示 */}
      <Card className={cn(
        "border-0 overflow-hidden",
        currentMood.bgColor
      )}>
        <CardContent className="p-5">
          <div className="text-center mb-6">
            <h3 className="text-xl font-bold text-gray-800">今天心情怎么样？</h3>
            <p className="text-sm text-gray-500 mt-1">{currentMood.subDesc}</p>
          </div>
          
          {/* 心情表情显示 */}
          <div className="flex justify-center mb-6">
            <div className={cn(
              "w-24 h-24 rounded-full bg-gradient-to-br flex items-center justify-center text-5xl shadow-lg transform transition-all duration-300",
              currentMood.color
            )}>
              {currentMood.emoji}
            </div>
          </div>

          {/* 滑块 */}
          <div className="px-2 mb-4">
            <Slider
              value={[moodLevel]}
              onValueChange={handleMoodChange}
              max={4}
              step={1}
              className="w-full"
            />
            <div className="flex justify-between mt-3 text-xs">
              {MOOD_LEVELS.map((m) => (
                <span 
                  key={m.value} 
                  className={cn(
                    "transition-all duration-300",
                    moodLevel === m.value ? 'font-bold text-gray-800 scale-110' : 'text-gray-400'
                  )}
                >
                  {m.label}
                </span>
              ))}
            </div>
          </div>

          {/* 当前心情描述卡片 */}
          <div className="bg-white/70 backdrop-blur rounded-2xl p-4 text-center shadow-sm">
            <p className="text-base font-medium text-gray-800">
              {currentMood.desc}
            </p>
          </div>
        </CardContent>
      </Card>

      {/* 用餐类型选择 */}
      <Card className="border-green-100">
        <CardContent className="p-5">
          <h3 className="text-base font-medium text-gray-700 mb-4 flex items-center gap-2">
            <span className="w-8 h-8 rounded-lg bg-green-100 flex items-center justify-center">
              <span className="text-lg">🍽️</span>
            </span>
            今天想怎么吃？
          </h3>
          
          <div className="grid grid-cols-3 gap-3">
            {MEAL_TYPES.map((type) => {
              const Icon = type.icon;
              return (
                <button
                  key={type.id}
                  onClick={() => handleMealSelect(type)}
                  className={cn(
                    "flex flex-col items-center p-4 rounded-2xl border-2 transition-all",
                    mealType === type.id
                      ? 'border-green-400 bg-green-50 shadow-md'
                      : 'border-gray-100 bg-white hover:border-green-200'
                  )}
                >
                  <div className={cn(
                    "w-12 h-12 rounded-xl flex items-center justify-center text-2xl mb-2 transition-all",
                    mealType === type.id ? 'bg-green-500 text-white' : 'bg-gray-100'
                  )}>
                    {type.emoji}
                  </div>
                  <span className={cn(
                    "text-sm font-medium",
                    mealType === type.id ? 'text-green-700' : 'text-gray-700'
                  )}>
                    {type.label}
                  </span>
                  <span className="text-xs text-gray-400 mt-1">{type.desc}</span>
                </button>
              );
            })}
          </div>
          
          {/* 提示信息 */}
          <div className="mt-4 p-3 bg-green-50 rounded-xl">
            <p className="text-sm text-green-700 text-center">
              {mealType === 'simple' && '💡 简餐推荐：10分钟内搞定的快手菜，省时又美味！'}
              {mealType === 'normal' && '💡 家常推荐：30分钟左右的经典家常菜，营养均衡！'}
              {mealType === 'elaborate' && '💡 精致推荐：60分钟的美味大餐，犒劳辛苦的自己！'}
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default MoodAndMealSelector;
