import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Slider } from '@/components/ui/slider';
import { cn } from '@/lib/utils';

const MOOD_LEVELS = [
  { value: 0, label: '心情低落', emoji: '😢', desc: '需要治愈', color: 'from-blue-400 to-blue-500' },
  { value: 1, label: '身体疲惫', emoji: '😔', desc: '需要能量', color: 'from-yellow-400 to-orange-400' },
  { value: 2, label: '阳光灿烂', emoji: '😊', desc: '享受美食', color: 'from-green-400 to-green-500' },
];

const DIET_GOALS = [
  { value: '正常饮食', emoji: '🍽️', desc: '均衡营养', color: 'bg-blue-50 text-blue-600' },
  { value: '减肥', emoji: '🥗', desc: '低卡健康', color: 'bg-green-50 text-green-600' },
  { value: '解馋', emoji: '😋', desc: '美味满足', color: 'bg-orange-50 text-orange-600' },
];

const SERVINGS_OPTIONS = [1, 2, 3, 4, 5, 6];

const MoodSelector = ({ preferences, onUpdate }) => {
  const [moodLevel, setMoodLevel] = useState(1);
  const [localPrefs, setLocalPrefs] = useState(preferences);

  const handleMoodChange = (value) => {
    const level = value[0];
    setMoodLevel(level);
    const moods = ['低落', '一般', '开心'];
    const updated = { ...localPrefs, current_mood: moods[level] };
    setLocalPrefs(updated);
    onUpdate(updated);
  };

  const handleDietSelect = (goal) => {
    const updated = { ...localPrefs, diet_goal: goal };
    setLocalPrefs(updated);
    onUpdate(updated);
  };

  const handleServingsSelect = (servings) => {
    const updated = { ...localPrefs, servings };
    setLocalPrefs(updated);
    onUpdate(updated);
  };

  const currentMood = MOOD_LEVELS[moodLevel];

  return (
    <div className="space-y-4">
      {/* 心情滑块 */}
      <Card className="border-green-100 bg-gradient-to-br from-green-50/50 to-white">
        <CardContent className="p-5">
          <div className="text-center mb-4">
            <h3 className="text-lg font-bold text-gray-800">今天心情怎么样？</h3>
            <p className="text-sm text-gray-500 mt-1">滑动滑块告诉我你的感受，我来为你寻找最治愈的美食！</p>
          </div>
          
          {/* 心情表情显示 */}
          <div className="flex justify-center mb-6">
            <div className={cn(
              "w-20 h-20 rounded-full bg-gradient-to-br flex items-center justify-center text-4xl shadow-lg",
              currentMood.color
            )}>
              {currentMood.emoji}
            </div>
          </div>

          {/* 滑块 */}
          <div className="px-2">
            <Slider
              value={[moodLevel]}
              onValueChange={handleMoodChange}
              max={2}
              step={1}
              className="w-full"
            />
            <div className="flex justify-between mt-2 text-xs text-gray-500">
              {MOOD_LEVELS.map((m) => (
                <span key={m.value} className={moodLevel === m.value ? 'font-medium text-green-600' : ''}>
                  {m.label}
                </span>
              ))}
            </div>
          </div>

          {/* 当前心情描述 */}
          <div className="mt-4 p-3 bg-white/80 rounded-xl text-center">
            <p className="text-sm text-gray-600">
              <span className="font-medium text-green-600">{currentMood.label}</span>
              <span className="mx-2">·</span>
              <span className="text-gray-500">{currentMood.desc}</span>
            </p>
          </div>
        </CardContent>
      </Card>

      {/* 饮食目标 */}
      <Card className="border-green-100">
        <CardContent className="p-4">
          <h3 className="text-sm font-medium text-gray-700 mb-3 flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-green-500"></span>
            饮食目标
          </h3>
          <div className="grid grid-cols-3 gap-3">
            {DIET_GOALS.map((goal) => (
              <button
                key={goal.value}
                onClick={() => handleDietSelect(goal.value)}
                className={cn(
                  "flex flex-col items-center p-3 rounded-xl border-2 transition-all",
                  localPrefs.diet_goal === goal.value
                    ? 'border-green-400 bg-green-50'
                    : 'border-gray-100 bg-white hover:border-green-200'
                )}
              >
                <span className="text-2xl mb-1">{goal.emoji}</span>
                <span className={cn(
                  "text-sm font-medium",
                  localPrefs.diet_goal === goal.value ? 'text-green-700' : 'text-gray-700'
                )}>
                  {goal.value}
                </span>
                <span className="text-xs text-gray-400 mt-0.5">{goal.desc}</span>
              </button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* 用餐人数 */}
      <Card className="border-green-100">
        <CardContent className="p-4">
          <h3 className="text-sm font-medium text-gray-700 mb-3 flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-green-500"></span>
            用餐人数
          </h3>
          <div className="flex gap-2">
            {SERVINGS_OPTIONS.map((num) => (
              <button
                key={num}
                onClick={() => handleServingsSelect(num)}
                className={cn(
                  "w-10 h-10 rounded-lg border-2 font-medium transition-all flex items-center justify-center",
                  localPrefs.servings === num
                    ? 'border-green-400 bg-green-500 text-white'
                    : 'border-gray-200 bg-white hover:border-green-300 text-gray-700'
                )}
              >
                {num}
              </button>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default MoodSelector;
