import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Clock, Users, Flame, Check, X, ShoppingCart } from 'lucide-react';

const RecipeDetail = ({ recipe, isOpen, onClose, servings, adjustAmount }) => {
  if (!recipe) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md max-h-[90vh] p-0 overflow-hidden">
        <div className="relative h-48 bg-gray-100">
          <img 
            src={recipe.image || `https://nocode.meituan.com/photo/search?keyword=food&width=400&height=300`}
            alt={recipe.name}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
          <div className="absolute bottom-4 left-4 right-4">
            <DialogHeader>
              <DialogTitle className="text-white text-xl">{recipe.name}</DialogTitle>
            </DialogHeader>
          </div>
        </div>

        <ScrollArea className="max-h-[calc(90vh-12rem)]">
          <div className="p-4 space-y-4">
            {/* 基本信息 */}
            <div className="flex items-center gap-4 text-sm">
              <Badge variant="secondary" className="flex items-center gap-1">
                <Clock size={14} />
                {recipe.cook_time}分钟
              </Badge>
              <Badge variant="secondary" className="flex items-center gap-1">
                <Users size={14} />
                {servings}人份
              </Badge>
              <Badge variant="secondary" className="flex items-center gap-1">
                <Flame size={14} />
                {recipe.calories_tag}
              </Badge>
            </div>

            {/* 食材清单 */}
            <div>
              <h4 className="font-medium text-gray-800 mb-2">所需食材</h4>
              <div className="space-y-2">
                {recipe.ingredients?.map((ing, idx) => {
                  const hasIngredient = recipe.hasIngredients?.some(
                    hi => hi.ingredient_name === ing.ingredient_name
                  );
                  return (
                    <div key={idx} className="flex items-center justify-between py-1 border-b border-gray-100 last:border-0">
                      <span className="flex items-center gap-2">
                        {hasIngredient ? (
                          <Check size={16} className="text-green-500" />
                        ) : (
                          <X size={16} className="text-red-400" />
                        )}
                        {ing.ingredient_name}
                      </span>
                      <span className="text-gray-500 text-sm">
                        {adjustAmount ? adjustAmount(ing.amount) : ing.amount}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* 烹饪步骤 */}
            <div>
              <h4 className="font-medium text-gray-800 mb-2">烹饪步骤</h4>
              <div className="space-y-3">
                {recipe.steps?.map((step, idx) => (
                  <div key={idx} className="flex gap-3">
                    <span className="flex-shrink-0 w-6 h-6 rounded-full bg-orange-100 text-orange-600 text-sm font-medium flex items-center justify-center">
                      {idx + 1}
                    </span>
                    <p className="text-sm text-gray-600 leading-relaxed pt-0.5">{step}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* 购物清单按钮 */}
            {!recipe.canCook && (
              <Button className="w-full bg-orange-400 hover:bg-orange-500">
                <ShoppingCart size={16} className="mr-2" />
                生成购物清单
              </Button>
            )}
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
};

export default RecipeDetail;
