import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Copy, Check, ShoppingBag } from 'lucide-react';
import { toast } from 'sonner';

const ShoppingList = ({ items, isOpen, onClose }) => {
  const [checkedItems, setCheckedItems] = useState({});
  const [copied, setCopied] = useState(false);

  const toggleItem = (index) => {
    setCheckedItems(prev => ({
      ...prev,
      [index]: !prev[index]
    }));
  };

  const copyToClipboard = () => {
    const text = items.map(item => `${item.name} ${item.amount}`).join('\n');
    navigator.clipboard.writeText(`购物清单：\n${text}`);
    setCopied(true);
    toast.success('已复制到剪贴板');
    setTimeout(() => setCopied(false), 2000);
  };

  const allChecked = items.length > 0 && items.every((_, idx) => checkedItems[idx]);

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-sm">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ShoppingBag size={20} className="text-orange-500" />
            购物清单
          </DialogTitle>
        </DialogHeader>
        
        <ScrollArea className="max-h-[60vh]">
          <div className="space-y-3 py-4">
            {items.length === 0 ? (
              <p className="text-center text-gray-500 py-8">暂无需要购买的食材</p>
            ) : (
              items.map((item, idx) => (
                <div 
                  key={idx} 
                  className="flex items-center gap-3 p-3 rounded-lg bg-gray-50 hover:bg-gray-100 transition-colors"
                >
                  <Checkbox 
                    checked={checkedItems[idx] || false}
                    onCheckedChange={() => toggleItem(idx)}
                  />
                  <span className={`flex-1 ${checkedItems[idx] ? 'line-through text-gray-400' : 'text-gray-700'}`}>
                    {item.name}
                  </span>
                  <span className="text-sm text-gray-500">{item.amount}</span>
                </div>
              ))
            )}
          </div>
        </ScrollArea>

        {items.length > 0 && (
          <div className="flex gap-2 pt-2 border-t">
            <Button 
              variant="outline" 
              className="flex-1"
              onClick={copyToClipboard}
            >
              {copied ? <Check size={16} className="mr-2" /> : <Copy size={16} className="mr-2" />}
              {copied ? '已复制' : '复制清单'}
            </Button>
            <Button 
              className={`flex-1 ${allChecked ? 'bg-green-500 hover:bg-green-600' : 'bg-orange-400 hover:bg-orange-500'}`}
              onClick={() => {
                if (allChecked) {
                  toast.success('购物完成！');
                  onClose();
                } else {
                  toast.info('请勾选所有食材');
                }
              }}
            >
              {allChecked ? '完成购物' : '去购物'}
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};

export default ShoppingList;
