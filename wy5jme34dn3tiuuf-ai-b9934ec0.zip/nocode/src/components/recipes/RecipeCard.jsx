import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Clock, Users, ChefHat, ShoppingCart, Check, Heart, Flame } from 'lucide-react';
import RecipeDetail from './RecipeDetail';
import { getRecipeEmoji } from '@/lib/recipeEmojis';
import { cn } from '@/lib/utils';

const CALORIE_COLORS = {
  '低热量': 'bg-blue-100 text-blue-700 border-blue-200',
  '正常': 'bg-green-100 text-green-700 border-green-200',
  '高热量': 'bg-orange-100 text-orange-700 border-orange-200',
};

const RecipeCard = ({ recipe, servings, onAddToShopping, isFavorite, onToggleFavorite, variant = 'vertical' }) => {
  const [showDetail, setShowDetail] = useState(false);
  const recipeEmoji = getRecipeEmoji(recipe.name);

  // 根据人数调整用量
  const adjustAmount = (amount) => {
    if (!amount) return '';
    const ratio = servings / (recipe.servings || 2);
    const match = amount.match(/(\d+\.?\d*)\s*(.*)/);
    if (match) {
      const num = parseFloat(match[1]) * ratio;
      return `${Math.round(num * 10) / 10}${match[2]}`;
    }
    return amount;
  };

  // 判断是否为调料
  const isSpice = (ingName) => {
    const spiceKeywords = ['盐', '糖', '酱油', '醋', '料酒', '油', '酱', '蚝油', '香油', '花椒', '八角', '桂皮', '辣椒', '葱', '姜', '蒜', '胡椒', '孜然', '芝麻', '粉', '精', '味精', '鸡精', '五香粉', '香料', '卤料', '茶叶', '豆豉'];
    return spiceKeywords.some(keyword => ingName.includes(keyword));
  };

  // 分离主要食材和调料
  const mainHasIngredients = recipe.hasIngredients?.filter(ing => !isSpice(ing.ingredient_name)) || [];
  const spiceHasIngredients = recipe.hasIngredients?.filter(ing => isSpice(ing.ingredient_name)) || [];
  const mainMissingIngredients = recipe.missingIngredients?.filter(ing => !isSpice(ing.ingredient_name)) || [];
  const spiceMissingIngredients = recipe.missingIngredients?.filter(ing => isSpice(ing.ingredient_name)) || [];

  // 横向布局（首页推荐样式）
  if (variant === 'horizontal') {
    return (
      <>
        <Card 
          className="overflow-hidden hover:shadow-lg transition-all cursor-pointer border-0 shadow-md"
          onClick={() => setShowDetail(true)}
        >
          {/* 图片区域 - 全宽 */}
          <div className="relative h-40 bg-gray-100">
            <img 
              src={recipe.image || `https://nocode.meituan.com/photo/search?keyword=food&width=400&height=300`}
              alt={recipe.name}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
            
            {/* 左上角 - 步骤图标 */}
            <div className="absolute top-3 left-3 w-10 h-10 bg-white/95 backdrop-blur rounded-xl flex items-center justify-center shadow-md">
              <span className="text-xl">{recipeEmoji}</span>
            </div>

            {/* 右上角 - 缺食材提示 */}
            {!recipe.canCook && mainMissingIngredients.length > 0 && (
              <Badge className="absolute top-3 right-3 bg-orange-500 text-white border-0 font-medium">
                缺{mainMissingIngredients.length}种食材
              </Badge>
            )}
            
            {/* 只缺调料提示 */}
            {!recipe.canCook && mainMissingIngredients.length === 0 && spiceMissingIngredients.length > 0 && (
              <Badge className="absolute top-3 right-3 bg-yellow-500 text-white border-0 font-medium">
                只差调料
              </Badge>
            )}
            
            {/* 左下角 - 热量标签 */}
            <Badge className={`absolute bottom-3 left-3 ${CALORIE_COLORS[recipe.calories_tag] || CALORIE_COLORS['正常']}`}>
              {recipe.calories_tag}
            </Badge>
          </div>
          
          <CardContent className="p-4">
            {/* 菜名 */}
            <h3 className="font-bold text-lg text-gray-800 mb-3">{recipe.name}</h3>
            
            {/* 食材匹配状态 */}
            <div className="flex items-center gap-2 mb-3">
              {recipe.canCook ? (
                <Badge className="bg-green-100 text-green-700 border-0">
                  <Check size={12} className="mr-1" />
                  食材齐全
                </Badge>
              ) : mainMissingIngredients.length === 0 ? (
                <Badge className="bg-yellow-100 text-yellow-700 border-0">
                  <Check size={12} className="mr-1" />
                  主料齐全，只差调料
                </Badge>
              ) : (
                <Badge className="bg-orange-100 text-orange-700 border-0">
                  缺 {mainMissingIngredients.length} 种主料
                </Badge>
              )}
              
              {/* 显示匹配率 */}
              <span className="text-xs text-gray-500">
                匹配度 {Math.round((recipe.mainMatchRate || recipe.matchRate || 0) * 100)}%
              </span>
            </div>
            
            {/* 底部信息：步骤、时间、人数 */}
            <div className="flex items-center gap-4 mb-3 text-sm">
              <div className="flex items-center gap-1 text-green-600">
                <ChefHat size={16} />
                <span>{recipe.steps?.length || 3}步搞定</span>
              </div>
              <div className="flex items-center gap-1 text-gray-500">
                <Clock size={16} />
                <span>{recipe.cook_time}分钟</span>
              </div>
              <div className="flex items-center gap-1 text-gray-500">
                <Users size={16} />
                <span>{servings}人份</span>
              </div>
            </div>

            {/* 食材标签 - 主料 */}
            <div className="flex flex-wrap gap-2 mb-3">
              {mainHasIngredients.slice(0, 2).map((ing, idx) => (
                <span key={idx} className="inline-flex items-center gap-1 px-2 py-1 bg-green-50 text-green-600 rounded-full text-xs">
                  <span>{getRecipeEmoji(ing.ingredient_name)}</span>
                  {ing.ingredient_name}
                </span>
              ))}
              {mainMissingIngredients.slice(0, 1).map((ing, idx) => (
                <span key={`miss-${idx}`} className="inline-flex items-center gap-1 px-2 py-1 bg-orange-50 text-orange-600 rounded-full text-xs">
                  <span>+</span>
                  {ing.ingredient_name}
                </span>
              ))}
            </div>

            {/* 调料标签（小字显示） */}
            {(spiceHasIngredients.length > 0 || spiceMissingIngredients.length > 0) && (
              <div className="flex flex-wrap gap-1 mb-3">
                <span className="text-xs text-gray-400">调料:</span>
                {spiceHasIngredients.slice(0, 3).map((ing, idx) => (
                  <span key={idx} className="text-xs text-green-500">
                    ✓{ing.ingredient_name}
                  </span>
                ))}
                {spiceMissingIngredients.slice(0, 2).map((ing, idx) => (
                  <span key={`spice-miss-${idx}`} className="text-xs text-gray-400 line-through">
                    {ing.ingredient_name}
                  </span>
                ))}
              </div>
            )}

            {/* 加入购物清单按钮 */}
            {mainMissingIngredients.length > 0 && (
              <Button 
                variant="outline" 
                className="w-full border-orange-300 text-orange-600 hover:bg-orange-50 rounded-xl h-10"
                onClick={(e) => {
                  e.stopPropagation();
                  onAddToShopping?.(recipe);
                }}
              >
                <ShoppingCart size={16} className="mr-2" />
                加入购物清单
              </Button>
            )}
            
            {/* 只差调料时的提示按钮 */}
            {mainMissingIngredients.length === 0 && spiceMissingIngredients.length > 0 && (
              <Button 
                variant="outline" 
                className="w-full border-yellow-300 text-yellow-600 hover:bg-yellow-50 rounded-xl h-10"
                onClick={(e) => {
                  e.stopPropagation();
                  onAddToShopping?.(recipe);
                }}
              >
                <ShoppingCart size={16} className="mr-2" />
                补充调料
              </Button>
            )}
            
            {/* 收藏按钮 */}
            <button
              onClick={(e) => {
                e.stopPropagation();
                onToggleFavorite?.(recipe);
              }}
              className="absolute top-3 right-16 w-9 h-9 bg-white/90 backdrop-blur rounded-full flex items-center justify-center shadow-md hover:scale-110 transition-transform"
            >
              <Heart 
                size={18} 
                className={cn(
                  "transition-colors",
                  isFavorite ? "fill-red-500 text-red-500" : "text-gray-400"
                )} 
              />
            </button>
          </CardContent>
        </Card>

        <RecipeDetail 
          recipe={recipe} 
          isOpen={showDetail} 
          onClose={() => setShowDetail(false)}
          servings={servings}
          adjustAmount={adjustAmount}
        />
      </>
    );
  }

  // 默认纵向布局
  return (
    <>
      <Card 
        className="overflow-hidden hover:shadow-lg transition-all cursor-pointer border-0 shadow-md"
        onClick={() => setShowDetail(true)}
      >
        {/* 图片区域 */}
        <div className="relative h-44 bg-gray-100">
          <img 
            src={recipe.image || `https://nocode.meituan.com/photo/search?keyword=food&width=400&height=300`}
            alt={recipe.name}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
          
          {/* 收藏按钮 */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              onToggleFavorite?.(recipe);
            }}
            className="absolute top-3 right-3 w-9 h-9 bg-white/90 backdrop-blur rounded-full flex items-center justify-center shadow-md hover:scale-110 transition-transform"
          >
            <Heart 
              size={18} 
              className={cn(
                "transition-colors",
                isFavorite ? "fill-red-500 text-red-500" : "text-gray-400"
              )} 
            />
          </button>
          
          {/* Emoji标签 */}
          <div className="absolute top-3 left-3 w-12 h-12 bg-white/90 backdrop-blur rounded-xl flex items-center justify-center text-2xl shadow-lg">
            {recipeEmoji}
          </div>

          {/* 状态标签 */}
          {recipe.canCook ? (
            <Badge className="absolute bottom-3 right-3 bg-green-500 text-white border-0">
              <Check size={12} className="mr-1" />
              食材已备齐
            </Badge>
          ) : mainMissingIngredients.length === 0 ? (
            <Badge className="absolute bottom-3 right-3 bg-yellow-500 text-white border-0">
              <Check size={12} className="mr-1" />
              只差调料
            </Badge>
          ) : (
            <Badge className="absolute bottom-3 right-3 bg-orange-500 text-white border-0">
              缺{mainMissingIngredients.length}种主料
            </Badge>
          )}
          
          {/* 热量标签 */}
          <Badge className={`absolute bottom-3 left-3 ${CALORIE_COLORS[recipe.calories_tag]}`}>
            {recipe.calories_tag}
          </Badge>
        </div>
        
        <CardContent className="p-4">
          <div className="flex items-start justify-between mb-2">
            <h3 className="font-bold text-lg text-gray-800">{recipe.name}</h3>
            {/* 预计用时 */}
            <div className="flex items-center gap-1 text-sm text-orange-600 bg-orange-50 px-2 py-1 rounded-lg">
              <Clock size={14} />
              <span>{recipe.cook_time}分钟</span>
            </div>
          </div>
          
          {/* 匹配度显示 */}
          <div className="flex items-center gap-2 mb-2">
            <div className="flex-1 h-2 bg-gray-100 rounded-full overflow-hidden">
              <div 
                className={cn(
                  "h-full rounded-full",
                  (recipe.mainMatchRate || recipe.matchRate || 0) >= 0.8 ? "bg-green-500" :
                  (recipe.mainMatchRate || recipe.matchRate || 0) >= 0.5 ? "bg-yellow-500" : "bg-orange-500"
                )}
                style={{ width: `${Math.round((recipe.mainMatchRate || recipe.matchRate || 0) * 100)}%` }}
              />
            </div>
            <span className="text-xs text-gray-500">
              {Math.round((recipe.mainMatchRate || recipe.matchRate || 0) * 100)}%匹配
            </span>
          </div>
          
          {/* 步骤和时间 */}
          <div className="flex items-center gap-4 text-sm text-gray-500 mb-3">
            <span className="flex items-center gap-1 bg-green-50 px-2 py-1 rounded-lg">
              <ChefHat size={14} className="text-green-500" />
              <span className="text-green-700">{recipe.steps?.length}步搞定</span>
            </span>
            <span className="flex items-center gap-1">
              <Users size={14} />
              {servings}人份
            </span>
          </div>

          {/* 食材预览 - 主料 */}
          <div className="space-y-2">
            <div className="flex flex-wrap gap-1.5">
              {mainHasIngredients.slice(0, 3).map((ing, idx) => (
                <Badge key={idx} variant="outline" className="text-xs bg-green-50 text-green-600 border-green-200 rounded-full">
                  <span className="mr-1">{getRecipeEmoji(ing.ingredient_name)}</span>
                  {ing.ingredient_name}
                </Badge>
              ))}
              {mainMissingIngredients.slice(0, 2).map((ing, idx) => (
                <Badge key={`miss-${idx}`} variant="outline" className="text-xs bg-orange-50 text-orange-600 border-orange-200 rounded-full">
                  <span className="mr-1">+</span>
                  {ing.ingredient_name}
                </Badge>
              ))}
              {(recipe.ingredients?.length || 0) > 5 && (
                <Badge variant="outline" className="text-xs rounded-full">+{(recipe.ingredients?.length || 0) - 5}</Badge>
              )}
            </div>
          </div>

          {/* 购物按钮 */}
          {mainMissingIngredients.length > 0 && (
            <Button 
              size="sm" 
              variant="outline" 
              className="w-full mt-3 border-orange-300 text-orange-600 hover:bg-orange-50 rounded-xl"
              onClick={(e) => {
                e.stopPropagation();
                onAddToShopping?.(recipe);
              }}
            >
              <ShoppingCart size={14} className="mr-1" />
              加入购物清单
            </Button>
          )}
          
          {/* 只差调料时的按钮 */}
          {mainMissingIngredients.length === 0 && spiceMissingIngredients.length > 0 && (
            <Button 
              size="sm" 
              variant="outline" 
              className="w-full mt-3 border-yellow-300 text-yellow-600 hover:bg-yellow-50 rounded-xl"
              onClick={(e) => {
                e.stopPropagation();
                onAddToShopping?.(recipe);
              }}
            >
              <ShoppingCart size={14} className="mr-1" />
              补充调料
            </Button>
          )}
        </CardContent>
      </Card>

      <RecipeDetail 
        recipe={recipe} 
        isOpen={showDetail} 
        onClose={() => setShowDetail(false)}
        servings={servings}
        adjustAmount={adjustAmount}
      />
    </>
  );
};

export default RecipeCard;
