import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

// 获取所有菜谱
const fetchRecipes = async () => {
  const { data: recipes, error } = await supabase
    .from('recipes')
    .select('*');
  
  if (error) throw error;

  // 获取每个菜谱的食材
  const { data: recipeIngredients, error: riError } = await supabase
    .from('recipe_ingredients')
    .select('*');
  
  if (riError) throw riError;

  // 合并数据
  const recipesWithIngredients = recipes.map(recipe => ({
    ...recipe,
    ingredients: recipeIngredients.filter(ri => ri.recipe_id === recipe.id) || [],
  }));

  return recipesWithIngredients;
};

// 食材匹配工具函数 - 包含别名和调料匹配
const matchIngredient = (requiredName, availableNames) => {
  const reqLower = requiredName.toLowerCase();
  
  // 精确匹配
  if (availableNames.includes(reqLower)) return true;
  
  // 模糊匹配：检查是否有包含关系
  const isMatch = availableNames.some(ai => 
    ai.includes(reqLower) || reqLower.includes(ai)
  );
  if (isMatch) return true;
  
  // 常见别名匹配
  const aliases = {
    '番茄': ['西红柿', '番茄', '圣女果'],
    '西红柿': ['番茄', '西红柿'],
    '土豆': ['马铃薯', '土豆', '洋芋'],
    '马铃薯': ['土豆', '马铃薯'],
    '鸡蛋': ['蛋', '鸡蛋', '蛋清', '蛋黄'],
    '蛋': ['鸡蛋', '蛋'],
    '青椒': ['辣椒', '青椒', '尖椒'],
    '辣椒': ['青椒', '辣椒', '尖椒', '红椒'],
    '生抽': ['酱油', '生抽', '鲜酱油'],
    '酱油': ['生抽', '老抽', '酱油'],
    '老抽': ['酱油', '老抽', '红烧酱油'],
    '醋': ['陈醋', '香醋', '白醋', '米醋', '醋'],
    '料酒': ['黄酒', '料酒', '花雕'],
    '糖': ['白糖', '冰糖', '红糖', '砂糖', '糖'],
    '蒜': ['大蒜', '蒜', '蒜瓣', '蒜蓉', '蒜末'],
    '姜': ['生姜', '姜', '姜片', '姜末', '姜丝'],
    '葱': ['大葱', '小葱', '葱', '葱花', '葱段', '香葱'],
    '洋葱': ['洋葱', '葱头', '圆葱'],
    '胡椒粉': ['白胡椒', '黑胡椒', '胡椒粉', '胡椒'],
    '淀粉': ['生粉', '淀粉', '玉米淀粉', '土豆淀粉'],
    '油': ['食用油', '植物油', '色拉油', '花生油', '菜籽油', '油'],
    '香油': ['芝麻油', '香油', '麻油'],
    '盐': ['食盐', '盐', '精盐'],
    '蚝油': ['蚝汁', '蚝油'],
    '豆瓣酱': ['郫县豆瓣', '豆瓣酱', '黄豆酱', '大酱'],
    '面粉': ['面粉', '中筋面粉', '小麦粉', '普通面粉'],
    '大米': ['米', '大米', '米饭', '粳米'],
    '面条': ['面条', '挂面', '拉面', '切面', '面'],
    '粉丝': ['粉条', '粉丝', '红薯粉', '米粉'],
    '豆腐': ['嫩豆腐', '老豆腐', '北豆腐', '南豆腐', '豆腐', '豆花'],
    '牛奶': ['牛奶', '鲜牛奶', '纯牛奶', '奶'],
    '芝士': ['奶酪', '芝士', '起司', '乳酪'],
    '黄油': ['黄油', '奶油', '牛油'],
  };
  
  // 检查别名匹配
  for (const [key, aliasList] of Object.entries(aliases)) {
    if (aliasList.includes(reqLower)) {
      // 如果需要的食材是某个别名，检查用户是否有任何一种别名
      const hasAlias = aliasList.some(alias => availableNames.includes(alias));
      if (hasAlias) return true;
    }
  }
  
  return false;
};

export const useRecipes = (userPreferences, availableIngredients) => {
  const { data: allRecipes = [], isLoading, error } = useQuery({
    queryKey: ['recipes'],
    queryFn: fetchRecipes,
  });

  // 智能推荐算法 - 优先匹配已有食材
  const generateSmartRecommendations = () => {
    if (!allRecipes.length) return [];
    
    // 获取用户拥有的食材名称列表（包括调料）
    const availableIngNames = availableIngredients?.map(i => i.name.toLowerCase()) || [];
    
    // 将食材分类：主要食材 vs 调料
    const mainIngredients = availableIngredients?.filter(i => 
      i.storage_location !== '调料'
    ).map(i => i.name.toLowerCase()) || [];
    
    const spiceIngredients = availableIngredients?.filter(i => 
      i.storage_location === '调料'
    ).map(i => i.name.toLowerCase()) || [];
    
    // 计算每道菜的匹配分数
    const scoredRecipes = allRecipes.map(recipe => {
      const requiredIngredients = recipe.ingredients || [];
      
      // 分类菜谱所需食材
      const requiredMainIng = [];
      const requiredSpiceIng = [];
      
      requiredIngredients.forEach(ri => {
        // 判断是否为调料（简单判断：用量少或常见调料名称）
        const isSpice = ['调料', '盐', '糖', '酱油', '醋', '料酒', '油', '酱', '粉', '精', '蚝油', '香油', '花椒', '八角', '桂皮', '辣椒', '葱', '姜', '蒜', '胡椒', '孜然', '芝麻'].some(
          keyword => ri.ingredient_name.includes(keyword)
        ) || ri.amount?.includes('勺') || ri.amount?.includes('克') && parseInt(ri.amount) < 30;
        
        if (isSpice) {
          requiredSpiceIng.push(ri);
        } else {
          requiredMainIng.push(ri);
        }
      });
      
      // 检查已有食材和缺失食材
      const hasIngredients = [];
      const missingIngredients = [];
      const hasMainIngredients = [];
      const missingMainIngredients = [];
      const hasSpiceIngredients = [];
      const missingSpiceIngredients = [];
      
      requiredIngredients.forEach(ri => {
        const isAvailable = matchIngredient(ri.ingredient_name, availableIngNames);
        
        if (isAvailable) {
          hasIngredients.push(ri);
          if (requiredMainIng.includes(ri)) {
            hasMainIngredients.push(ri);
          } else {
            hasSpiceIngredients.push(ri);
          }
        } else {
          missingIngredients.push(ri);
          if (requiredMainIng.includes(ri)) {
            missingMainIngredients.push(ri);
          } else {
            missingSpiceIngredients.push(ri);
          }
        }
      });
      
      // 计算各类匹配率
      const totalMatchRate = requiredIngredients.length > 0 
        ? hasIngredients.length / requiredIngredients.length 
        : 0;
      
      const mainMatchRate = requiredMainIng.length > 0
        ? hasMainIngredients.length / requiredMainIng.length
        : 1;
      
      const spiceMatchRate = requiredSpiceIng.length > 0
        ? hasSpiceIngredients.length / requiredSpiceIng.length
        : 1;
      
      // 计算综合评分 - 优先已有食材匹配度
      let score = 0;
      
      // ===== 核心：已有食材匹配度权重最高 =====
      // 主要食材匹配度权重 50%
      score += mainMatchRate * 50;
      
      // 调料匹配度权重 15%
      score += spiceMatchRate * 15;
      
      // 整体匹配率权重 10%
      score += totalMatchRate * 10;
      
      // 优先推荐可以完整制作的菜谱（食材齐全）+20分
      if (missingIngredients.length === 0) {
        score += 20;
      } else if (missingMainIngredients.length === 0) {
        // 只缺调料也给予较高加分
        score += 15;
      } else if (missingMainIngredients.length <= 1) {
        // 只缺1种主要食材
        score += 8;
      } else if (missingMainIngredients.length <= 2) {
        // 缺2种主要食材
        score += 3;
      }
      
      // 根据心情加分（权重降低）
      if (userPreferences?.current_mood && recipe.mood_type) {
        const moods = recipe.mood_type.split(',');
        if (moods.some(m => userPreferences.current_mood.includes(m) || m.includes(userPreferences.current_mood))) {
          score += 3;
        }
      }
      
      // 根据用餐类型筛选时间（权重降低）
      if (userPreferences?.mealType === 'simple' && recipe.cook_time <= 15) {
        score += 2;
      } else if (userPreferences?.mealType === 'normal' && recipe.cook_time > 15 && recipe.cook_time < 45) {
        score += 2;
      } else if (userPreferences?.mealType === 'elaborate' && recipe.cook_time >= 45) {
        score += 2;
      }
      
      // 根据饮食偏好调整
      if (userPreferences?.dietPreference === 'weight_loss' && recipe.calories_tag === '低热量') {
        score += 2;
      } else if (userPreferences?.dietPreference === 'muscle' && recipe.calories_tag === '高热量') {
        score += 2;
      } else if (userPreferences?.dietPreference === 'comfort' && recipe.calories_tag === '高热量') {
        score += 2;
      }
      
      return {
        ...recipe,
        hasIngredients,
        missingIngredients,
        hasMainIngredients,
        missingMainIngredients,
        hasSpiceIngredients,
        missingSpiceIngredients,
        canCook: missingIngredients.length === 0,
        canCookMain: missingMainIngredients.length === 0, // 主料齐全（只差调料也可以做）
        mainMatchRate,
        spiceMatchRate,
        matchRate: totalMatchRate,
        score,
      };
    });
    
    // 按分数排序并返回
    return scoredRecipes
      .sort((a, b) => {
        // 首先按分数排序
        if (b.score !== a.score) return b.score - a.score;
        // 分数相同，按主料匹配率排序
        return b.mainMatchRate - a.mainMatchRate;
      })
      .slice(0, 12);
  };

  // 根据用户偏好和现有食材筛选推荐菜谱
  const getRecommendedRecipes = () => {
    if (!allRecipes.length) return [];
    
    // 获取用户拥有的食材名称列表（包括调料）
    const availableIngNames = availableIngredients?.map(i => i.name.toLowerCase()) || [];
    
    return allRecipes.filter(recipe => {
      // 根据心情筛选
      const moodMatch = !userPreferences?.current_mood || 
                       !recipe.mood_type || 
                       recipe.mood_type.includes(userPreferences.current_mood) || 
                       recipe.mood_type === '一般';
      
      // 根据烹饪时间筛选
      if (userPreferences?.maxCookTime && recipe.cook_time > userPreferences.maxCookTime) {
        return false;
      }
      
      // 根据饮食偏好筛选
      if (userPreferences?.dietPreference === 'weight_loss' && recipe.calories_tag === '高热量') {
        return false;
      }
      if (userPreferences?.dietPreference === 'muscle' && recipe.calories_tag === '低热量') {
        return false;
      }
      if (userPreferences?.dietPreference === 'comfort' && recipe.calories_tag !== '高热量') {
        return false;
      }

      return moodMatch;
    }).map(recipe => {
      const requiredIngredients = recipe.ingredients || [];
      
      const hasIngredients = [];
      const missingIngredients = [];
      
      requiredIngredients.forEach(ri => {
        const isAvailable = matchIngredient(ri.ingredient_name, availableIngNames);
        
        if (isAvailable) {
          hasIngredients.push(ri);
        } else {
          missingIngredients.push(ri);
        }
      });

      return {
        ...recipe,
        missingIngredients,
        hasIngredients,
        canCook: missingIngredients.length === 0,
        matchRate: requiredIngredients.length > 0 
          ? hasIngredients.length / requiredIngredients.length 
          : 0,
      };
    }).sort((a, b) => {
      // 优先显示可以完整制作的菜谱
      if (a.canCook && !b.canCook) return -1;
      if (!a.canCook && b.canCook) return 1;
      // 其次按匹配度排序
      return b.matchRate - a.matchRate;
    });
  };

  // 根据是否允许购物筛选
  const getFilteredRecipes = () => {
    const recommended = getRecommendedRecipes();
    
    if (userPreferences?.allow_shopping !== false) {
      // 允许购物时，显示所有推荐菜谱
      return recommended;
    } else {
      // 不允许购物时，只显示可以完全制作的菜谱
      return recommended.filter(r => r.canCook);
    }
  };

  // 根据烹饪时间筛选
  const getFilteredByTime = (maxTime) => {
    return getFilteredRecipes().filter(r => r.cook_time <= maxTime);
  };

  return {
    recipes: allRecipes,
    recommendedRecipes: getFilteredRecipes(),
    isLoading,
    error,
    getFilteredByTime,
    generateSmartRecommendations,
  };
};
