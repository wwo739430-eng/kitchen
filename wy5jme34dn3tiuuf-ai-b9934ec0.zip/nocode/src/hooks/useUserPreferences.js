import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

const PREFERENCES_KEY = 'user_preferences';

// 从本地存储获取
const getStoredPreferences = () => {
  const stored = localStorage.getItem(PREFERENCES_KEY);
  return stored ? JSON.parse(stored) : {
    current_mood: '一般',
    diet_goal: '正常饮食',
    servings: 2,
    allow_shopping: true,
  };
};

// 保存到本地存储
const saveStoredPreferences = (prefs) => {
  localStorage.setItem(PREFERENCES_KEY, JSON.stringify(prefs));
};

export const useUserPreferences = () => {
  const queryClient = useQueryClient();

  const { data: preferences = getStoredPreferences(), isLoading } = useQuery({
    queryKey: ['userPreferences'],
    queryFn: () => getStoredPreferences(),
    staleTime: Infinity,
  });

  const updateMutation = useMutation({
    mutationFn: async (newPrefs) => {
      const updated = { ...preferences, ...newPrefs };
      saveStoredPreferences(updated);
      return updated;
    },
    onSuccess: (data) => {
      queryClient.setQueryData(['userPreferences'], data);
    },
  });

  return {
    preferences,
    isLoading,
    updatePreferences: updateMutation.mutate,
    isUpdating: updateMutation.isPending,
  };
};
