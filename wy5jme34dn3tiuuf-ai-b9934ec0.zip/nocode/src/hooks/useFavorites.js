import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

const FAVORITES_KEY = 'user_favorites';

// 从本地存储获取收藏
const getStoredFavorites = () => {
  const stored = localStorage.getItem(FAVORITES_KEY);
  return stored ? JSON.parse(stored) : [];
};

// 保存到本地存储
const saveStoredFavorites = (favorites) => {
  localStorage.setItem(FAVORITES_KEY, JSON.stringify(favorites));
};

// 获取收藏列表
const fetchFavorites = async () => {
  // 这里可以从Supabase获取，现在先用本地存储
  return getStoredFavorites();
};

export const useFavorites = () => {
  const queryClient = useQueryClient();

  const { data: favorites = [], isLoading } = useQuery({
    queryKey: ['favorites'],
    queryFn: fetchFavorites,
    staleTime: Infinity,
  });

  // 添加收藏
  const addFavorite = (recipe) => {
    const current = getStoredFavorites();
    const exists = current.find(f => f.id === recipe.id);
    
    if (exists) {
      toast.info('这道菜已经在收藏夹了');
      return;
    }
    
    const updated = [...current, { ...recipe, favoritedAt: new Date().toISOString() }];
    saveStoredFavorites(updated);
    queryClient.setQueryData(['favorites'], updated);
    toast.success('已添加到收藏夹');
  };

  // 移除收藏
  const removeFavorite = (recipeId) => {
    const current = getStoredFavorites();
    const updated = current.filter(f => f.id !== recipeId);
    saveStoredFavorites(updated);
    queryClient.setQueryData(['favorites'], updated);
    toast.success('已取消收藏');
  };

  // 检查是否已收藏
  const isFavorite = (recipeId) => {
    return favorites.some(f => f.id === recipeId);
  };

  // 获取最常点的菜谱（按收藏时间排序，最近的优先）
  const getRecentFavorites = (limit = 5) => {
    return [...favorites]
      .sort((a, b) => new Date(b.favoritedAt) - new Date(a.favoritedAt))
      .slice(0, limit);
  };

  // 获取收藏数量
  const getFavoritesCount = () => favorites.length;

  return {
    favorites,
    isLoading,
    addFavorite,
    removeFavorite,
    isFavorite,
    getRecentFavorites,
    getFavoritesCount,
  };
};
