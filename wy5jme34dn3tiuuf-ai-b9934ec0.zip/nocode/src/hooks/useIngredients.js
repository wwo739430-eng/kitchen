import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

// 获取食材列表
const fetchIngredients = async () => {
  const { data, error } = await supabase
    .from('ingredients')
    .select('*')
    .order('created_at', { ascending: false });
  
  if (error) throw error;
  return data || [];
};

// 添加食材
const addIngredient = async (ingredient) => {
  const { data, error } = await supabase
    .from('ingredients')
    .insert([ingredient])
    .select()
    .single();
  
  if (error) throw error;
  return data;
};

// 更新食材
const updateIngredient = async ({ id, ...updates }) => {
  const { data, error } = await supabase
    .from('ingredients')
    .update(updates)
    .eq('id', id)
    .select()
    .single();
  
  if (error) throw error;
  return data;
};

// 删除食材
const deleteIngredient = async (id) => {
  const { error } = await supabase
    .from('ingredients')
    .delete()
    .eq('id', id);
  
  if (error) throw error;
};

export const useIngredients = () => {
  const queryClient = useQueryClient();

  const { data: ingredients = [], isLoading, error } = useQuery({
    queryKey: ['ingredients'],
    queryFn: fetchIngredients,
  });

  const addMutation = useMutation({
    mutationFn: addIngredient,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['ingredients'] });
      toast.success('食材添加成功');
    },
    onError: (error) => {
      toast.error('添加失败：' + error.message);
    },
  });

  const updateMutation = useMutation({
    mutationFn: updateIngredient,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['ingredients'] });
      toast.success('食材更新成功');
    },
    onError: (error) => {
      toast.error('更新失败：' + error.message);
    },
  });

  const deleteMutation = useMutation({
    mutationFn: deleteIngredient,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['ingredients'] });
      toast.success('食材删除成功');
    },
    onError: (error) => {
      toast.error('删除失败：' + error.message);
    },
  });

  // 计算剩余保质期
  const getRemainingDays = (createdAt, expiryDays) => {
    const created = new Date(createdAt);
    const expiry = new Date(created.getTime() + expiryDays * 24 * 60 * 60 * 1000);
    const now = new Date();
    const diff = Math.ceil((expiry - now) / (1000 * 60 * 60 * 24));
    return diff;
  };

  // 获取即将过期的食材
  const getExpiringSoon = (days = 3) => {
    return ingredients.filter(ing => {
      const remaining = getRemainingDays(ing.created_at, ing.expiry_days);
      return remaining <= days && remaining >= 0;
    });
  };

  return {
    ingredients,
    isLoading,
    error,
    addIngredient: addMutation.mutate,
    updateIngredient: updateMutation.mutate,
    deleteIngredient: deleteMutation.mutate,
    isAdding: addMutation.isPending,
    isUpdating: updateMutation.isPending,
    isDeleting: deleteMutation.isPending,
    getRemainingDays,
    getExpiringSoon,
  };
};
